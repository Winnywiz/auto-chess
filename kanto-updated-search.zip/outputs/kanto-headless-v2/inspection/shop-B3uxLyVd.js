import { n as e } from "./rolldown-runtime-8BhlS34s.js";
import { i as t, n } from "./toolsAllowed-BbHZamZY.js";
import { n as r, s as i, u as a } from "./i18n-CDsr9I4f.js";
import "./reach-DxJaD9s1.js";
import {
  S as o,
  d as s,
  f as c,
  g as l,
  l as u,
  o as d,
  r as f,
  s as p,
  v as m,
} from "./roster-CpnLcVHu.js";
import {
  $t as h,
  Bt as g,
  Ct as ee,
  E as _,
  Et as v,
  Gt as te,
  Ht as y,
  I as ne,
  It as re,
  Jt as ie,
  Kt as b,
  L as x,
  M as ae,
  Pt as oe,
  Qt as se,
  R as ce,
  Rt as S,
  Tt as C,
  W as w,
  Wt as le,
  Yt as ue,
  Zt as T,
  _ as de,
  _n as fe,
  _t as pe,
  ct as me,
  f as he,
  g as ge,
  gn as _e,
  hn as ve,
  i as ye,
  in as be,
  it as xe,
  jt as Se,
  kt as Ce,
  ln as we,
  lt as Te,
  mn as Ee,
  nn as De,
  pn as Oe,
  qt as ke,
  rn as Ae,
  tn as je,
  un as Me,
  vn as Ne,
  vt as Pe,
  xt as Fe,
  yn as Ie,
  z as Le,
  zt as Re,
} from "./sim-DVnRY1Xk.js";
import { f as ze, m as Be } from "./music-C_ykDJVf.js";
function Ve(e) {
  let t = typeof e == `string` ? et.exec(e) : null;
  return t ? { wk: Number(t[1]), seed: t[2], attempt: t[3] ?? null } : null;
}
function He(e) {
  if (!e.startsWith(`tw|`)) return e;
  let t = Ve(e);
  return t ? tt(t.wk, t.seed) : e;
}
function Ue(e) {
  var t;
  if (!rt(e) || !((t = Ve(e)) != null && t.attempt)) return 0;
  let n = 2166136261,
    r = `${e}|combate`;
  for (let e = 0; e < r.length; e++)
    ((n ^= r.charCodeAt(e)), (n = Math.imul(n, 16777619)));
  return (n >>> 0) & 1073741823;
}
function We(e, t, n) {
  if (!(e >= 1 && t >= 1 && e <= t) || n < 10) return `none`;
  let r = e / t;
  for (let [e, t] of st) if (r <= t) return e;
  return `part`;
}
function Ge(e) {
  let t = Math.max(0, Math.floor(e / 6e4));
  return { d: Math.floor(t / 1440), h: Math.floor((t % 1440) / 60), m: t % 60 };
}
var Ke, qe, Je, Ye, Xe, Ze, Qe, $e, et, tt, nt, rt, it, at, ot, st, ct;
function lt() {
  return (lt = e(() => {
    ((Ke = Date.UTC(2026, 9, 14, 9, 0, 0)),
      (qe = 6048e5),
      (Je = 864e5),
      (Ye = 108e5),
      (Xe = (e) => Math.max(0, Math.floor((e - Ke) / qe) + 1)),
      (Ze = (e) => Ke + (e - 1) * qe),
      (Qe = (e) => Ze(e + 1)),
      ($e = (e, t) => e > 0 && t < Qe(e) + 864e5),
      (et = /^tw\|(\d{1,5})\|([0-9a-f]{8,64})(?:\|([0-9a-z-]{1,40}))?$/),
      (tt = (e, t) => `tw|${e}|${t}`),
      (nt = (e, t) => `${e}|${t}`),
      (rt = (e) => typeof e == `string` && et.test(e)),
      (it = (e) => {
        var t;
        return ((t = Ve(e)) == null ? void 0 : t.wk) ?? 0;
      }),
      (at = (e) => {
        var t;
        return !!(
          (t = Ve(e)) != null &&
          (t = t.attempt) != null &&
          t.startsWith(`l`)
        );
      }),
      (ot = (e) => (at(e) ? 0 : it(e))),
      (st = [
        [`prism`, 0.01],
        [`gold`, 0.1],
        [`silver`, 0.25],
        [`bronze`, 0.5],
      ]),
      (ct = (e, t) =>
        Math.max(1, Math.min(100, Math.ceil((e / Math.max(1, t)) * 100)))));
  }))();
}
function E(e) {
  let t = 2166136261;
  for (let n = 0; n < e.length; n++)
    ((t ^= e.charCodeAt(n)), (t = Math.imul(t, 16777619)));
  let n = t >>> 0;
  return () => {
    let e = (n += 1831565813);
    return (
      (e = Math.imul(e ^ (e >>> 15), e | 1)),
      (e ^= e + Math.imul(e ^ (e >>> 7), e | 61)),
      ((e ^ (e >>> 14)) >>> 0) / 4294967296
    );
  };
}
function ut() {
  return (ut = e(() => {}))();
}
function dt(e, t, n) {
  return Math.max(
    t,
    Math.min(n, typeof e == `number` && Number.isFinite(e) ? Math.floor(e) : t),
  );
}
function ft(e, t = gt) {
  let n = dt(e.maxRound, 0, t.length - 1),
    r = e.win ? t.length : n;
  return {
    badges: yt(t, `G`, 0, r),
    elites: yt(t, `A`, 0, r),
    champion: yt(t, `C`, 0, r) > 0,
    mewtwo: e.win,
    optPlayed: yt(t, `f`, 0, e.win ? t.length : n + 1),
    passedRaw: r,
  };
}
function pt(e, t = gt) {
  let n = dt(e.league, 1, 8),
    r = e.win === !0,
    i = r ? t.length - 1 : dt(e.maxRound, 0, t.length - 1),
    a = ft({ win: r, maxRound: i }, t);
  return {
    league: n,
    win: r,
    maxRound: i,
    optLosses: dt(e.optLosses, 0, a.optPlayed),
    hpEnd: r ? dt(e.hpEnd, 1, vt(n)) : 0,
    retries: dt(e.retries, 0, 999),
  };
}
function mt(e, t = gt) {
  let n = pt(e, t),
    r = ft(n, t),
    i = +(!n.win && t[n.maxRound] === `f` && n.optLosses > 0),
    a = Math.max(0, r.passedRaw - (n.optLosses - i)),
    o = [
      { id: `stops`, n: a, unit: D.stop, pts: a * D.stop },
      { id: `badges`, n: r.badges, unit: D.badge, pts: r.badges * D.badge },
      { id: `elites`, n: r.elites, unit: D.elite, pts: r.elites * D.elite },
      {
        id: `champion`,
        n: +!!r.champion,
        unit: D.champion,
        pts: r.champion ? D.champion : 0,
      },
      {
        id: `mewtwo`,
        n: +!!r.mewtwo,
        unit: D.mewtwo,
        pts: r.mewtwo ? D.mewtwo : 0,
      },
      {
        id: `hp`,
        n: n.win ? n.hpEnd : 0,
        unit: D.hp,
        pts: n.win ? n.hpEnd * D.hp : 0,
      },
      {
        id: `flawless`,
        n: n.win && n.retries === 0 ? 1 : 0,
        unit: D.flawless,
        pts: n.win && n.retries === 0 ? D.flawless : 0,
      },
    ],
    s = o.reduce((e, t) => e + t.pts, 0),
    c = _t(n.league);
  return {
    rows: o,
    subtotal: s,
    league: n.league,
    mult: c,
    total: Math.round(s * c),
    title: ht(n, t),
  };
}
function ht(e, t = gt) {
  let n = ft(e, t);
  if (n.mewtwo) return `master`;
  if (n.champion) return `champion`;
  let r = t.indexOf(`A`);
  return n.badges >= 8 && e.maxRound >= r
    ? `challenger`
    : n.badges >= 8
      ? `ace`
      : n.badges >= 4
        ? `veteran`
        : n.badges >= 1
          ? `trainer`
          : `novice`;
}
var gt, D, _t, vt, yt, bt, xt;
function St() {
  return (St = e(() => {
    ((gt = `ffEGfffGfEfGfEfGffEGfEfGfGfGfffEAAAACM`),
      (D = {
        stop: 10,
        badge: 100,
        elite: 150,
        champion: 300,
        mewtwo: 500,
        hp: 2,
        flawless: 150,
      }),
      (_t = (e) => 1 + 0.25 * (dt(e, 1, 8) - 1)),
      (vt = (e) => 100),
      (yt = (e, t, n, r) => {
        let i = 0;
        for (let a = Math.max(0, n); a < Math.min(e.length, r); a++)
          t.includes(e[a]) && i++;
        return i;
      }),
      (bt = [
        `novice`,
        `trainer`,
        `veteran`,
        `ace`,
        `challenger`,
        `champion`,
        `master`,
      ]),
      (xt = (e, t) => t.score - e.score || e.durationMs - t.durationMs));
  }))();
}
function Ct(e) {
  let t = typeof e == `number` && Number.isFinite(e) ? Math.floor(e) : 1;
  return t >= 3 ? 3 : t >= 2 ? 2 : 1;
}
var wt, Tt, Et, Dt, Ot, kt, At;
function jt() {
  return (jt = e(() => {
    (r(),
      St(),
      (wt = (e) => Math.min(2, Ct(e))),
      (Tt = Date.UTC(2026, 9, 20)),
      (Et = (e) => {
        let t = Ct(e);
        return t === 3 ? `legend` : t === 2 ? `trainer` : `normal`;
      }),
      (Dt = (e) => i(`game.diff.${Et(e)}`)),
      (Ot = (e) => `×${a(_t(Ct(e)), `auto`)}`),
      (kt = (e) =>
        Et(e) === `trainer`
          ? i(`game.diff.trainerNote`, { pct: a(Math.round(At * 100)) })
          : i(`game.diff.normalNote`)),
      (At = 0.05));
  }))();
}
var Mt;
function Nt() {
  return (Nt = e(() => {
    (jt(),
      (Mt = {
        kanto: {
          2: [{ k: `trainers` }, { k: `vit`, v: At }],
          3: [
            { k: `trainers` },
            { k: `vit`, v: At },
            { k: `rage`, v: 0.15 },
            { k: `fortress`, v: 0.1, from: 0.85 },
          ],
        },
        safari: {
          2: [
            { k: `trainers` },
            { k: `vit`, v: 0.09 },
            { k: `focus`, v: 0.5, at: `all`, type: `Poison` },
            { k: `rage`, v: 0.15, at: `all`, type: `Poison` },
          ],
          3: [
            { k: `trainers` },
            { k: `vit`, v: 0.1 },
            { k: `vit`, v: 0.08, at: `final` },
            { k: `focus`, v: 0.5, at: `all`, type: `Poison` },
            { k: `rage`, v: 0.35, at: `all`, type: `Poison` },
            { k: `fortress`, v: 0.3, at: `final` },
          ],
        },
        lavanda: {
          2: [
            { k: `trainers` },
            { k: `rage`, v: 0.3, at: `all`, type: `Ghost` },
            { k: `fortress`, v: 0.15 },
            { k: `vit`, v: 0.03 },
            { k: `fortress`, v: 0.15, at: `final` },
          ],
          3: [
            { k: `trainers` },
            { k: `rage`, v: 0.4, at: `all`, type: `Ghost` },
            { k: `fortress`, v: 0.2, from: 0.77 },
            { k: `vit`, v: 0.08 },
            { k: `focus`, v: 0.5, at: `final` },
            { k: `fortress`, v: 0.4, at: `final` },
            { k: `vit`, v: 0.06, at: `final` },
          ],
        },
        rocket: {
          2: [
            { k: `trainers` },
            { k: `armory`, v: 1 },
            { k: `rage`, v: 0.1, at: `final` },
          ],
          3: [
            { k: `trainers` },
            { k: `armory`, v: 1 },
            { k: `armory`, v: 1, from: 0.7 },
            { k: `rage`, v: 0.15, from: 0.7 },
          ],
        },
      }));
  }))();
}
var O,
  k,
  A,
  Pt,
  Ft,
  It,
  Lt,
  Rt,
  zt,
  Bt,
  Vt,
  Ht,
  Ut,
  Wt,
  Gt,
  Kt,
  qt,
  Jt,
  Yt,
  Xt,
  Zt,
  Qt,
  $t,
  en,
  tn,
  nn,
  rn,
  an,
  on,
  sn,
  cn,
  ln,
  un,
  dn,
  fn,
  pn,
  mn,
  hn;
function gn() {
  return (gn = e(() => {
    (s(),
      (O = { atk: 1, spa: 0 }),
      (k = { atk: 0, spa: 1 }),
      (A = (e, t, n, r, i = {}) => ({
        name: e,
        type: t,
        kind: n,
        mana: r,
        ...i,
      })),
      (Pt = A(`Luz Lunar`, `Normal`, `heal`, 50, {
        start: 10,
        heal: 160,
        hits: 3,
        cleanse: 1,
        fade: 0.02,
        selfK: 0.3,
        scale: k,
        tag: `Limpia estados`,
        stars: [
          void 0,
          void 0,
          {
            heal: 100,
            cleanse: 99,
            allyShield: 30,
            tag: `Limpia y escuda`,
            desc: `La luna llena cura al aliado más herido y a los 2 siguientes, les quita todos sus estados y les da un escudo pequeño.`,
          },
        ],
        desc: `La luna llena cura al aliado más herido y a los 2 siguientes y les quita un estado (sueño, confusión, parálisis, veneno, quemadura…).`,
      })),
      (Ft = {
        moves: [
          A(`Luz Lunar`, `Normal`, `heal`, 45, {
            start: 10,
            heal: 220,
            cleanse: 1,
            fade: 0.02,
            selfK: 0.3,
            scale: k,
            tag: `Limpia estados`,
            desc: `Luz de luna sobre el aliado más herido: lo cura y le quita un estado (sueño, confusión, parálisis, veneno, quemadura…).`,
          }),
          Pt,
        ],
      }),
      (It = A(`Escamas`, `Bug`, `multi`, 60, {
        power: 125,
        esc: { atk: 0, spa: 0.9 },
        spread: !0,
        hits: 3,
        powder: !0,
        scale: k,
        seq: [
          { poison: 30 },
          { stun: 0.5, status: `paralyze` },
          { sunderT: 3 },
        ],
        tag: `Escamas ×3`,
        stars: [
          void 0,
          void 0,
          {
            hits: 5,
            power: 35,
            tag: `Escamas ×5`,
            desc: `Aletea y suelta 5 nubes de escamas: la primera sobre su objetivo y las demás sobre los enemigos más cercanos a él; cada una deja un estado distinto: veneno, parálisis y Desgaste.`,
          },
        ],
        desc: `Aletea y suelta 3 nubes de escamas: la primera sobre su objetivo y las demás sobre los enemigos más cercanos a él; cada una deja un estado distinto: veneno, parálisis y Desgaste.`,
      })),
      (Lt = A(`Señal Rayo`, `Bug`, `line`, 50, {
        start: 10,
        power: 240,
        len: 3,
        slow: 25,
        slowT: 1.5,
        scale: k,
        tag: `Línea de 3`,
        desc: `Rayo de ondas de sus ojos de radar en línea hacia su objetivo: daña y ralentiza un 25 % 1,5 s a los que alcanza.`,
      })),
      (Rt = A(`Puya Nociva`, `Poison`, `dash`, 45, {
        start: 10,
        power: 160,
        poison: 30,
        back: !0,
        scale: O,
        tag: `Picado y vuelta`,
        desc: `Se lanza a picar a su objetivo con el aguijón y vuelve a su sitio: daño y veneno.`,
      })),
      (zt = A(`Veneno X`, `Poison`, `dash`, 60, {
        power: 120,
        esc: { atk: 1.1, spa: 0 },
        combo: 2,
        canCrit: !0,
        critBonus: 0.1,
        poison: 40,
        back: !0,
        scale: O,
        tag: `Tajos en X`,
        stars: [
          void 0,
          void 0,
          {
            combo: 4,
            power: 90,
            tag: `Dos picados`,
            desc: `Cae en picado dos veces sobre su objetivo: en cada uno cruza las alas y le da dos tajos en X que envenenan y pueden ser críticos; luego vuelve a su sitio.`,
          },
        ],
        desc: `Cae en picado sobre su objetivo, cruza las alas y le da dos tajos en X que envenenan y pueden ser críticos; luego vuelve a su sitio.`,
      })),
      (Bt = {
        moves: [Lt, It],
        flex: { stars: [1, 2, 3], def: `spec`, spec: [Lt, It], phys: [Rt, zt] },
      }),
      (Vt = A(`Látigo Cepa`, `Grass`, `nuke`, 40, {
        start: 10,
        power: 120,
        stun: 0.3,
        status: `flinch`,
        scale: O,
        tag: `Retroceso`,
        desc: `Latigazo con la liana a su objetivo: daño y le hace retroceder.`,
      })),
      (Ht = A(`Latigazo`, `Grass`, `line`, 55, {
        start: 10,
        power: 210,
        esc: { atk: 1.2, spa: 0 },
        len: 2,
        zone: { kind: `bind`, dur: 1, anchor: !0 },
        scale: O,
        tag: `Atrapa`,
        desc: `Latigazo enorme en línea de 2 hacia su objetivo: daña y deja atrapados 1 s a los que alcanza (no pueden moverse).`,
      })),
      (Ut = A(`Tragar`, `Grass`, `nuke`, 70, {
        power: 650,
        esc: { atk: 1.1, spa: 0 },
        vsStatus: { status: `trapped`, pct: 40 },
        leech: 0.2,
        spit: 2,
        scale: O,
        tag: `Engulle`,
        desc: `Engulle a su objetivo, lo exprime (se cura parte del daño) y lo escupe 2 casillas: pega un 40 % más si estaba atrapado.`,
      })),
      (Wt = A(`Ácido`, `Poison`, `nuke`, 40, {
        start: 10,
        power: 190,
        sunderT: 3,
        scale: k,
        tag: `Desgaste`,
        desc: `Escupe ácido a su objetivo: daño y Desgaste 3 s (menos Defensa y Def. Esp.).`,
      })),
      (Gt = A(`Bomba Ácida`, `Poison`, `line`, 55, {
        start: 10,
        power: 200,
        shape: `cone`,
        len: 3,
        sunderT: 4,
        scale: k,
        tag: `Cono que corroe`,
        desc: `Cono de ácido hacia su objetivo: daña y deja Desgaste 4 s a todos los que alcanza.`,
      })),
      (Kt = A(`Bomba Lodo`, `Poison`, `aoeTarget`, 70, {
        power: 540,
        esc: { atk: 0, spa: 1.2 },
        radius: 1,
        aoeK: 0.5,
        poison: 40,
        vsStatus: { status: `sunder`, pct: 40 },
        scale: k,
        tag: `Revienta`,
        desc: `Bola de lodo a su objetivo que revienta y salpica a los de al lado (la mitad): daño y veneno; pega un 40 % más a los que tienen Desgaste.`,
      })),
      (qt = {
        range: 2,
        moves: [Vt, Ht, Ut],
        flex: {
          stars: [1, 2, 3],
          def: `phys`,
          phys: [Vt, Ht, Ut],
          spec: [Wt, Gt, Kt],
        },
      }),
      (Jt = A(`Autodestrucción`, `Poison`, `aoeSelf`, 60, {
        power: 300,
        esc: { atk: 0, spa: 0.6 },
        dmgHp: 0.06,
        radius: 2,
        selfDestruct: 1.5,
        scale: k,
        tag: `Explota`,
        desc: `Herido, se hincha y explota: gran daño a 2 casillas a su alrededor. No se debilita: queda con 1 PS y agotado 1,5 s (una vez por combate).`,
      })),
      (Yt = {
        role: `tank`,
        range: 1,
        moves: [
          A(`Polución`, `Poison`, `aoeSelf`, 50, {
            start: 10,
            power: 70,
            esc: { atk: 0, spa: 0.6 },
            dmgHp: 0.03,
            radius: 1,
            poison: 25,
            zone: { kind: `toxic`, dur: 2, radius: 1, miss: 15 },
            scale: k,
            tag: `Humo tóxico`,
            desc: `Suelta gas a su alrededor: envenena y deja humo 2 s en el que los enemigos fallan el 15 % de sus ataques. Pega más cuantos más PS tiene.`,
          }),
          A(`Niebla Tóxica`, `Poison`, `aoeSelf`, 60, {
            start: 10,
            power: 45,
            esc: { atk: 0, spa: 0.6 },
            dmgHp: 0.03,
            radius: 2,
            poison: 30,
            zone: { kind: `toxic`, dur: 4, radius: 2, miss: 20 },
            provoke: 2,
            lowHp: Jt,
            lowHpBelow: 0.3,
            scale: k,
            tag: `Niebla y explosión`,
            desc: `Nube tóxica a 2 casillas 4 s: envenena, los de dentro fallan el 20 % de sus ataques y provoca. Pega más cuantos más PS tiene. Por debajo del 30 % de sus PS lanza Autodestrucción.`,
          }),
        ],
      }),
      (Xt = A(`Armadura Ácida`, `Poison`, `shield`, 80, {
        power: 200,
        shieldEsc: { hp: 0.1 },
        shieldRefresh: !0,
        provoke: 2,
        retaliate: 0.15,
        zone: { kind: `toxic`, dur: 4, radius: 2, poison: 12, poisonHp: 0.003 },
        scale: O,
        esc: { atk: 0, spa: 0 },
        tag: `Charco que crece`,
        stars: [
          void 0,
          void 0,
          {
            power: 150,
            zone: {
              kind: `toxic`,
              dur: 0,
              radius: 2,
              poison: 12,
              poisonHp: 0.003,
              grow: 3,
            },
            tag: `Charco permanente`,
            desc: `Se derrite en un gran escudo (con sus PS) y provoca. Su charco tóxico se queda todo el combate y crece cada vez que lo repite. Represalia: devuelve parte del daño recibido a los pegados.`,
          },
        ],
        desc: `Se derrite en un gran escudo (con sus PS) y provoca; el charco tóxico crece a 2 casillas 4 s. Represalia: devuelve parte del daño recibido a los pegados.`,
      })),
      (Zt = {
        moves: [
          A(`Residuos`, `Poison`, `aoeSelf`, 50, {
            start: 10,
            power: 90,
            dmgHp: 0.04,
            radius: 1,
            poison: 25,
            zone: {
              kind: `toxic`,
              dur: 3,
              radius: 1,
              poison: 20,
              poisonHp: 0.004,
            },
            retaliate: 0.25,
            scale: O,
            esc: { atk: 0, spa: 0 },
            tag: `Charco tóxico`,
            desc: `Lanza lodo a su alrededor: daña, envenena y deja un charco tóxico 3 s (más fuerte cuantos más PS tiene). Represalia: devuelve parte del daño recibido a los pegados.`,
          }),
          Xt,
        ],
      }),
      (Qt = {
        moves: [
          A(`Absorber`, `Grass`, `multi`, 60, {
            start: 10,
            power: 120,
            esc: { atk: 0, spa: 0.6 },
            dmgDef: 1,
            spread: !0,
            hits: 3,
            leech: 0.3,
            zone: { kind: `bind`, dur: 2, anchor: !0 },
            provoke: 2,
            scale: k,
            tag: `Lianas ×3`,
            stars: [
              void 0,
              void 0,
              {
                hits: 5,
                tag: `Lianas ×5`,
                desc: `Lanza lianas a los 5 enemigos más cercanos: los atrapa 2 s (no pueden moverse), les quita PS y se cura una parte. Pega también con su Defensa y provoca.`,
              },
            ],
            desc: `Lanza lianas a los 3 enemigos más cercanos: los atrapa 2 s (no pueden moverse), les quita PS y se cura una parte. Pega también con su Defensa y provoca.`,
          }),
        ],
      }),
      ($t = {
        moves: [
          A(`Guillotina`, `Bug`, `nuke`, 70, {
            start: 10,
            power: 580,
            esc: { atk: 1.3, spa: 0 },
            grab: 1,
            execBelow: 0.2,
            scale: O,
            tag: `Remata`,
            stars: [
              void 0,
              void 0,
              {
                execSplash: 0.5,
                desc: `Agarra a su objetivo con las pinzas 1 s y corta: si queda por debajo del 20 % de sus PS, lo deja KO y lanza su cuerpo contra los que tenía al lado.`,
              },
            ],
            desc: `Agarra a su objetivo con las pinzas 1 s y corta: si queda por debajo del 20 % de sus PS, lo deja KO.`,
          }),
        ],
      }),
      (en = A(`Gruñido`, `Normal`, `aoeSelf`, 40, {
        start: 10,
        statusMove: !0,
        power: 0,
        radius: 1,
        atkDown: { pct: 0.2, t: 3 },
        provoke: 2,
        selfShield: 160,
        shieldEsc: { def: 0.8 },
        scale: O,
        esc: { atk: 0, spa: 0 },
        tag: `Ataque ↓`,
        desc: `Gruñe: los enemigos pegados pierden un 20 % de Ataque 3 s y quedan provocados; ella se escuda con su Defensa.`,
      })),
      (tn = A(`Colmillo Veneno`, `Poison`, `nuke`, 45, {
        start: 10,
        power: 90,
        dmgDef: 1,
        stun: 0.5,
        status: `flinch`,
        poison: 25,
        retaliate: 0.4,
        scale: O,
        esc: { atk: 0, spa: 0 },
        tag: `Muerde y envenena`,
        desc: `Muerde a su objetivo con colmillos venenosos: daño con su Defensa, retroceso y veneno. Represalia: devuelve parte del daño recibido a los pegados.`,
      })),
      (nn = A(`Tierra Viva`, `Ground`, `aoeTarget`, 60, {
        power: 100,
        dmgDef: 1.8,
        radius: 1,
        selfShield: 160,
        shieldEsc: { def: 1 },
        allyBoost: { trait: `Ground`, pct: 8 },
        scale: k,
        esc: { atk: 0, spa: 0 },
        tag: `Escudo y tierra`,
        desc: `La tierra estalla bajo su objetivo y los de alrededor (pega con su Defensa) y se protege con un escudo. Un 8 % más por cada aliado de tipo Tierra.`,
      })),
      (rn = A(`Arañazo`, `Normal`, `multi`, 40, {
        start: 10,
        power: 140,
        hits: 2,
        scale: O,
        tag: `Dos zarpazos`,
        desc: `Dos zarpazos rápidos a su objetivo.`,
      })),
      (an = A(`Superpoder`, `Fighting`, `nuke`, 55, {
        start: 10,
        power: 340,
        esc: { atk: 1.4, spa: 0 },
        selfSunder: { pct: 0.15, t: 3 },
        scale: O,
        tag: `A todo o nada`,
        desc: `Golpe con todas sus fuerzas a su objetivo; después ella pierde un 15 % de Defensa 3 s.`,
      })),
      (on = A(`Fisura`, `Ground`, `line`, 70, {
        power: 300,
        esc: { atk: 1.4, spa: 0 },
        len: 4,
        airborne: 0.8,
        scale: O,
        tag: `Grieta en línea`,
        desc: `Pisa fuerte y abre una grieta en línea de 4 hacia su objetivo: daña y lanza por los aires a todos los que alcanza.`,
      })),
      (sn = {
        moves: [en, tn, nn],
        flex: {
          stars: [1, 2, 3],
          def: `spec`,
          axes: [`atk`, `def`],
          spec: [en, tn, nn],
          phys: [rn, an, on],
        },
      }),
      (cn = {
        moves: [
          A(`Patada Baja`, `Fighting`, `nuke`, 40, {
            start: 15,
            power: 160,
            vsMaxHp: 0.05,
            scale: O,
            tag: `Anti-tanques`,
            desc: `Barrido bajo a su objetivo: pega más cuantos más PS máximos tiene (el 5 % de ellos).`,
          }),
          A(`Tajo Cruzado`, `Fighting`, `multi`, 60, {
            start: 10,
            power: 150,
            hits: 2,
            vsMaxHp: 0.04,
            canCrit: !0,
            critBonus: 0.15,
            rage: { hits: 3, as: 20, t: 3 },
            scale: O,
            tag: `Tajos ×2`,
            stars: [
              void 0,
              void 0,
              {
                hits: 3,
                power: 100,
                tag: `Tajos ×3`,
                desc: `Tres tajos en X a su objetivo, cada uno con el 4 % de sus PS máximos y con crítico alto. Cada 3 golpes que recibe se enfurece: ataca un 20 % más rápido 3 s.`,
              },
            ],
            desc: `Dos tajos en X a su objetivo, cada uno con el 4 % de sus PS máximos y con crítico alto. Cada 3 golpes que recibe se enfurece: ataca un 20 % más rápido 3 s.`,
          }),
        ],
      }),
      (ln = {
        moves: [
          A(`Día de Pago`, `Normal`, `multi`, 45, {
            start: 10,
            power: 80,
            spread: !0,
            hits: 3,
            payDay: 3,
            scale: O,
            tag: `Monedas`,
            desc: `Lanza 3 monedas: a su objetivo y a los enemigos más cercanos a él. Cada 3 que aciertan cae una moneda: si ganas el combate, +1 de oro (1 por combate y 8 por partida, aunque tengas varios Meowth).`,
          }),
          A(`Golpes Furia`, `Normal`, `dash`, 60, {
            start: 60,
            power: 110,
            combo: 3,
            perAsHit: 25,
            sunderT: 3,
            pick: `carry`,
            scale: O,
            tag: `Zarpazos`,
            desc: `Salta al enemigo que más daño ha hecho, chirría (Desgaste 3 s) y le da 3 zarpazos, uno más por cada 25 % de velocidad de ataque de sus objetos.`,
          }),
        ],
      }),
      (un = {
        moves: [
          A(`Ataque Furia`, `Normal`, `multi`, 45, {
            start: 10,
            power: 45,
            hits: 3,
            scale: O,
            tag: `Picotazos ×3`,
            desc: `Tres picotazos seguidos a su objetivo, alternando las dos cabezas.`,
          }),
          A(`Triataque`, `Normal`, `multi`, 75, {
            power: 70,
            esc: { atk: 1.1, spa: 0 },
            spread: !0,
            hits: 3,
            seq: [
              { burn: 40 },
              { freeze: 0.8 },
              { stun: 0.5, status: `paralyze` },
            ],
            scale: O,
            tag: `Tres cabezas`,
            stars: [void 0, void 0, { power: 45 }],
            desc: `Cada cabeza picotea a un enemigo distinto (su objetivo y los más cercanos a él): una quema, otra congela un momento y otra paraliza.`,
          }),
        ],
      }),
      (dn = {
        moves: [
          A(`Psicoonda`, `Psychic`, `multi`, 50, {
            start: 10,
            power: 120,
            hits: 3,
            seq: [{ power: 60 }, { power: 120 }, { power: 180 }],
            scale: k,
            tag: `Ondas crecientes`,
            desc: `Tres ondas psíquicas a su objetivo, cada una más fuerte que la anterior.`,
          }),
          A(`Comesueños`, `Psychic`, `line`, 90, {
            power: 420,
            esc: { atk: 0, spa: 0.8 },
            shape: `cone`,
            len: 3,
            stun: 2,
            status: `sleep`,
            dreamEat: { insom: 4, repeatK: 0.5 },
            scale: k,
            tag: `Péndulo`,
            stars: [
              void 0,
              void 0,
              {
                stun: 2.5,
                len: 4,
                desc: `Balancea el péndulo en un cono de 4 hacia su objetivo: duerme 2,5 s y daña a todos los que alcanza. El que despierta queda Desvelado 4 s y cada nuevo sueño al mismo rival dura la mitad.`,
              },
            ],
            desc: `Balancea el péndulo en un cono de 3 hacia su objetivo: duerme 2 s y daña a todos los que alcanza. El que despierta queda Desvelado 4 s y cada nuevo sueño al mismo rival dura la mitad.`,
          }),
        ],
      }),
      (fn = {
        moves: [
          A(`Barrera`, `Psychic`, `buff`, 45, {
            start: 10,
            windup: 0.3,
            active: 0.2,
            recover: 0.25,
            barrier: { basic: 0.5, ability: 0, t: 6 },
            esc: { atk: 0, spa: 0.6 },
            scale: k,
            tag: `Muro de mimo`,
            stars: [
              void 0,
              void 0,
              {
                barrier: { basic: 0.5, ability: 0.3, t: 6 },
                tag: `Muro y luz`,
                desc: `Levanta un muro invisible y una Pantalla de Luz: los aliados de su fila y de la de delante reciben un 50 % menos de daño de ataques básicos y un 30 % menos de habilidades 6 s (más con objetos de At. Esp.).`,
              },
            ],
            desc: `Levanta un muro invisible: los aliados de su fila y de la de delante reciben un 50 % menos de daño de ataques básicos 6 s (más con objetos de At. Esp.).`,
          }),
        ],
      }),
      (pn = {
        moves: [
          A(`Atizar`, `Normal`, `nuke`, 60, {
            start: 10,
            power: 520,
            esc: { atk: 0.6, spa: 0 },
            dmgHp: 0.05,
            pick: `back`,
            push: -3,
            provoke: 2,
            scale: O,
            tag: `Gancho`,
            stars: [
              void 0,
              void 0,
              {
                power: 400,
                stun: 1,
                status: `paralyze`,
                desc: `Lanza la lengua al enemigo más retrasado, lo atrae hasta él, lo atiza y lo paraliza. Pega más cuantos más PS tiene y provoca.`,
              },
            ],
            desc: `Lanza la lengua al enemigo más retrasado, lo atrae hasta él y lo atiza. Pega más cuantos más PS tiene y provoca.`,
          }),
        ],
      }),
      (mn = {
        moves: [
          A(`Conversión`, `Normal`, `nuke`, 50, {
            start: 10,
            power: 400,
            rampUse: 0.15,
            convert: !0,
            scale: k,
            tag: `Cambia de tipo`,
            stars: [void 0, void 0, { power: 360 }],
            desc: `Cambia su tipo al que mejor resiste el último golpe de habilidad que recibió y dispara un rayo de ese tipo a su objetivo. Cada Conversión del combate pega un 15 % más.`,
          }),
        ],
      }),
      (hn = {
        clefairy: Ft,
        venonat: Bt,
        bellsprout: qt,
        koffing: Yt,
        grimer: Zt,
        tangela: Qt,
        pinsir: $t,
        nidoranf: sn,
        mankey: cn,
        meowth: ln,
        doduo: un,
        drowzee: dn,
        mrmime: fn,
        lickitung: pn,
        porygon: mn,
      }));
    for (let e of Object.values(hn))
      for (let t of new Set([
        ...e.moves,
        ...(e.flex ? [e.flex.phys, e.flex.spec].flat() : []),
      ]))
        c(t);
  }))();
}
var _n, vn, yn, bn;
function xn() {
  return (xn = e(() => {
    (s(),
      gn(),
      (_n = {
        name: `Puño Cometa`,
        type: `Normal`,
        kind: `buff`,
        mana: 60,
        start: 10,
        windup: 0.25,
        active: 0.15,
        recover: 0.2,
        empower: {
          n: 4,
          dmg: 0.1,
          twice: !0,
          twiceK: 0.5,
          stars: [void 0, void 0, { n: 6 }],
        },
        allyBoost: { trait: `Normal`, pct: 6 },
        scale: { atk: 1, spa: 0 },
        esc: { atk: 1.1, spa: 0 },
        tag: `Golpes dobles`,
        stars: [
          void 0,
          void 0,
          {
            desc: `Sus 6 próximos ataques golpean dos veces (el segundo al 50 %) y pegan más: un 6 % más por cada aliado de tipo Normal.`,
          },
        ],
        desc: `Sus 4 próximos ataques golpean dos veces (el segundo al 50 %) y pegan más: un 6 % más por cada aliado de tipo Normal.`,
      }),
      c(_n),
      (vn = [
        {
          id: `clefairy`,
          stages: [35, 36],
          cost: 2,
          traits: [`Normal`],
          role: `support`,
          range: 3,
          donor: `jigglypuff`,
        },
        {
          id: `venonat`,
          stages: [48, 49],
          cost: 2,
          traits: [`Bug`, `Poison`],
          role: `marksman`,
          range: 3,
          donor: `pikachu`,
        },
        {
          id: `bellsprout`,
          stages: [69, 70, 71],
          cost: 2,
          traits: [`Grass`, `Poison`],
          role: `fighter`,
          range: 1,
          donor: `poliwag`,
        },
        {
          id: `koffing`,
          stages: [109, 110],
          cost: 2,
          traits: [`Poison`],
          role: `support`,
          range: 3,
          donor: `jigglypuff`,
        },
        {
          id: `grimer`,
          stages: [88, 89],
          cost: 3,
          traits: [`Poison`],
          role: `tank`,
          range: 1,
          donor: `seel`,
        },
        {
          id: `tangela`,
          stages: [114],
          cost: 3,
          traits: [`Grass`],
          role: `tank`,
          range: 1,
          donor: `onix`,
        },
        {
          id: `pinsir`,
          stages: [127],
          cost: 3,
          traits: [`Bug`],
          role: `fighter`,
          range: 1,
          donor: `hitmonlee`,
        },
        {
          id: `kangaskhan`,
          stages: [115],
          cost: 4,
          traits: [`Normal`],
          role: `fighter`,
          range: 1,
          donor: `tauros`,
          moves: [_n],
        },
      ]),
      (yn = [
        {
          id: `nidoranf`,
          stages: [29, 30, 31],
          cost: 1,
          traits: [`Poison`, `Ground`],
          role: `tank`,
          range: 1,
          donor: `geodude`,
        },
        {
          id: `mankey`,
          stages: [56, 57],
          cost: 1,
          traits: [`Fighting`],
          role: `fighter`,
          range: 1,
          donor: `machop`,
        },
        {
          id: `meowth`,
          stages: [52, 53],
          cost: 2,
          traits: [`Normal`],
          role: `assassin`,
          range: 1,
          donor: `ekans`,
          entry: `open`,
        },
        {
          id: `doduo`,
          stages: [84, 85],
          cost: 2,
          traits: [`Normal`, `Flying`],
          role: `assassin`,
          range: 1,
          donor: `ekans`,
          entry: `rush`,
        },
        {
          id: `drowzee`,
          stages: [96, 97],
          cost: 3,
          traits: [`Psychic`],
          role: `mage`,
          range: 3,
          donor: `magmar`,
        },
        {
          id: `mrmime`,
          stages: [122],
          cost: 3,
          traits: [`Psychic`],
          role: `support`,
          range: 3,
          donor: `jigglypuff`,
        },
        {
          id: `lickitung`,
          stages: [108],
          cost: 3,
          traits: [`Normal`],
          role: `tank`,
          range: 1,
          donor: `slowpoke`,
        },
        {
          id: `porygon`,
          stages: [137],
          cost: 3,
          traits: [`Normal`],
          role: `special`,
          range: 3,
          donor: `jynx`,
        },
      ]),
      (bn = [...vn, ...yn].map((e) => {
        let t = f[e.donor];
        if (!t || t.branchOf)
          throw Error(`extraLines: donante raro ${e.donor}`);
        let { branches: n, flex: r, entry: i, ...a } = t,
          o = hn[e.id],
          s =
            (o == null ? void 0 : o.moves) ??
            e.moves ??
            (t.moves.length > Math.max(1, e.stages.length)
              ? t.moves.slice(0, e.stages.length)
              : t.moves);
        return {
          ...a,
          moves: s,
          id: e.id,
          stages: e.stages,
          cost: e.cost,
          traits: e.traits,
          role: (o == null ? void 0 : o.role) ?? e.role,
          range: (o == null ? void 0 : o.range) ?? e.range,
          ...(o != null && o.flex ? { flex: o.flex } : {}),
          ...(e.entry ? { entry: e.entry } : {}),
        };
      })));
    for (let e of bn) f[e.id] || (f[e.id] = e);
  }))();
}
var j, M, Sn, Cn;
function wn() {
  return (wn = e(() => {
    ((j = (e, t, n, r = {}) => ({
      who: e,
      kind: `trainer`,
      side: t,
      gesture: n,
      ...r,
    })),
      (M = (e, t, n, r = {}) => ({
        who: e,
        kind: `mon`,
        side: t,
        gesture: n,
        ...r,
      })),
      (Sn = (e, t, n, r = {}) => ({
        who: e,
        kind: `mine`,
        side: t,
        gesture: n,
        ...r,
      })),
      (Cn = (e) =>
        e.endsWith(`:win`)
          ? { id: e.slice(0, -4), win: !0, end: !1 }
          : e.endsWith(`:end`)
            ? { id: e.slice(0, -4), win: !1, end: !0 }
            : { id: e, win: !1, end: !1 }));
  }))();
}
function Tn(e, t) {
  for (let r of t)
    for (let t = r.from; t <= r.to; t++) {
      var n;
      let i = e[t];
      if (
        i &&
        (r.music && (i.music = r.music),
        (n = i.eventLook) != null && n.music && (i.music = i.eventLook.music),
        !i.event && !i.battleMusic)
      ) {
        let e = i.boss || i.badge ? (r.boss ?? r.battle) : r.battle;
        e && (i.battleMusic = e);
      }
    }
  return e;
}
function En(e, t) {
  for (let n of e) {
    let e = t[n.id];
    if (!e || !n.event) continue;
    let { title: r, ...i } = e;
    (r && (n.eventTitle = r),
      (n.eventLook = { ...n.eventLook, ...i }),
      i.music && (n.music = i.music));
  }
  return e;
}
function Dn(e, t, ...n) {
  let r = e.find((e) => e.id === t);
  r &&
    (r.vid ?? (r.vid = `a`),
    (r.variants = n.map((e, t) => ({
      ...e,
      vid: String.fromCharCode(98 + t),
    }))));
}
function On(e, t) {
  let n = (e) => {
      var n;
      return ((n = t.sprites) == null ? void 0 : n[e]) ?? e;
    },
    r = (e) => {
      var n;
      return ((n = t.who) == null ? void 0 : n[e]) ?? e;
    },
    i = (e) => {
      var n;
      return ((n = t.text) == null ? void 0 : n[e]) ?? e;
    };
  for (let t of e.rounds) {
    t.trainer && (t.trainer = n(t.trainer));
    let e = t.name.lastIndexOf(` · `);
    ((t.name =
      e >= 0 ? t.name.slice(0, e + 3) + r(t.name.slice(e + 3)) : r(t.name)),
      t.intro && (t.intro = i(t.intro)),
      t.choice &&
        (t.choice = {
          ...t.choice,
          trainer: n(t.choice.trainer),
          who: r(t.choice.who),
          text: i(t.choice.text),
          options: t.choice.options.map((e) => ({ ...e, label: i(e.label) })),
        }));
  }
  for (let t of e.story ?? [])
    ((t.trainer = n(t.trainer)), (t.who = r(t.who)), (t.text = i(t.text)));
  for (let t of e.scenes ?? [])
    for (let e of t.panels) {
      e.line && (e.line = i(e.line));
      for (let t of e.cast)
        (t.kind ?? `trainer`) === `trainer` && (t.who = n(t.who));
    }
}
var N, P, F, I, L, kn, An;
function jn() {
  return (jn = e(() => {
    (Ne(),
      (N = (e, t = 1) => ({ line: e, star: t })),
      (P = (e, t, n, r, i, a = `mus_rg_route24`) => ({
        id: e,
        name: t,
        route: `wild`,
        tier: n,
        team: Ie(r, n),
        intro: `¡Pokémon salvajes!`,
        bg: i,
        music: a,
      })),
      (F = (e, t, n, r, i, a, o, s = `mus_rg_route24`) => ({
        id: e,
        name: t,
        route: `trainer`,
        tier: i,
        trainer: n,
        team: Ie(a, i),
        intro: r,
        bg: o,
        music: s,
      })),
      (I = (e, t, n, r = `bg-city`, i = `mus_rg_fuchsia`) => ({
        id: e,
        name: t,
        event: n,
        team: [],
        bg: r,
        music: i,
      })),
      (L = (e, t, n, r, i, a, o, s = `mus_rg_game_corner`) => ({
        id: e,
        name: t,
        boss: !0,
        introStyle: `trainer`,
        trainer: n,
        team: Ie(a, i),
        intro: r,
        bg: o,
        music: s,
      })),
      (kn = (e, t, n, r, i) => ({
        ...I(e, t, [`safari`], r, i),
        eventTitle: `¡Pokémon liberados!`,
        eventPool: n,
        eventSure: !0,
      })),
      (An = (e, t, n, r, i, a, o, s = `bg-city`, c = `mus_rg_lavender`) => ({
        ...I(e, t, [`choice`], s, c),
        choice: { title: n, who: r, trainer: i, text: a, options: o },
      })));
  }))();
}
var R, z, Mn, Nn, Pn, Fn, In, Ln, Rn, zn, Bn, Vn, Hn, Un;
function Wn() {
  return (Wn = e(() => {
    (Ne(),
      jn(),
      o(),
      wn(),
      (R = {
        entrada: `Zona Safari · Entrada`,
        pradera: `Zona Safari · Pradera`,
        bosque: `Zona Safari · Bosque`,
        lago: `Zona Safari · Lago`,
        hierba: `Zona Safari · Hierba alta`,
        casa: `Zona Safari · Casa del Guarda`,
        koga: `Zona Safari · Bosque de Koga`,
      }),
      (z = (e, t) => ({ ...e, scene: t })),
      (Mn = {
        name: `Safari Ball`,
        icon: `safariball-icon.png`,
        max: 3,
        lures: [
          {
            id: `bait`,
            name: `Cebo`,
            icon: `item:sitrus-berry`,
            hint: `Más difícil, pero si falla no huye: otra tirada gratis`,
            catch: 0.65,
            keep: !0,
          },
          {
            id: `rock`,
            name: `Piedra`,
            icon: `pk/fx/rock1.png`,
            hint: `Más fácil, pero si falla huye sin consuelo`,
            catch: 1.15,
            noConsolation: !0,
          },
        ],
      }),
      (Nn = (e, t, n, r, i, a) => L(e, t, `rocketgrunt`, n, r, i, a)),
      (Pn = [
        P(
          `saf-r13`,
          `Ruta 13 · Pokémon salvajes`,
          [1, 0, 0],
          [`magikarp`],
          `bg-river`,
        ),
        F(
          `saf-pescador`,
          `Ruta 13 · Pescador`,
          `fisherman-gen1`,
          `¡Un Pescador quiere luchar!`,
          [2, 0, 0],
          [`magikarp`, `poliwag`],
          `bg-river`,
        ),
        I(
          `saf-oak`,
          `Ruta 14 · Profesor Oak`,
          [`oak`],
          `bg-route`,
          `mus_rg_oak`,
        ),
        P(
          `saf-r15`,
          `Ruta 15 · Pokémon salvajes`,
          [3, 0, 0],
          [`venonat`, `oddish`, `pidgey`],
          `bg-meadow`,
        ),
        {
          id: `saf-azul`,
          name: `Ruta 15 · Rival Azul`,
          route: `rival`,
          tier: [4, 1, 0],
          intro: `¡Tu rival Azul quiere luchar!`,
          trainer: `blue-gen1`,
          team: [N(`squirtle`, 2), N(`pidgey`), N(`abra`), N(`rattata`)],
          bg: `bg-route`,
          music: `mus_rg_encounter_rival`,
        },
        I(
          `saf-fucsia`,
          `Ciudad Fucsia · Centro Pokémon`,
          [`center`],
          `bg-city`,
          `mus_rg_poke_center`,
        ),
        Nn(
          `saf-bici`,
          `Calle Bici · Recluta furtivo`,
          `¡Un recluta furtivo del Team Rocket!`,
          [5, 2, 0],
          [`sandshrew`, `rattata`, `machop`],
          `bg-city`,
        ),
        kn(
          `saf-lib1`,
          `Calle Bici · Pokémon liberados`,
          [`nidoran`, `paras`, `exeggcute`, `venonat`],
          `bg-city`,
        ),
        {
          id: `saf-kanga`,
          name: `Zona Safari · Madre furiosa`,
          boss: !0,
          battleMusic: `mus_rg_vs_legend`,
          intro: `¡Una Kangaskhan furiosa protege a su cría!`,
          team: [
            N(`kangaskhan`, 2),
            N(`clefairy`, 2),
            N(`rattata`, 2),
            N(`nidoran`),
            { ...N(`kangaskhan`, 1), ward: !0 },
          ],
          ward: { guard: `kangaskhan` },
          bg: `bg-meadow`,
          music: `mus_rg_fuchsia`,
          scene: R.entrada,
        },
        z(
          I(`saf-puerta`, `Zona Safari · Puerta`, [`safari`], `bg-meadow`),
          R.entrada,
        ),
        z(
          P(
            `saf-centro`,
            `Zona Safari · Área Centro`,
            [5, 2, 0],
            [`nidoran`, `paras`, `venonat`, `exeggcute`],
            `bg-meadow`,
            `mus_rg_fuchsia`,
          ),
          R.pradera,
        ),
        z(
          Nn(
            `saf-este`,
            `Zona Safari · Recluta furtivo`,
            `¡Ni se te ocurra acercarte a nuestro botín!`,
            [6, 2, 0],
            [`sandshrew`, `growlithe`, `pidgey`, `rattata`],
            `bg-forest`,
          ),
          R.bosque,
        ),
        z(
          kn(
            `saf-lib2`,
            `Zona Safari · Pokémon liberados`,
            [`tangela`, `pinsir`, `scyther`, `exeggcute`],
            `bg-forest`,
          ),
          R.pradera,
        ),
        {
          ...I(`saf-safari2`, `Zona Safari · Pescador`, [`safari`], `bg-river`),
          eventTitle: `La caña del Pescador`,
          eventPool: [
            `magikarp`,
            `poliwag`,
            `psyduck`,
            `seel`,
            `slowpoke`,
            `dratini`,
          ],
          scene: R.lago,
        },
        z(
          P(
            `saf-norte`,
            `Zona Safari · Área Norte`,
            [6, 1, 0],
            [`nidoran`, `rhyhorn`, `tauros`, `chansey`],
            `bg-meadow`,
            `mus_rg_fuchsia`,
          ),
          R.hierba,
        ),
        {
          ...I(
            `saf-guarda`,
            `Zona Safari · Casa del Guarda`,
            [`mall`],
            `bg-route`,
          ),
          eventTitle: `Tienda del Safari`,
          scene: R.casa,
        },
        z(
          I(`saf-safari3`, `Zona Safari · Área Oeste`, [`safari`], `bg-meadow`),
          R.hierba,
        ),
        {
          id: `saf-furtivo`,
          name: `Zona Safari · Jefe furtivo`,
          boss: !0,
          introStyle: `gym`,
          trainer: `rocketgrunt`,
          takes: 5,
          intro: `¡El jefe de los furtivos! ¡Suelta a esos Pokémon!`,
          team: [
            N(`rhyhorn`, 2),
            N(`scyther`, 2),
            N(`exeggcute`, 2),
            N(`tauros`, 2),
            N(`kangaskhan`),
            N(`chansey`),
          ],
          bg: `bg-forest`,
          music: `mus_rg_game_corner`,
          scene: R.bosque,
        },
        {
          ...P(
            `saf-estampida`,
            `Zona Safari · Estampida`,
            [6, 2, 0],
            [`tauros`, `tauros`, `rhyhorn`],
            `bg-meadow`,
            `mus_rg_fuchsia`,
          ),
          quick: !0,
          intro: `¡Los furtivos han espantado a los Tauros!`,
          scene: R.pradera,
        },
        z(
          kn(
            `saf-lib3`,
            `Zona Safari · Pokémon liberados`,
            [`kangaskhan`, `chansey`, `tauros`, `rhyhorn`, `dratini`],
            `bg-meadow`,
          ),
          R.pradera,
        ),
        z(
          F(
            `saf-ninja1`,
            `Zona Safari · Ninja de Koga`,
            `juggler-gen1`,
            `¡Un ninja de Koga te corta el paso!`,
            [7, 4, 1],
            [`koffing`, `grimer`, `zubat`, `venonat`],
            `bg-forest`,
          ),
          R.bosque,
        ),
        z(
          I(
            `saf-centro2`,
            `Zona Safari · Casa de descanso`,
            [`center`],
            `bg-route`,
            `mus_rg_poke_center`,
          ),
          R.casa,
        ),
        {
          id: `saf-azul2`,
          name: `Zona Safari · Rival Azul`,
          route: `rival`,
          tier: [8, 5, 1],
          intro: `¡Tu rival Azul quiere luchar!`,
          trainer: `blue-gen1`,
          team: Ie(
            [`squirtle`, `pidgey`, `abra`, `growlithe`, `exeggcute`],
            [8, 5, 1],
          ),
          bg: `bg-river`,
          music: `mus_rg_encounter_rival`,
          scene: R.lago,
        },
        z(
          F(
            `saf-cerco`,
            `Zona Safari · Últimos furtivos`,
            `rocketgrunt`,
            `¡Los últimos furtivos te cierran el paso!`,
            [8, 4, 1],
            [`sandshrew`, `growlithe`, `pidgey`, `rattata`],
            `bg-meadow`,
          ),
          R.hierba,
        ),
        z(
          I(
            `saf-tienda`,
            `Zona Safari · Tienda del Safari`,
            [`mall`],
            `bg-route`,
            `mus_rg_poke_center`,
          ),
          R.casa,
        ),
        {
          id: `saf-koga`,
          name: `Zona Safari · Koga`,
          badge: 5,
          intro: `¡El Líder Koga te desafía!`,
          trainer: `koga-gen1`,
          scene: R.koga,
          mood: { night: 0.35 },
          fog: 0.35,
          fogTint: `#8e4cc0`,
          team: [
            N(`koffing`, 3),
            N(`venonat`, 2),
            { ...N(`zubat`, 3), items: [`shell-bell`] },
            N(`grimer`, 3),
            N(`grimer`, 2),
            N(`weedle`, 2),
            N(`nidoran`, 2),
            N(`bellsprout`, 2),
          ],
          bg: `bg-dampcave`,
          music: `mus_rg_gym`,
        },
      ]),
      (Fn = [
        {
          name: `Rutas`,
          full: `Rutas a Fucsia`,
          from: 0,
          to: 8,
          lossBase: 3,
          floor: !0,
          music: `mus_rg_cycling`,
          battle: `mus_rg_vs_wild`,
          boss: `mus_rg_vs_trainer`,
        },
        {
          name: `Safari`,
          full: `Zona Safari`,
          from: 9,
          to: 17,
          lossBase: 5,
          floor: !1,
          music: `mus_rg_fuchsia`,
          battle: `mus_rg_vs_wild`,
          boss: `mus_rg_vs_trainer`,
        },
        {
          name: `Corazón`,
          full: `Corazón del Safari`,
          from: 18,
          to: 25,
          lossBase: 8,
          floor: !1,
          music: `mus_rg_fuchsia`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_gym_leader`,
        },
      ]),
      (In = [
        `vulpix`,
        `gastly`,
        `ekans`,
        `voltorb`,
        `magnemite`,
        `onix`,
        `jynx`,
        `snorlax`,
      ]),
      (Ln = [
        `clefairy`,
        `venonat`,
        `bellsprout`,
        `koffing`,
        `grimer`,
        `tangela`,
        `pinsir`,
        `kangaskhan`,
      ]),
      (Rn = [
        `tauros`,
        `chansey`,
        `scyther`,
        `rhyhorn`,
        `exeggcute`,
        `dratini`,
        `nidoran`,
        `paras`,
        `kangaskhan`,
        `pinsir`,
        `tangela`,
        `venonat`,
      ]),
      (zn = {
        trainer: `scientist-gen1`,
        name: `Guarda del Safari`,
        intro: `¡Bienvenido a la Zona Safari! Hoy rondan furtivos. Elige a tu compañero.`,
      }),
      (Bn = [
        {
          at: `saf-r13`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `Los furtivos del Team Rocket se llevan a los Pokémon del Safari. ¡Detenlos!`,
        },
        {
          at: `saf-azul`,
          trainer: `blue-gen1`,
          who: `Azul`,
          text: `¿Furtivos? Eso es cosa de novatos como tú.`,
        },
        {
          at: `saf-bici`,
          trainer: `rocketgrunt`,
          who: `Recluta furtivo`,
          text: `¡Esa Kangaskhan y su cría valen una fortuna!`,
        },
        {
          at: `saf-puerta`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `¡La cría está a salvo! Los furtivos se esconden dentro del Safari.`,
        },
        {
          at: `saf-safari3`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `¡Han visto a su jefe en el Área Oeste!`,
        },
        {
          at: `saf-ninja1`,
          trainer: `koga-gen1`,
          who: `Koga`,
          text: `Mis ninjas cortan la huida a los furtivos. Tú, ven a por tu medalla.`,
        },
        {
          at: `saf-azul2`,
          trainer: `blue-gen1`,
          who: `Azul`,
          text: `He oído lo de los furtivos. No te creas tan importante.`,
        },
        {
          at: `saf-cerco`,
          trainer: `rocketgrunt`,
          who: `Jefe furtivo`,
          text: `¡Esto no quedará así! El jefe se enterará…`,
        },
        {
          at: `saf-furtivo`,
          trainer: `rocketgrunt`,
          who: `Jefe furtivo`,
          text: `Ese {mon} que se te escapó… ¡ahora está en mi jaula!`,
          when: `lost`,
        },
        {
          at: `saf-lib1`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `¡Los has salvado! Uno quiere irse contigo.`,
        },
        {
          at: `saf-lib2`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `Estos Pokémon estaban en las jaulas del furtivo.`,
        },
        {
          at: `saf-lib3`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `¡Has calmado la estampida! Su botín vuelve a ser libre.`,
        },
        {
          at: `saf-safari2`,
          trainer: `fisherman-gen1`,
          who: `Pescador`,
          text: `¡Toma mi caña! En este lago pica de todo.`,
        },
        {
          at: `saf-guarda`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `Pasa a mi casa: tengo cosas que te servirán.`,
        },
        {
          at: `saf-centro2`,
          trainer: `nurse`,
          who: `Enfermera`,
          text: `Descansa aquí antes de seguir: Koga anda cerca.`,
        },
        {
          at: `saf-tienda`,
          trainer: `scientist-gen1`,
          who: `Guarda del Safari`,
          text: `Última parada antes de Koga. ¡Prepárate bien!`,
        },
      ]),
      (Vn = {
        trainer: `koga-gen1`,
        who: `Koga`,
        text: `Esos furtivos trabajaban para alguien de Ciudad Azulona…`,
      }),
      m([
        [`Guarda del Safari`, `Safari Zone Warden`],
        [`Azul`, `Blue`],
        [`Koga`, `Koga`],
        [`Recluta furtivo`, `Poacher Grunt`],
        [`Jefe furtivo`, `Poacher Boss`],
        [
          `¡Bienvenido a la Zona Safari! Hoy rondan furtivos. Elige a tu compañero.`,
          `Welcome to the Safari Zone! Poachers are about today. Choose your partner.`,
        ],
        [
          `Los furtivos del Team Rocket se llevan a los Pokémon del Safari. ¡Detenlos!`,
          `Team Rocket poachers are taking the Safari Pokémon. Stop them!`,
        ],
        [
          `¿Furtivos? Eso es cosa de novatos como tú.`,
          `Poachers? That sounds like a job for a rookie like you.`,
        ],
        [
          `¡Esa Kangaskhan y su cría valen una fortuna!`,
          `That Kangaskhan and her baby are worth a fortune!`,
        ],
        [
          `¡La cría está a salvo! Los furtivos se esconden dentro del Safari.`,
          `The baby is safe! The poachers are hiding inside the Safari.`,
        ],
        [
          `¡Han visto a su jefe en el Área Oeste!`,
          `Their boss has been spotted in the West Area!`,
        ],
        [
          `¡Esto no quedará así! El jefe se enterará…`,
          `This isn't over! The boss will hear about this…`,
        ],
        [
          `Mis ninjas vigilan el Safari. Ven a por tu medalla.`,
          `My ninjas watch over the Safari. Come and earn your Badge.`,
        ],
        [
          `He oído lo de los furtivos. No te creas tan importante.`,
          `I heard about the poachers. Don't let it go to your head.`,
        ],
        [
          `Esos furtivos trabajaban para alguien de Ciudad Azulona…`,
          `Those poachers were working for someone in Celadon City…`,
        ],
        [`Zona Safari`, `Safari Zone`],
        [`Captura, captura, captura`, `Catch, catch, catch`],
        [`Los furtivos del Team Rocket`, `The Team Rocket poachers`],
        [`Kanto`, `Kanto`],
        [
          `8 medallas, la Liga y un secreto`,
          `8 Badges, the League and a secret`,
        ],
        [`Rutas a Fucsia`, `Roads to Fuchsia`],
        [`Rutas`, `Routes`],
        [`Safari`, `Safari`],
        [`Fucsia`, `Fuchsia`],
        [`Área Centro`, `Center Area`],
        [`Área Este`, `East Area`],
        [`Área Norte`, `North Area`],
        [`Área Oeste`, `West Area`],
        [`Puerta`, `Gate`],
        [`Casa del Guarda`, `Warden's House`],
        [`Kangaskhan`, `Kangaskhan`],
        [`Pescador`, `Fisherman`],
        [`Pokémon liberados`, `Freed Pokémon`],
        [`¡Pokémon liberados!`, `Pokémon freed!`],
        [
          `¡Una Kangaskhan furiosa protege a su cría!`,
          `A furious Kangaskhan protects her baby!`,
        ],
        [
          `¡Un recluta furtivo del Team Rocket!`,
          `A Team Rocket poacher grunt!`,
        ],
        [
          `¡Ni se te ocurra acercarte a nuestro botín!`,
          `Don't even think about touching our loot!`,
        ],
        [
          `¡El jefe de los furtivos! ¡Suelta a esos Pokémon!`,
          `The poacher boss! Let those Pokémon go!`,
        ],
        [`La caña del Pescador`, `The Fisherman's Rod`],
        [`Estampida`, `Stampede`],
        [`¡Una estampida de Tauros!`, `A Tauros stampede!`],
        [`Tienda del Safari`, `Safari Shop`],
      ]),
      m([
        [
          `¡Los furtivos han espantado a los Tauros!`,
          `The poachers have spooked the Tauros!`,
        ],
        [`Últimos furtivos`, `Last poachers`],
        [
          `¡Los últimos furtivos te cierran el paso!`,
          `The last poachers block your way!`,
        ],
        [
          `Mis ninjas cortan la huida a los furtivos. Tú, ven a por tu medalla.`,
          `My ninjas are cutting off the poachers. You, come and earn your Badge.`,
        ],
        [
          `¡Has calmado la estampida! Su botín vuelve a ser libre.`,
          `You calmed the stampede! Their loot is free again.`,
        ],
      ]),
      Tn(Pn, Fn));
    for (let e of Pn)
      (e.id === `saf-bici` || e.id === `saf-lib1`) && (e.scene = `Calle Bici`);
    ((Hn = [
      {
        id: `intro`,
        at: `start`,
        style: `strip`,
        go: `iris`,
        panels: [
          { bg: `bg-route`, fx: `dawn`, cast: [j(`red-gen1`, `c`, `joy`)] },
          {
            bg: `bg-meadow`,
            cast: [
              M(`kangaskhan`, `l`, `fear`),
              j(`rocketgrunt`, `r`, `angry`),
            ],
          },
          {
            bg: `bg-meadow`,
            cast: [j(`scientist-gen1`, `c`, `!`)],
            line: `¡Furtivos en el Safari!`,
          },
        ],
      },
      {
        id: `cria`,
        at: Pn[9].id,
        style: `panel`,
        when: { mark: `saf-kanga:ward`, not: !0 },
        panels: [
          {
            bg: `bg-meadow`,
            cast: [
              M(`kangaskhan`, `c`, `joy`),
              M(`kangaskhan`, `r`, `joy`, { scale: 0.55 }),
            ],
          },
        ],
      },
      {
        id: `cria-confiada`,
        at: `saf-kanga:win`,
        style: `panel`,
        when: { mark: `saf-kanga:ward` },
        panels: [
          {
            bg: `bg-meadow`,
            fx: `dawn`,
            cast: [
              M(`kangaskhan`, `l`, `joy`),
              M(`kangaskhan`, `c`, `joy`, { scale: 0.55 }),
              Sn(`starter`, `r`, `joy`),
            ],
            line: `¡La madre te confía a su cría!`,
          },
        ],
      },
      {
        id: `huye`,
        at: `saf-estampida`,
        style: `panel`,
        panels: [
          {
            bg: `bg-meadow`,
            cast: [
              j(`rocketgrunt`, `r`, `angry`, { flip: !0 }),
              M(`tauros`, `l`, `angry`),
            ],
          },
        ],
      },
      {
        id: `koga`,
        at: `saf-koga`,
        style: `panel`,
        go: `iris`,
        panels: [
          {
            bg: `scenes/safari-koga-noche.webp`,
            cast: [j(`koga-gen1`, `c`, `dots`)],
          },
        ],
      },
      {
        id: `madre`,
        at: `saf-kanga`,
        style: `panel`,
        panels: [
          {
            bg: `bg-meadow`,
            cast: [
              j(`rocketgrunt`, `l`, `fear`, { flip: !0 }),
              M(`kangaskhan`, `c`, `fear`, { scale: 0.55 }),
              M(`kangaskhan`, `r`, `angry`, { scale: 1.15 }),
            ],
            line: `¡Los furtivos la han asustado! Su cría se esconde detrás de ella.`,
          },
        ],
      },
      {
        id: `nudo`,
        at: `saf-norte`,
        style: `strip`,
        panels: [
          {
            bg: `bg-meadow`,
            cast: [j(`scientist-gen1`, `c`, `fear`)],
            line: `¡Se los llevan al bosque!`,
          },
          {
            bg: `bg-forest`,
            fx: `night`,
            cast: [
              M(`tauros`, `l`, `fear`),
              j(`rocketgrunt`, `c`, `joy`),
              M(`chansey`, `r`, `fear`),
            ],
          },
          {
            bg: `bg-forest`,
            cast: [j(`red-gen1`, `l`, `angry`), M(`kangaskhan`, `r`, `!`)],
          },
        ],
      },
      {
        id: `fin`,
        at: `end`,
        style: `strip`,
        go: `iris`,
        panels: [
          {
            bg: `bg-meadow`,
            fx: `dawn`,
            cast: [M(`kangaskhan`, `c`, `joy`, { scale: 1.1 })],
          },
          {
            bg: `bg-route`,
            cast: [j(`red-gen1`, `l`, `joy`), j(`scientist-gen1`, `r`, `joy`)],
          },
          {
            bg: `bg-meadow`,
            fx: `dawn`,
            cast: [
              M(`tauros`, `l`, `joy`),
              M(`chansey`, `c`, `joy`),
              M(`dratini`, `r`, `joy`),
            ],
          },
        ],
      },
    ]),
      m([
        [`¡Furtivos en el Safari!`, `Poachers in the Safari!`],
        [`Ciudad Fucsia`, `Fuchsia City`],
      ]),
      m([
        [`Madre furiosa`, `Furious mother`],
        [`Ninja de Koga`, `Koga's ninja`],
        [
          `¡Un ninja de Koga te corta el paso!`,
          `One of Koga's ninjas blocks your way!`,
        ],
        [`Casa de descanso`, `Rest House`],
        [`Corazón`, `Heart`],
        [`Corazón del Safari`, `Heart of the Safari`],
        [`Enfermera`, `Nurse`],
        [
          `¡Los furtivos la han atacado! Protege a su cría.`,
          `The poachers attacked her! She protects her baby.`,
        ],
        [`¡Se los llevan al bosque!`, `They're taking them to the forest!`],
        [
          `¡Los has salvado! Uno quiere irse contigo.`,
          `You saved them! One wants to come with you.`,
        ],
        [
          `Estos Pokémon estaban en las jaulas del furtivo.`,
          `These Pokémon were in the poacher's cages.`,
        ],
        [
          `¡Toma mi caña! En este lago pica de todo.`,
          `Take my rod! Everything bites in this lake.`,
        ],
        [
          `Pasa a mi casa: tengo cosas que te servirán.`,
          `Come into my house: I've got things you'll need.`,
        ],
        [
          `Descansa aquí antes de seguir: Koga anda cerca.`,
          `Rest here before you go on: Koga is close.`,
        ],
        [
          `Última parada antes de Koga. ¡Prepárate bien!`,
          `Last stop before Koga. Get ready!`,
        ],
      ]),
      m([
        [
          `¡Los furtivos la han asustado! Su cría se esconde detrás de ella.`,
          `The poachers scared her! Her baby hides behind her.`,
        ],
        [
          `¡La madre te confía a su cría!`,
          `The mother entrusts her baby to you!`,
        ],
        [
          `Ese {mon} que se te escapó… ¡ahora está en mi jaula!`,
          `That {mon} that got away from you… is in my cage now!`,
        ],
        [`Cebo`, `Bait`],
        [`Piedra`, `Rock`],
        [
          `Más difícil, pero si falla no huye: otra tirada gratis`,
          `Harder, but if it fails it doesn't flee: one free throw`,
        ],
        [
          `Más fácil, pero si falla huye sin consuelo`,
          `Easier, but if it fails it flees with no consolation`,
        ],
      ]),
      (Un = { host: `scientist-gen1`, name: `Guarda del Safari` }),
      En(Pn, {
        "saf-lib1": {
          ...Un,
          say: `¡Los has salvado! Uno quiere irse contigo.`,
          icon: `item:poke-ball`,
        },
        "saf-lib2": {
          ...Un,
          say: `Estos Pokémon estaban en las jaulas del furtivo.`,
        },
        "saf-safari2": {
          host: `fisherman-gen1`,
          name: `Pescador`,
          say: `¡Toma mi caña! En este lago pica de todo.`,
          icon: `item:good-rod`,
        },
        "saf-safari3": { ...Un, say: `¡Han visto a su jefe en el Área Oeste!` },
        "saf-guarda": {
          ...Un,
          say: `Pasa a mi casa: tengo cosas que te servirán.`,
        },
        "saf-lib3": {
          ...Un,
          say: `¡Has calmado la estampida! Su botín vuelve a ser libre.`,
        },
        "saf-centro2": {
          ...Un,
          title: `Casa de descanso`,
          say: `Descansa aquí antes de seguir: Koga anda cerca.`,
          icon: `item:sitrus-berry`,
        },
        "saf-tienda": {
          ...Un,
          title: `Tienda del Safari`,
          say: `Última parada antes de Koga. ¡Prepárate bien!`,
        },
      }),
      On(
        { rounds: Pn, story: Bn, scenes: Hn },
        {
          sprites: { rocketgrunt: `burglar-gen3` },
          who: { "Recluta furtivo": `Furtivo` },
          text: {
            "¡Un recluta furtivo del Team Rocket!": `¡Un furtivo quiere luchar!`,
            "Los furtivos del Team Rocket se llevan a los Pokémon del Safari. ¡Detenlos!": `Unos furtivos se llevan a los Pokémon del Safari. ¡Detenlos!`,
          },
        },
      ));
    for (let e of Pn) e.id === `saf-furtivo` && (e.trainer = `burglar`);
    for (let e of Bn) e.who === `Jefe furtivo` && (e.trainer = `burglar`);
    for (let e of Hn)
      if (e.id === `huye`)
        for (let t of e.panels)
          for (let e of t.cast) e.who === `burglar-gen3` && (e.who = `burglar`);
    (m([
      [`Furtivo`, `Poacher`],
      [`¡Un furtivo quiere luchar!`, `You are challenged by Poacher!`],
      [`Los furtivos del Safari`, `The Safari poachers`],
      [
        `Unos furtivos se llevan a los Pokémon del Safari. ¡Detenlos!`,
        `Poachers are taking the Safari Pokémon. Stop them!`,
      ],
    ]),
      Dn(Pn, `saf-koga`, {
        team: [
          N(`koffing`, 3),
          N(`venonat`, 2),
          N(`ekans`, 3),
          N(`grimer`, 3),
          N(`grimer`, 2),
          N(`oddish`, 2),
          N(`nidoranf`, 2),
          N(`bellsprout`, 2),
        ],
      }));
  }))();
}
var B, V, Gn, Kn, H, U, qn, Jn, Yn, Xn, Zn, Qn, $n, er, tr, nr;
function rr() {
  return (rr = e(() => {
    (o(),
      wn(),
      jn(),
      (B = `bg-gen4-cave`),
      (V = `mus_rg_lavender`),
      (Gn = {
        id: `marowak`,
        hp: 41e3,
        dmg: 9,
        hidden: !0,
        spare: [`cubone`],
        skillK: 0.6,
      }),
      (Kn = `Torre Pokémon`),
      (H = (e, t) => ({
        ...t,
        name: `${Kn} · ${e}F · ${t.name}`,
        floor: `${e}F`,
      })),
      (U = [
        P(
          `lav-r10`,
          `Ruta 10 · Pokémon salvajes`,
          [1, 0, 0],
          [`magikarp`],
          `bg-deepsea`,
        ),
        F(
          `lav-tunel`,
          `Túnel Roca · Montañero`,
          `hiker-gen1`,
          `¡Un Montañero quiere luchar!`,
          [2, 0, 0],
          [`geodude`, `machop`],
          `bg-earthycave`,
          `mus_rg_mt_moon`,
        ),
        I(
          `lav-oak`,
          `Pueblo Lavanda · Profesor Oak`,
          [`oak`],
          `bg-city`,
          `mus_rg_oak`,
        ),
        P(
          `lav-r8`,
          `Ruta 8 · Pokémon salvajes`,
          [3, 0, 0],
          [`meowth`, `zubat`, `rattata`],
          `bg-route`,
          V,
        ),
        I(
          `lav-centro`,
          `Pueblo Lavanda · Centro Pokémon`,
          [`center`],
          `bg-city`,
          `mus_rg_poke_center`,
        ),
        An(
          `lav-cubone`,
          `Pueblo Lavanda · Cubone`,
          `La Cubone huérfana`,
          `Niño de Lavanda`,
          `lass-gen1`,
          `Esta Cubone perdió a su madre en la torre. Nadie la cuida…`,
          [
            { label: `Llevártela`, gain: { mon: `cubone` } },
            { label: `Dejarle comida`, gain: { xp: 4, gold: 2 } },
          ],
          `bg-city`,
        ),
        {
          ...I(
            `lav-tienda`,
            `Pueblo Lavanda · Tienda`,
            [`mall`],
            `bg-city`,
            `mus_rg_poke_center`,
          ),
          eventTitle: `Tienda de Lavanda`,
        },
        H(
          1,
          F(
            `lav-medium1`,
            `Médium`,
            `channeler-gen1`,
            `¡Una Médium quiere luchar!`,
            [4, 1, 0],
            [`gastly`, `zubat`, `gastly`],
            B,
            V,
          ),
        ),
        H(
          1,
          L(
            `lav-recluta1`,
            `Recluta Rocket`,
            `rocketgrunt`,
            `¡Nadie sube a la torre! Órdenes del jefe.`,
            [5, 2, 0],
            [`geodude`, `machop`, `rattata`],
            B,
          ),
        ),
        H(2, {
          ...L(
            `lav-azul`,
            `Rival Azul`,
            `blue-gen1`,
            `¡Tu rival Azul quiere luchar!`,
            [6, 3, 0],
            [`squirtle`, `pidgey`, `abra`, `rattata`, `cubone`],
            B,
            `mus_rg_encounter_rival`,
          ),
          introStyle: `gym`,
        }),
        H(
          2,
          F(
            `lav-p3`,
            `Médium`,
            `channeler-gen1`,
            `¡Una Médium quiere luchar!`,
            [6, 2, 0],
            [`gastly`, `drowzee`, `gastly`, `koffing`],
            B,
            V,
          ),
        ),
        H(
          3,
          An(
            `lav-lapida`,
            `Lápida`,
            `La lápida sin nombre`,
            `Médium`,
            `channeler-gen1`,
            `Aquí descansa un Pokémon sin nombre. ¿Qué haces?`,
            [
              { label: `Rezar`, gain: { hp: 10 } },
              { label: `Dejar una ofrenda`, cost: 6, gain: { full: 1 } },
            ],
            B,
          ),
        ),
        H(
          3,
          P(
            `lav-p4`,
            `Fantasmas`,
            [6, 3, 0],
            [`gastly`, `gastly`, `cubone`, `zubat`],
            B,
            V,
          ),
        ),
        H(
          4,
          F(
            `lav-p5`,
            `Médium`,
            `channeler-gen1`,
            `¡Una Médium quiere luchar!`,
            [7, 3, 0],
            [`gastly`, `mrmime`, `drowzee`, `clefairy`],
            B,
            V,
          ),
        ),
        H(
          4,
          An(
            `lav-posesion`,
            `Médium poseída`,
            `La Médium poseída`,
            `Médium poseída`,
            `channeler-gen1`,
            `¡Fuera… de… aquí…! (Un espíritu la tiene atrapada.)`,
            [
              {
                label: `Ahuyentar al espíritu`,
                hpCost: 12,
                gain: { full: 1, part: 1 },
              },
              { label: `Pagar un ritual`, cost: 8, gain: { part: 1, xp: 4 } },
              { label: `Pasar de largo`, gain: {} },
            ],
            B,
          ),
        ),
        H(5, {
          ...I(`lav-purificada`, `Zona purificada`, [`center`], B, V),
          eventTitle: `Zona purificada`,
        }),
        H(
          5,
          P(
            `lav-p6`,
            `Fantasmas`,
            [7, 4, 0],
            [`gastly`, `cubone`, `koffing`, `grimer`],
            B,
            V,
          ),
        ),
        H(
          6,
          L(
            `lav-recluta2`,
            `Recluta Rocket`,
            `rocketgruntf`,
            `¡El jefe está arriba con el viejo! No pasarás.`,
            [8, 3, 0],
            [`mankey`, `onix`, `zubat`, `meowth`],
            B,
          ),
        ),
        H(6, {
          ...L(
            `lav-jefe`,
            `Jefe Rocket`,
            `teamrocketgruntm-gen3`,
            `¡El Sr. Fuji no se irá hasta que hable! ¡Fuera!`,
            [8, 5, 0],
            [`onix`, `grimer`, `drowzee`, `meowth`, `zubat`, `rattata`],
            B,
          ),
          introStyle: `gym`,
        }),
        H(
          7,
          kn(
            `lav-lib`,
            `Pokémon liberados`,
            [`cubone`, `gastly`, `drowzee`, `clefairy`, `mrmime`],
            B,
            V,
          ),
        ),
        H(
          7,
          P(
            `lav-p7`,
            `Fantasmas`,
            [8, 4, 1],
            [`gastly`, `cubone`, `zubat`, `koffing`],
            B,
            V,
          ),
        ),
        H(
          7,
          An(
            `lav-fuji`,
            `Sr. Fuji`,
            `El Sr. Fuji`,
            `Sr. Fuji`,
            `gentleman-gen1`,
            `¡Gracias! Los Rocket me quitaron el Visor Silph: con él se ve a los fantasmas.`,
            [
              { label: `Desatarle ya`, gain: { hp: 15, xp: 2 } },
              {
                label: `Registrar el botín Rocket`,
                hpCost: 8,
                gain: { key: `silph-scope`, gold: 4 },
              },
            ],
            B,
          ),
        ),
        H(7, {
          ...I(`lav-puesto`, `Puesto de incienso`, [`mall`], B, V),
          eventTitle: `Puesto de incienso`,
        }),
        H(
          7,
          F(
            `lav-espiritu`,
            `Espíritu de la Médium`,
            `channeler-gen1`,
            `¡Ningún… vivo… pasará…!`,
            [8, 5, 1],
            [
              `gastly`,
              `gastly`,
              `jynx`,
              `mrmime`,
              `drowzee`,
              `gastly`,
              `koffing`,
              `grimer`,
            ],
            B,
            V,
          ),
        ),
        H(7, {
          id: `lav-marowak`,
          name: `Fantasma de Marowak`,
          boss: !0,
          wow: `marowak`,
          battleMusic: `mus_rg_lavender`,
          intro: `¡Vete… vete de aquí!`,
          team: [{ line: `snorlax`, star: 2, boss: Gn }],
          bg: B,
          music: V,
          bossKey: {
            key: `silph-scope`,
            boss: { hidden: !1, unveiled: !0, hp: 46e3 },
          },
        }),
      ]),
      (qn = [
        {
          name: `Lavanda`,
          full: `Ruta 10 y Pueblo Lavanda`,
          from: 0,
          to: 8,
          lossBase: 3,
          floor: !0,
          music: `mus_rg_route11`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_trainer`,
        },
        {
          name: `Torre`,
          full: `Torre Pokémon`,
          from: 9,
          to: 18,
          lossBase: 5,
          floor: !1,
          music: `mus_rg_poke_tower`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_gym_leader`,
        },
        {
          name: `Cima`,
          full: `Cima de la Torre`,
          from: 19,
          to: 24,
          lossBase: 8,
          floor: !1,
          music: `mus_rg_poke_tower`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_gym_leader`,
        },
      ]),
      (Jn = [
        `bulbasaur`,
        `eevee`,
        `electabuzz`,
        `growlithe`,
        `hitmonchan`,
        `hitmonlee`,
        `magmar`,
        `nidoran`,
        `oddish`,
        `paras`,
        `poliwag`,
        `sandshrew`,
        `tauros`,
      ]),
      (Yn = [
        `bellsprout`,
        `clefairy`,
        `drowzee`,
        `grimer`,
        `kangaskhan`,
        `koffing`,
        `mankey`,
        `meowth`,
        `mrmime`,
        `nidoranf`,
        `pinsir`,
        `tangela`,
        `venonat`,
      ]),
      (Xn = [`gastly`, `cubone`, `drowzee`, `clefairy`, `mrmime`]),
      (Zn = {
        trainer: `channeler-gen1`,
        name: `Médium`,
        intro: `Pueblo Lavanda… Dicen que en la torre hay fantasmas. Elige a tu compañero.`,
      }),
      (Qn = [
        {
          at: `lav-r10`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `El Team Rocket se ha llevado al Sr. Fuji a la cima de la torre.`,
        },
        {
          at: `lav-medium1`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `Hay un fantasma en la torre que no deja pasar a nadie…`,
        },
        {
          at: `lav-azul`,
          trainer: `blue-gen1`,
          who: `Azul`,
          text: `¿Tú aquí? Venía a ver a mi Raticate… ¡Te enseñaré lo que he aprendido!`,
        },
        {
          at: `lav-p3`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `Ese fantasma… dicen que es la madre de una Cubone.`,
        },
        {
          at: `lav-lib`,
          trainer: `teamrocketgruntm-gen3`,
          who: `Jefe Rocket`,
          text: `¡Quedaos con el viejo! Total, ese fantasma no deja bajar a nadie…`,
        },
        {
          at: `lav-p7`,
          trainer: `gentleman-gen1`,
          who: `Sr. Fuji`,
          text: `¡Socorro! ¡Estoy arriba!`,
        },
        {
          at: `lav-tienda`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `Última compra antes de subir: en la torre no hay vuelta atrás.`,
        },
        {
          at: `lav-purificada`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `Aquí los espíritus no entran. Descansa un poco.`,
        },
        {
          at: `lav-puesto`,
          trainer: `channeler-gen1`,
          who: `Médium`,
          text: `Incienso y velas para la cima. Llévate lo que necesites.`,
        },
        {
          at: `lav-espiritu`,
          trainer: `gentleman-gen1`,
          who: `Sr. Fuji`,
          text: `¡Cuidado! Un espíritu se ha metido en esa Médium.`,
        },
      ]),
      ($n = {
        trainer: `gentleman-gen1`,
        who: `Sr. Fuji`,
        text: `La madre de Cubone por fin descansa. Toma mi Poké Flauta: en la Ruta 12 duerme un Snorlax…`,
      }),
      m([
        [`Noche en Lavanda`, `Night in Lavender`],
        [`La Torre Pokémon de noche`, `Pokémon Tower by night`],
        [`Pueblo Lavanda`, `Lavender Town`],
        [`Ruta 10 y Pueblo Lavanda`, `Route 10 and Lavender Town`],
        [`Lavanda`, `Lavender`],
        [`Torre`, `Tower`],
        [`Cima`, `Top`],
        [`Cima de la Torre`, `Top of the Tower`],
        [`Médium`, `Channeler`],
        [`Médium poseída`, `Possessed Channeler`],
        [`Fantasmas`, `Ghosts`],
        [`Lápida`, `Grave`],
        [`Zona purificada`, `Purified Zone`],
        [`Recluta Rocket`, `Rocket Grunt`],
        [`Jefe Rocket`, `Rocket Boss`],
        [`Fantasma de Marowak`, `Marowak Ghost`],
        [`Sr. Fuji`, `Mr. Fuji`],
        [`Niño de Lavanda`, `Lavender Kid`],
        [`Tienda de Lavanda`, `Lavender Mart`],
        [`Tienda`, `Mart`],
        [`La Cubone huérfana`, `The orphaned Cubone`],
        [
          `Esta Cubone perdió a su madre en la torre. Nadie la cuida…`,
          `This Cubone lost its mother in the tower. No one looks after it…`,
        ],
        [`Llevártela`, `Take it with you`],
        [`Dejarle comida`, `Leave it some food`],
        [`La lápida sin nombre`, `The nameless grave`],
        [
          `Aquí descansa un Pokémon sin nombre. ¿Qué haces?`,
          `A nameless Pokémon rests here. What do you do?`,
        ],
        [`Rezar`, `Pray`],
        [`Dejar una ofrenda`, `Leave an offering`],
        [`La Médium poseída`, `The possessed Channeler`],
        [
          `¡Fuera… de… aquí…! (Un espíritu la tiene atrapada.)`,
          `Get… out… (A spirit has her trapped.)`,
        ],
        [`Ahuyentar al espíritu`, `Drive the spirit away`],
        [`Pagar un ritual`, `Pay for a ritual`],
        [`Pasar de largo`, `Walk on by`],
        [`El Sr. Fuji`, `Mr. Fuji`],
        [
          `¡Gracias por venir! Pero el fantasma de la cima… ten cuidado.`,
          `Thank you for coming! But the ghost at the top… be careful.`,
        ],
        [`Desatarle ya`, `Untie him now`],
        [`Registrar el botín Rocket`, `Search the Rocket loot`],
        [`¡Una Médium quiere luchar!`, `You are challenged by Channeler!`],
        [
          `¡Nadie sube a la torre! Órdenes del jefe.`,
          `Nobody goes up the tower! Boss’s orders.`,
        ],
        [
          `¡El jefe está arriba con el viejo! No pasarás.`,
          `The boss is upstairs with the old man! You won't pass.`,
        ],
        [
          `¡El Sr. Fuji no se irá hasta que hable! ¡Fuera!`,
          `Mr. Fuji isn't going anywhere until he talks! Get lost!`,
        ],
        [`¡Vete… vete de aquí!`, `Be gone… intruder…`],
        [
          `Pueblo Lavanda… Dicen que en la torre hay fantasmas. Elige a tu compañero.`,
          `Lavender Town… They say the tower is haunted. Choose your partner.`,
        ],
        [
          `El Team Rocket se ha llevado al Sr. Fuji a la cima de la torre.`,
          `Team Rocket has taken Mr. Fuji to the top of the tower.`,
        ],
        [
          `Hay un fantasma en la torre que no deja pasar a nadie…`,
          `There's a ghost in the tower that lets no one through…`,
        ],
        [
          `¿Tú aquí? Venía a ver a mi Raticate… ¡Te enseñaré lo que he aprendido!`,
          `You? I came to see my Raticate… I'll show you what I've learned!`,
        ],
        [
          `Ese fantasma… dicen que es la madre de una Cubone.`,
          `That ghost… they say it is a Cubone’s mother.`,
        ],
        [
          `¡Quedaos con el viejo! Total, ese fantasma no deja bajar a nadie…`,
          `Keep the old man! That ghost lets no one down anyway…`,
        ],
        [`¡Socorro! ¡Estoy arriba!`, `Help! I'm up here!`],
        [
          `La madre de Cubone por fin descansa. Toma mi Poké Flauta: en la Ruta 12 duerme un Snorlax…`,
          `Cubone's mother can finally rest. Take my Poké Flute: a Snorlax sleeps on Route 12…`,
        ],
        [`Cubone`, `Cubone`],
        [`Objeto combinado`, `Completed item`],
        [`Componente`, `Component`],
        [`PS`, `HP`],
        [`Elegir`, `Choose`],
        [`Decisión`, `Decision`],
      ]),
      Tn(U, qn),
      (er = [
        `Torre Pokémon · Entrada`,
        `Torre Pokémon · Planta`,
        `Torre Pokémon · Cima`,
      ]),
      qn.forEach((e, t) => {
        for (let n = e.from; n <= e.to; n++)
          U[n].name.startsWith(`Torre Pokémon`) && (U[n].scene = er[t]);
      }));
    for (let e of U)
      [`lav-r8`, `lav-oak`, `lav-centro`, `lav-cubone`, `lav-tienda`].includes(
        e.id,
      ) && (e.scene = `Pueblo Lavanda · Noche`);
    for (let e of U) {
      let t = parseInt(e.floor ?? ``, 10);
      t && (e.fog = Math.round((0.2 + (0.4 * (t - 1)) / 6) * 100) / 100);
    }
    ((U.find((e) => e.id === `lav-espiritu`).fog = 0.8),
      (tr = [
        {
          id: `intro`,
          at: `start`,
          style: `strip`,
          go: `iris`,
          panels: [
            { bg: `bg-river`, fx: `night`, cast: [j(`red-gen1`, `c`, `dots`)] },
            {
              bg: `bg-route`,
              fx: `night`,
              cast: [j(`red-gen1`, `l`, `!`), j(`channeler-gen1`, `r`, `fear`)],
              line: `¡Se han llevado al Sr. Fuji a la torre!`,
            },
            {
              bg: `scenes/lavanda-noche.webp`,
              focus: `56% 62%`,
              fx: `fog`,
              cast: [
                M(`gastly`, `l`, `joy`),
                j(`teamrocketgruntm-gen3`, `c`, `angry`),
                M(`gastly`, `r`, `dots`),
              ],
            },
          ],
        },
        {
          id: `cubone`,
          at: `lav-cubone`,
          style: `panel`,
          panels: [
            {
              bg: `scenes/lavanda-noche.webp`,
              focus: `30% 62%`,
              fx: `night`,
              cast: [M(`cubone`, `c`, `fear`)],
            },
          ],
        },
        {
          id: `jefe-cae`,
          at: `lav-lib`,
          style: `panel`,
          panels: [
            {
              bg: `scenes/torre-interior.webp`,
              fx: `fog`,
              cast: [
                j(`teamrocketgruntm-gen3`, `l`, `angry`),
                M(`cubone`, `c`, `joy`),
                M(`drowzee`, `r`, `joy`),
              ],
            },
          ],
        },
        {
          id: `fantasma`,
          at: `lav-marowak`,
          style: `panel`,
          go: `iris`,
          when: { line: [`cubone`], in: `team`, not: !0 },
          panels: [
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `fog`,
              cast: [
                j(`red-gen1`, `l`, `fear`),
                {
                  who: `boss/ghost.png`,
                  kind: `img`,
                  side: `r`,
                  gesture: `dots`,
                  scale: 1.1,
                },
              ],
            },
          ],
        },
        {
          id: `fantasma-cubone`,
          at: `lav-marowak`,
          style: `panel`,
          go: `iris`,
          when: { line: [`cubone`], in: `team` },
          panels: [
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `fog`,
              cast: [
                j(`red-gen1`, `l`, `fear`),
                M(`cubone`, `c`, `?`),
                {
                  who: `boss/ghost.png`,
                  kind: `img`,
                  side: `r`,
                  gesture: `dots`,
                  scale: 1.1,
                },
              ],
            },
          ],
        },
        {
          id: `madre`,
          at: `lav-marowak:win`,
          style: `panel`,
          go: `fade`,
          when: { line: [`cubone`] },
          panels: [
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `night`,
              cast: [
                M(`cubone`, `l`, `love`),
                {
                  who: `boss/ghost.png`,
                  kind: `img`,
                  side: `r`,
                  gesture: `love`,
                  scale: 0.9,
                },
              ],
              line: `La madre de Cubone la ha reconocido.`,
            },
          ],
        },
        {
          id: `nudo`,
          at: `lav-p5`,
          style: `strip`,
          panels: [
            {
              bg: `scenes/torre-interior.webp`,
              fx: `fog`,
              cast: [j(`channeler-gen1`, `c`, `fear`)],
            },
            {
              bg: `scenes/torre-interior.webp`,
              fx: `fog`,
              cast: [
                M(`gastly`, `l`, `angry`),
                M(`cubone`, `c`, `fear`),
                M(`gastly`, `r`, `angry`, { flip: !0 }),
              ],
            },
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `night`,
              cast: [
                j(`teamrocketgruntm-gen3`, `l`, `angry`),
                j(`gentleman-gen1`, `r`, `fear`),
              ],
              line: `¡El Sr. Fuji está arriba!`,
            },
          ],
        },
        {
          id: `fin`,
          at: `end`,
          style: `strip`,
          go: `iris`,
          when: { line: [`cubone`], not: !0 },
          panels: [
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `night`,
              cast: [
                M(`cubone`, `l`, `fear`),
                {
                  who: `boss/ghost.png`,
                  kind: `img`,
                  side: `r`,
                  gesture: `joy`,
                  scale: 0.9,
                },
              ],
            },
            {
              bg: `scenes/torre-interior.webp`,
              cast: [
                j(`red-gen1`, `l`, `joy`),
                j(`gentleman-gen1`, `r`, `joy`),
              ],
            },
            {
              bg: `scenes/lavanda-noche.webp`,
              fx: `dawn`,
              cast: [M(`cubone`, `c`, `joy`)],
            },
          ],
        },
        {
          id: `fin-juntas`,
          at: `end`,
          style: `strip`,
          go: `iris`,
          when: { line: [`cubone`] },
          panels: [
            {
              bg: `scenes/torre-cima-noche.webp`,
              fx: `dawn`,
              cast: [
                {
                  who: `boss/ghost.png`,
                  kind: `img`,
                  side: `c`,
                  gesture: `joy`,
                  scale: 0.8,
                },
              ],
              line: `Ya puede descansar en paz.`,
            },
            {
              bg: `scenes/torre-interior.webp`,
              cast: [
                j(`red-gen1`, `l`, `joy`),
                j(`gentleman-gen1`, `r`, `joy`),
              ],
            },
            {
              bg: `scenes/lavanda-noche.webp`,
              fx: `dawn`,
              cast: [
                j(`red-gen1`, `l`, `joy`),
                M(`cubone`, `r`, `love`, { flip: !0 }),
              ],
            },
          ],
        },
      ]),
      m([
        ...[1, 2, 3, 4, 5, 6, 7].map((e) => [`${e}F`, `${e}F`]),
        [`Puesto de incienso`, `Incense stall`],
        [`Espíritu de la Médium`, `Channeler's spirit`],
        [`¡Ningún… vivo… pasará…!`, `No… living… soul… shall pass…`],
        [
          `Última compra antes de subir: en la torre no hay vuelta atrás.`,
          `Last shopping before you climb: there's no turning back in the tower.`,
        ],
        [
          `Incienso y velas para la cima. Llévate lo que necesites.`,
          `Incense and candles for the top. Take what you need.`,
        ],
        [
          `¡Cuidado! Un espíritu se ha metido en esa Médium.`,
          `Careful! A spirit has taken hold of that Channeler.`,
        ],
      ]),
      m([
        [
          `¡Se han llevado al Sr. Fuji a la torre!`,
          `They took Mr. Fuji to the tower!`,
        ],
        [`Ruta 10`, `Route 10`],
        [`Camino a Lavanda`, `Road to Lavender`],
        [`Entrada`, `Entrance`],
        [`Pisos superiores`, `Upper floors`],
      ]),
      m([
        [`¡El Sr. Fuji está arriba!`, `Mr. Fuji is upstairs!`],
        [
          `Aquí los espíritus no entran. Descansa un poco.`,
          `Spirits can't come in here. Rest a while.`,
        ],
      ]),
      m([
        [
          `¡Gracias! Los Rocket me quitaron el Visor Silph: con él se ve a los fantasmas.`,
          `Thank you! Team Rocket took my Silph Scope: with it, you can see ghosts.`,
        ],
        [
          `La madre de Cubone la ha reconocido.`,
          `Cubone's mother has recognized her.`,
        ],
        [`Ya puede descansar en paz.`, `Now she can rest in peace.`],
      ]),
      (nr = { host: `channeler-gen1`, name: `Médium` }),
      En(U, {
        "lav-tienda": {
          say: `Última compra antes de subir: en la torre no hay vuelta atrás.`,
        },
        "lav-purificada": {
          ...nr,
          say: `Aquí los espíritus no entran. Descansa un poco.`,
          icon: `item:cleanse-tag`,
          bg: `scenes/torre-interior.webp`,
        },
        "lav-lib": {
          icon: `item:poke-ball`,
          bg: `scenes/torre-cima-noche.webp`,
        },
        "lav-puesto": {
          ...nr,
          say: `Incienso y velas para la cima. Llévate lo que necesites.`,
          icon: `item:pure-incense`,
          bg: `scenes/torre-cima-noche.webp`,
        },
      }),
      On(
        { rounds: U, story: Qn, scenes: tr },
        {
          sprites: {
            rocketgrunt: `cueball-gen3`,
            rocketgruntf: `cueball-gen1rb`,
            "teamrocketgruntm-gen3": `rocker-gen3`,
          },
          who: {
            "Recluta Rocket": `Matón`,
            "Jefe Rocket": `Jefe de los matones`,
          },
          text: {
            "El Team Rocket se ha llevado al Sr. Fuji a la cima de la torre.": `Unos matones se han llevado al Sr. Fuji a la cima de la torre.`,
            "Registrar el botín Rocket": `Registrar el botín de los matones`,
          },
        },
      ),
      m([
        [`Matón`, `Thug`],
        [`Jefe de los matones`, `Thug boss`],
        [`Registrar el botín de los matones`, `Search the thugs' loot`],
        [
          `Unos matones se han llevado al Sr. Fuji a la cima de la torre.`,
          `Some thugs have taken Mr. Fuji to the top of the tower.`,
        ],
      ]));
  }))();
}
var ir;
function ar() {
  return (ar = e(() => {
    (wn(),
      o(),
      (ir = [
        {
          id: `intro`,
          at: `start`,
          style: `strip`,
          go: `iris`,
          panels: [
            {
              bg: `bg-route`,
              cast: [j(`oak-gen1`, `c`, `!`)],
              line: `Tu viaje empieza hoy.`,
            },
            {
              bg: `bg-route`,
              cast: [
                j(`blue-gen1`, `l`, `joy`),
                Sn(`rival`, `c`, `!`),
                j(`red-gen1`, `r`, `angry`),
              ],
              line: `¡Me quedo este, que le gana al tuyo!`,
            },
            {
              bg: `bg-route`,
              cast: [
                Sn(`rival`, `l`, `angry`),
                Sn(`starter`, `r`, `joy`, { flip: !0 }),
              ],
            },
          ],
        },
        {
          id: `azul-celeste`,
          at: `azul`,
          style: `panel`,
          panels: [
            {
              bg: `bg-city`,
              cast: [j(`blue-gen1`, `c`, `joy`)],
              line: `Huele a novato.`,
            },
          ],
        },
        {
          id: `escondite`,
          at: `escondite`,
          style: `panel`,
          panels: [
            {
              bg: `scenes/escondite-rocket.webp`,
              fx: `night`,
              cast: [
                j(`rocketgrunt`, `l`, `joy`),
                j(`giovanni-gen1rb`, `r`, void 0, { shadow: !0 }),
              ],
              line: `El jefe lo quiere todo.`,
            },
          ],
        },
        {
          id: `giovanni`,
          at: `giovanni`,
          style: `strip`,
          go: `iris`,
          panels: [
            {
              bg: `bg-desert`,
              cast: [
                j(`rocketgrunt`, `l`, `dots`),
                j(`giovanni-gen1rb`, `r`, void 0, { shadow: !0 }),
              ],
            },
            {
              bg: `bg-desert`,
              cast: [j(`giovanni-gen1rb`, `c`, `!`)],
              line: `Sí: el jefe del Team Rocket soy yo.`,
            },
          ],
        },
        {
          id: `giovanni-cae`,
          at: `giovanni:win`,
          style: `panel`,
          panels: [
            {
              bg: `bg-desert`,
              cast: [j(`giovanni-gen1rb`, `c`, `dots`, { flip: !0 })],
              line: `Se acabó el Team Rocket.`,
            },
          ],
        },
        {
          id: `azul-r22`,
          at: `ruta22`,
          style: `panel`,
          panels: [
            {
              bg: `bg-route`,
              cast: [j(`blue-gen1`, `l`, `angry`), j(`red-gen1`, `r`, `dots`)],
              line: `¡Llegaré a la Liga antes que tú!`,
            },
          ],
        },
        {
          id: `campeon`,
          at: `campeon`,
          style: `panel`,
          go: `iris`,
          panels: [
            {
              bg: `bg-city`,
              cast: [j(`blue-gen1champion`, `c`, `!`)],
              line: `¡Llegaste tarde! El Campeón soy yo.`,
            },
          ],
        },
        {
          id: `salon`,
          at: `mewtwo`,
          style: `strip`,
          go: `iris`,
          panels: [
            {
              bg: `bg-city`,
              fx: `dawn`,
              cast: [
                j(`oak-gen1`, `l`, `joy`),
                Sn(`bird`, `c`, `joy`),
                j(`red-gen1`, `r`, `joy`),
              ],
              line: `¡Bienvenido al Salón de la Fama!`,
            },
            {
              bg: `bg-space`,
              fx: `night`,
              cast: [M(`mewtwo`, `c`, void 0, { scale: 1.1, shadow: !0 })],
            },
            { bg: `bg-space`, cast: [M(`mewtwo`, `c`, `!`, { scale: 1.1 })] },
          ],
        },
        {
          id: `fin`,
          at: `end`,
          style: `panel`,
          go: `fade`,
          panels: [
            {
              bg: `scenes/lavanda-noche.webp`,
              fx: `night`,
              cast: [j(`channeler-gen1`, `c`, `dots`)],
              line: `En Lavanda pasan cosas de noche…`,
            },
          ],
        },
      ]),
      m([
        [`Tu viaje empieza hoy.`, `Your journey starts today.`],
        [
          `¡Me quedo este, que le gana al tuyo!`,
          `I'll take this one. It beats yours!`,
        ],
        [`Huele a novato.`, `Smells like a rookie.`],
        [`El jefe lo quiere todo.`, `The boss wants it all.`],
        [
          `Sí: el jefe del Team Rocket soy yo.`,
          `Yes: I'm the boss of Team Rocket.`,
        ],
        [`Se acabó el Team Rocket.`, `Team Rocket is finished.`],
        [
          `¡Llegaré a la Liga antes que tú!`,
          `I'll reach the League before you!`,
        ],
        [
          `¡Llegaste tarde! El Campeón soy yo.`,
          `You're too late! I'm the Champion.`,
        ],
        [`¡Bienvenido al Salón de la Fama!`, `Welcome to the Hall of Fame!`],
        [
          `En Lavanda pasan cosas de noche…`,
          `Strange things happen in Lavender at night…`,
        ],
      ]));
  }))();
}
var or,
  W,
  sr,
  G,
  cr,
  K,
  lr,
  q,
  ur,
  dr,
  fr,
  pr,
  mr,
  hr,
  gr,
  _r,
  vr,
  yr,
  br,
  xr,
  Sr,
  Cr,
  wr,
  Tr,
  Er,
  Dr;
function Or() {
  return (Or = e(() => {
    (o(),
      wn(),
      Ne(),
      jn(),
      (or = `mus_rg_celadon`),
      (W = `bg-gen4-indoors`),
      (sr = `mus_rg_game_corner`),
      (G = `bg-gen4-indoors`),
      (cr = `mus_rg_victory_road`),
      (K = `giovanni-gen1rb`),
      (lr = `gentleman-gen3`),
      (q = [
        P(
          `roc-r7`,
          `Ruta 7 · Pokémon salvajes`,
          [1, 0, 0],
          [`magikarp`],
          `bg-route`,
          or,
        ),
        F(
          `roc-jugador`,
          `Ciudad Azulona · Jugador`,
          `gambler-gen1`,
          `¡Un Jugador quiere luchar!`,
          [2, 0, 0],
          [`meowth`, `rattata`],
          `bg-city`,
          or,
        ),
        I(
          `roc-oak`,
          `Ciudad Azulona · Profesor Oak`,
          [`oak`],
          `bg-city`,
          `mus_rg_oak`,
        ),
        P(
          `roc-r16`,
          `Ruta 16 · Pokémon salvajes`,
          [3, 1, 0],
          [`meowth`, `doduo`, `rattata`],
          `bg-route`,
          or,
        ),
        An(
          `roc-dojo`,
          `Ciudad Azafrán · Dojo Karate`,
          `El Dojo Karate`,
          `Maestro Karateka`,
          `blackbelt-gen1`,
          `¡Has vencido a mis alumnos! Llévate uno de mis luchadores.`,
          [
            { label: `Hitmonlee`, gain: { mon: `hitmonlee` } },
            { label: `Hitmonchan`, gain: { mon: `hitmonchan` } },
          ],
          `bg-gen4-indoors`,
          `mus_rg_gym`,
        ),
        F(
          `roc-karateka`,
          `Ciudad Azafrán · Karateka`,
          `blackbelt-gen1`,
          `¡Un Karateka quiere luchar!`,
          [4, 1, 0],
          [`mankey`, `machop`, `mankey`],
          `bg-gen4-indoors`,
          `mus_rg_gym`,
        ),
        I(
          `roc-centro`,
          `Ciudad Azulona · Centro Pokémon`,
          [`center`],
          `bg-city`,
          `mus_rg_poke_center`,
        ),
        {
          ...I(
            `roc-casino`,
            `Ciudad Azulona · Casino`,
            [`shop`],
            `bg-city`,
            sr,
          ),
          scene: `Casino`,
          slotJackpot: `porygon`,
        },
        L(
          `roc-cartel`,
          `Casino · Recluta Rocket`,
          `rocketgrunt`,
          `¡No mires el cartel! Aquí no hay nada que ver.`,
          [5, 3, 0],
          [`rattata`, `zubat`, `ekans`, `sandshrew`],
          W,
        ),
        {
          ...L(
            `roc-azul`,
            `Casino · Rival Azul`,
            `blue-gen1`,
            `¡Tu rival Azul quiere luchar!`,
            [6, 3, 0],
            [`squirtle`, `pidgey`, `abra`, `rattata`, `eevee`],
            `bg-city`,
            `mus_rg_encounter_rival`,
          ),
          introStyle: `gym`,
        },
        L(
          `roc-b1`,
          `Escondite Rocket · B1 · Recluta`,
          `rocketgruntf`,
          `¡Una intrusa! ¡A por ella!`,
          [6, 3, 0],
          [`sandshrew`, `grimer`, `zubat`, `meowth`],
          W,
        ),
        F(
          `roc-b2`,
          `Escondite Rocket · B2 · Recluta`,
          `rocketgrunt`,
          `¡Un recluta del Team Rocket!`,
          [7, 3, 0],
          [`ekans`, `drowzee`, `koffing`, `rattata`, `zubat`],
          W,
          sr,
        ),
        An(
          `roc-arrepentido`,
          `Escondite Rocket · B2 · Recluta`,
          `El recluta arrepentido`,
          `Recluta Rocket`,
          `rocketgrunt`,
          `Quiero dejar el Team Rocket… Toma, pero no digas que fui yo.`,
          [
            { label: `Dejarle huir`, gain: { xp: 4, hp: 6 } },
            {
              label: `Quitarle la Llave Ascensor`,
              hpCost: 10,
              gain: { full: 1, gold: 4 },
            },
          ],
          W,
          sr,
        ),
        P(
          `roc-b3`,
          `Escondite Rocket · B3 · Pokémon de laboratorio`,
          [7, 3, 0],
          [`grimer`, `koffing`, `porygon`, `drowzee`],
          W,
          sr,
        ),
        {
          ...I(
            `roc-tienda`,
            `Escondite Rocket · B3 · Almacén Rocket`,
            [`mall`],
            W,
            sr,
          ),
          eventTitle: `Almacén Rocket`,
        },
        F(
          `roc-b4`,
          `Escondite Rocket · B4 · Recluta`,
          `rocketgrunt`,
          `¡Un recluta del Team Rocket!`,
          [8, 3, 1],
          [`ekans`, `grimer`, `mankey`, `drowzee`, `cubone`],
          W,
          sr,
        ),
        {
          ...I(
            `roc-centro2`,
            `Escondite Rocket · B4 · Enfermería Rocket`,
            [`center`],
            W,
            `mus_rg_poke_center`,
          ),
          eventTitle: `Enfermería Rocket`,
        },
        L(
          `roc-b4b`,
          `Escondite Rocket · B4 · Guardia`,
          `teamrocketgruntm-gen3`,
          `¡Nadie pasa al despacho del jefe!`,
          [8, 4, 0],
          [`sandshrew`, `grimer`, `ekans`, `drowzee`, `meowth`],
          W,
        ),
        {
          id: `roc-giovanni1`,
          name: `Escondite Rocket · B4 · Giovanni`,
          boss: !0,
          canLose: !0,
          scene: `Escondite Rocket`,
          introStyle: `gym`,
          trainer: K,
          intro: `¡Giovanni, el jefe del Team Rocket!`,
          team: [
            N(`onix`, 2),
            N(`rhyhorn`, 2),
            N(`kangaskhan`),
            N(`meowth`, 2),
            N(`cubone`, 2),
            N(`nidoran`),
            N(`nidoranf`),
          ],
          bg: W,
          music: sr,
        },
        kn(
          `roc-lib`,
          `Escondite Rocket · B4 · Pokémon liberados`,
          [`eevee`, `porygon`, `kangaskhan`, `mrmime`, `drowzee`],
          W,
          sr,
        ),
        L(
          `roc-silph1`,
          `Silph S.A. · P1 · Recluta Rocket`,
          `rocketgruntf`,
          `¡Silph es nuestra! ¡Fuera de aquí!`,
          [8, 3, 1],
          [`grimer`, `sandshrew`, `meowth`, `mankey`, `zubat`],
          G,
        ),
        An(
          `roc-puertas`,
          `Silph S.A. · P3 · Puertas cerradas`,
          `Las puertas cerradas`,
          `Científico de Silph`,
          `scientist-gen1`,
          `Los Rocket han cerrado todas las puertas. Hay un teletransportador…`,
          [
            { label: `Subir por las escaleras`, hpCost: 8, gain: { xp: 6 } },
            {
              label: `Arriesgar el teletransportador`,
              cost: 6,
              gain: { hp: 8, part: 1 },
            },
          ],
          G,
          cr,
        ),
        F(
          `roc-cientifico`,
          `Silph S.A. · P5 · Científico`,
          `scientist-gen1`,
          `¡Un Científico quiere luchar!`,
          [8, 4, 2],
          [`porygon`, `koffing`, `grimer`, `magnemite`, `voltorb`],
          G,
          cr,
        ),
        {
          ...I(
            `roc-curacion`,
            `Silph S.A. · P6 · Sala de descanso`,
            [`center`],
            G,
            `mus_rg_poke_center`,
          ),
          eventTitle: `Sala de descanso`,
        },
        F(
          `roc-silph2`,
          `Silph S.A. · P7 · Recluta Rocket`,
          `rocketgrunt`,
          `¡Un recluta del Team Rocket!`,
          [8, 5, 2],
          [`ekans`, `drowzee`, `cubone`, `mankey`, `kangaskhan`],
          G,
          cr,
        ),
        {
          id: `roc-azul2`,
          name: `Silph S.A. · P9 · Rival Azul`,
          boss: !0,
          introStyle: `gym`,
          intro: `¡Tu rival Azul quiere luchar!`,
          trainer: `blue-gen1`,
          team: Ie(
            [
              `squirtle`,
              `pidgey`,
              `abra`,
              `eevee`,
              `exeggcute`,
              `rattata`,
              `cubone`,
            ],
            [8, 5, 1],
          ),
          bg: G,
          music: `mus_rg_encounter_rival`,
        },
        An(
          `roc-presidente`,
          `Silph S.A. · P11 · Presidente`,
          `El presidente de Silph`,
          `Presidente de Silph`,
          lr,
          `¡Gracias! Elige un regalo: un Lapras… o nuestro invento secreto.`,
          [
            { label: `Lapras`, gain: { mon: `lapras` } },
            { label: `El invento secreto`, gain: { full: 1, part: 1 } },
          ],
          G,
          cr,
        ),
        {
          ...I(`roc-tienda2`, `Silph S.A. · P11 · Almacén`, [`mall`], G, cr),
          eventTitle: `Almacén de Silph`,
        },
        L(
          `roc-silph3`,
          `Silph S.A. · P11 · Guardaespaldas`,
          `teamrocketgruntm-gen3`,
          `¡El jefe no recibe visitas!`,
          [8, 5, 2],
          [`grimer`, `koffing`, `drowzee`, `kangaskhan`, `meowth`, `onix`],
          G,
        ),
        {
          id: `roc-giovanni`,
          name: `Silph S.A. · P11 · Giovanni`,
          boss: !0,
          battleMusic: `mus_rg_vs_champion`,
          scene: `Silph S.A. · Despacho`,
          introStyle: `gym`,
          trainer: K,
          intro: `¡Otra vez tú! Esta vez no habrá clemencia.`,
          team: [
            N(`rhyhorn`, 3),
            N(`meowth`, 3),
            N(`kangaskhan`, 2),
            N(`nidoran`, 2),
            N(`nidoranf`, 2),
            N(`onix`, 2),
            N(`cubone`, 3),
            N(`diglett`, 2),
          ],
          bg: G,
          music: cr,
        },
      ]),
      (ur = [
        {
          name: `Azulona`,
          full: `Ciudad Azulona`,
          from: 0,
          to: 9,
          lossBase: 4,
          floor: !0,
          music: `mus_rg_celadon`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_trainer`,
        },
        {
          name: `Escondite`,
          full: `Escondite Rocket`,
          from: 10,
          to: 19,
          lossBase: 7,
          floor: !1,
          music: `mus_rg_rocket_hideout`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_gym_leader`,
        },
        {
          name: `Silph`,
          full: `Silph S.A.`,
          from: 20,
          to: 29,
          lossBase: 10,
          floor: !1,
          music: `mus_rg_silph`,
          battle: `mus_rg_vs_trainer`,
          boss: `mus_rg_vs_gym_leader`,
        },
      ]),
      (dr = [
        `bulbasaur`,
        `chansey`,
        `exeggcute`,
        `gastly`,
        `growlithe`,
        `jigglypuff`,
        `jynx`,
        `magmar`,
        `oddish`,
        `pidgey`,
        `poliwag`,
        `psyduck`,
        `seel`,
        `slowpoke`,
      ]),
      (fr = [
        `bellsprout`,
        `clefairy`,
        `drowzee`,
        `grimer`,
        `kangaskhan`,
        `koffing`,
        `mankey`,
        `meowth`,
        `mrmime`,
        `nidoranf`,
        `pinsir`,
        `porygon`,
        `tangela`,
        `venonat`,
      ]),
      (pr = [`eevee`, `porygon`, `kangaskhan`, `mrmime`, `drowzee`]),
      (mr = {
        trainer: `erika-gen1`,
        name: `Erika`,
        intro: `El Team Rocket se esconde en Ciudad Azulona. Necesito tu ayuda. Elige a tu compañero.`,
      }),
      (hr = [
        {
          at: `roc-r7`,
          trainer: `erika-gen1`,
          who: `Erika`,
          text: `Los furtivos del Safari trabajaban para el Team Rocket. Su guarida está aquí.`,
        },
        {
          at: `roc-casino`,
          trainer: `gentleman-gen1`,
          who: `Encargado del Casino`,
          text: `¡Hoy hay premio gordo! Tres sietes y te llevas un Porygon.`,
        },
        {
          at: `roc-cartel`,
          trainer: `rocketgrunt`,
          who: `Recluta Rocket`,
          text: `¡Nadie debe saber lo que hay detrás del cartel del Casino!`,
        },
        {
          at: `roc-b1`,
          trainer: `erika-gen1`,
          who: `Erika`,
          text: `Detrás del cartel hay una escalera. ¡Ten cuidado ahí abajo!`,
        },
        {
          at: `roc-giovanni1`,
          trainer: K,
          who: `Giovanni`,
          text: `¿Un crío en mi escondite? Te enseñaré a respetar al Team Rocket.`,
        },
        {
          at: `roc-lib`,
          trainer: K,
          who: `Giovanni`,
          text: `Quédate con esos Pokémon. Silph S.A. ya es nuestra.`,
        },
        {
          at: `roc-silph1`,
          trainer: `scientist-gen1`,
          who: `Científico de Silph`,
          text: `¡Han tomado el edificio y tienen al presidente en la planta 11!`,
        },
        {
          at: `roc-azul2`,
          trainer: `blue-gen1`,
          who: `Azul`,
          text: `¿Tú también aquí? ¡Yo llegué primero!`,
        },
        {
          at: `roc-silph3`,
          trainer: lr,
          who: `Presidente de Silph`,
          text: `¡Giovanni quiere la Master Ball! ¡No le dejes salirse con la suya!`,
        },
        {
          at: `roc-tienda`,
          trainer: `erika-gen1`,
          who: `Erika`,
          text: `Un almacén del Team Rocket sin vigilar. ¡Coge lo que te haga falta!`,
        },
        {
          at: `roc-centro2`,
          trainer: `erika-gen1`,
          who: `Erika`,
          text: `La enfermería Rocket está vacía. Recupérate: Giovanni está cerca.`,
        },
        {
          at: `roc-curacion`,
          trainer: `scientist-gen1`,
          who: `Científico de Silph`,
          text: `Descansa aquí, los Rocket no vigilan esta sala.`,
        },
        {
          at: `roc-tienda2`,
          trainer: `scientist-gen1`,
          who: `Científico de Silph`,
          text: `Llévate lo que quieras del almacén.`,
        },
      ]),
      (gr = {
        trainer: K,
        who: `Giovanni`,
        text: `Disolveré el Team Rocket… por ahora. Te espero en el Gimnasio Verde.`,
      }),
      m([
        [`Team Rocket`, `Team Rocket`],
        [`El escondite, Silph y Giovanni`, `The hideout, Silph and Giovanni`],
        [`Ciudad Azulona`, `Celadon City`],
        [`Ciudad Azafrán`, `Saffron City`],
        [`Azulona`, `Celadon`],
        [`Escondite`, `Hideout`],
        [`Escondite Rocket`, `Rocket Hideout`],
        [`Silph`, `Silph`],
        [`Silph S.A.`, `Silph Co.`],
        [`Erika`, `Erika`],
        [`Giovanni`, `Giovanni`],
        [`Jugador`, `Gambler`],
        [`Karateka`, `Black Belt`],
        [`Casino`, `Game Corner`],
        [`Dojo Karate`, `Fighting Dojo`],
        [`Sótano 1`, `B1F`],
        [`Sótano 2`, `B2F`],
        [`Sótano 4`, `B4F`],
        [`Guardia`, `Guard`],
        [`Pokémon de laboratorio`, `Lab Pokémon`],
        [`Centro Comercial`, `Department Store`],
        [`Centro Comercial Azulona`, `Celadon Dept. Store`],
        [`Puertas cerradas`, `Locked doors`],
        [`Científico`, `Scientist`],
        [`Sala de descanso`, `Rest area`],
        [`Presidente`, `President`],
        [`Almacén`, `Storeroom`],
        [`Almacén de Silph`, `Silph storeroom`],
        [`Guardaespaldas`, `Bodyguard`],
        [`Recluta`, `Grunt`],
        [`El Dojo Karate`, `The Fighting Dojo`],
        [`Maestro Karateka`, `Karate Master`],
        [
          `¡Has vencido a mis alumnos! Llévate uno de mis luchadores.`,
          `You beat my students! Take one of my fighters.`,
        ],
        [`Hitmonlee`, `Hitmonlee`],
        [`Hitmonchan`, `Hitmonchan`],
        [`Lapras`, `Lapras`],
        [`Las fichas del Casino`, `Game Corner coins`],
        [`Encargado del Casino`, `Game Corner clerk`],
        [
          `Hoy la máquina da premio. ¿Canjeas tus fichas?`,
          `The machines are paying out today. Cash in your coins?`,
        ],
        [`Canjear por Porygon`, `Trade for Porygon`],
        [`Jugar una tirada`, `Play one spin`],
        [`No jugar`, `Don't play`],
        [`El recluta arrepentido`, `The repentant grunt`],
        [
          `Quiero dejar el Team Rocket… Toma, pero no digas que fui yo.`,
          `I want to quit Team Rocket… Here, but don't say it was me.`,
        ],
        [`Dejarle huir`, `Let him go`],
        [`Quitarle la Llave Ascensor`, `Take his Lift Key`],
        [`Las puertas cerradas`, `The locked doors`],
        [`Científico de Silph`, `Silph scientist`],
        [
          `Los Rocket han cerrado todas las puertas. Hay un teletransportador…`,
          `The Rockets locked every door. There is a warp panel…`,
        ],
        [`Subir por las escaleras`, `Take the stairs`],
        [`Arriesgar el teletransportador`, `Risk the warp panel`],
        [`El presidente de Silph`, `The Silph president`],
        [`Presidente de Silph`, `Silph president`],
        [
          `¡Gracias! Elige un regalo: un Lapras… o nuestro invento secreto.`,
          `Thank you! Pick a gift: a Lapras… or our secret invention.`,
        ],
        [`El invento secreto`, `The secret invention`],
        [`¡Un Jugador quiere luchar!`, `You are challenged by Gambler!`],
        [`¡Un Karateka quiere luchar!`, `You are challenged by Black Belt!`],
        [`¡Un Científico quiere luchar!`, `You are challenged by Scientist!`],
        [`¡Un recluta del Team Rocket!`, `A Team Rocket grunt!`],
        [
          `¡No mires el cartel! Aquí no hay nada que ver.`,
          `Stop looking at that poster! Nothing to see here.`,
        ],
        [`¡Una intrusa! ¡A por ella!`, `An intruder! Get her!`],
        [
          `¡Nadie pasa al despacho del jefe!`,
          `Nobody gets into the boss's office!`,
        ],
        [
          `¡Giovanni, el jefe del Team Rocket!`,
          `Giovanni, the boss of Team Rocket!`,
        ],
        [`¡Silph es nuestra! ¡Fuera de aquí!`, `Silph is ours! Get out!`],
        [`¡El jefe no recibe visitas!`, `The boss is not taking visitors!`],
        [
          `¡Otra vez tú! Esta vez no habrá clemencia.`,
          `You again! This time there will be no mercy.`,
        ],
        [
          `El Team Rocket se esconde en Ciudad Azulona. Necesito tu ayuda. Elige a tu compañero.`,
          `Team Rocket is hiding in Celadon City. I need your help. Choose your partner.`,
        ],
        [
          `Los furtivos del Safari trabajaban para el Team Rocket. Su guarida está aquí.`,
          `The Safari poachers worked for Team Rocket. Their lair is here.`,
        ],
        [
          `¡Nadie debe saber lo que hay detrás del cartel del Casino!`,
          `No one must know what is behind the Game Corner poster!`,
        ],
        [
          `Detrás del cartel hay una escalera. ¡Ten cuidado ahí abajo!`,
          `There is a staircase behind the poster. Be careful down there!`,
        ],
        [
          `¿Un crío en mi escondite? Te enseñaré a respetar al Team Rocket.`,
          `A child in my hideout? I will teach you to respect Team Rocket.`,
        ],
        [
          `Quédate con esos Pokémon. Silph S.A. ya es nuestra.`,
          `Keep those Pokémon. Silph Co. is already ours.`,
        ],
        [
          `¡Han tomado el edificio y tienen al presidente en la planta 11!`,
          `They took the building and are holding the president on 11F!`,
        ],
        [`¿Tú también aquí? ¡Yo llegué primero!`, `You too? I got here first!`],
        [
          `¡Giovanni quiere la Master Ball! ¡No le dejes salirse con la suya!`,
          `Giovanni wants the Master Ball! Don't let him get away with it!`,
        ],
        [
          `Disolveré el Team Rocket… por ahora. Te espero en el Gimnasio Verde.`,
          `I will disband Team Rocket… for now. I will be waiting at the Viridian Gym.`,
        ],
      ]),
      Tn(q, ur));
    for (let e of q)
      e.name.startsWith(`Casino`)
        ? (e.scene ?? (e.scene = `Casino`))
        : e.name.startsWith(`Escondite Rocket`)
          ? (e.scene ?? (e.scene = `Escondite Rocket · Sótano`))
          : e.name.startsWith(`Silph S.A.`) &&
            (e.scene ?? (e.scene = `Silph S.A. · Planta`));
    _r = {
      B1: { night: 0.15, alarm: 0.2 },
      B2: { night: 0.25, alarm: 0.35 },
      B3: { night: 0.35, alarm: 0.5 },
      B4: { night: 0.45, alarm: 0.7 },
      P1: { alarm: 0.15 },
      P3: { night: 0.1, alarm: 0.25 },
      P5: { night: 0.2, alarm: 0.35 },
      P6: { night: 0.25 },
      P7: { night: 0.35, alarm: 0.45 },
      P9: { night: 0.45, alarm: 0.5 },
      P11: { night: 0.6, alarm: 0.55 },
    };
    for (let e of q) {
      let t = e.name.split(` · `)[1];
      _r[t] && (e.mood = { ..._r[t] });
    }
    ((vr = q[q.length - 1]),
      (vr.mood = { night: 0.8, alarm: 0.4 }),
      (yr = {
        name: `Alerta`,
        icon: `rocket-r.png`,
        max: 3,
        hint: `Cada alerta, un guardia más con Giovanni`,
      }),
      (br = 1),
      (xr = {
        "roc-b1": [N(`zubat`), N(`meowth`), N(`rattata`)],
        "roc-b4b": [N(`koffing`, 2), N(`meowth`), N(`zubat`)],
        "roc-silph3": [N(`grimer`, 2), N(`sandshrew`, 2), N(`meowth`)],
      }));
    for (let e of q)
      xr[e.id] &&
        ((e.sneak = 1),
        (e.sneakTeam = xr[e.id]),
        (e.sneakIntro = `¡Eh! ¿Quién anda ahí?`),
        (e.sneakLoot = br));
    ((vr.meterTeam = [N(`rattata`), N(`rattata`), N(`meowth`)]),
      (Sr = `scenes/silph-despacho.webp`),
      (Cr = [
        {
          id: `intro`,
          at: `start`,
          style: `strip`,
          go: `iris`,
          panels: [
            { bg: `bg-city`, cast: [j(`erika-gen1`, `c`, `!`)] },
            {
              bg: `bg-city`,
              cast: [j(`red-gen1`, `l`, `?`), j(`rocketgrunt`, `r`, `dots`)],
            },
            {
              bg: `scenes/escondite-rocket.webp`,
              fx: `alarm`,
              cast: [
                j(`rocketgruntf`, `l`, `!`),
                j(`rocketgrunt`, `r`, `angry`),
              ],
            },
          ],
        },
        {
          id: `giovanni1`,
          at: `roc-giovanni1`,
          style: `panel`,
          go: `iris`,
          panels: [
            {
              bg: `scenes/escondite-rocket.webp`,
              fx: `night`,
              cast: [j(K, `c`, `dots`)],
            },
          ],
        },
        {
          id: `presidente`,
          at: `roc-silph3`,
          style: `panel`,
          panels: [
            {
              bg: `scenes/silph-oficina.webp`,
              fx: `night`,
              cast: [j(lr, `c`, `fear`)],
            },
          ],
        },
        {
          id: `giovanni2`,
          at: `roc-giovanni`,
          style: `panel`,
          go: `iris`,
          panels: [{ bg: Sr, fx: `alarm`, cast: [j(K, `c`, `!`)] }],
        },
        {
          id: `nudo`,
          at: `roc-giovanni1:end`,
          style: `strip`,
          panels: [
            {
              bg: `scenes/escondite-rocket.webp`,
              cast: [j(K, `c`, `angry`, { flip: !0 })],
            },
            {
              bg: `scenes/silph-oficina.webp`,
              fx: `alarm`,
              cast: [
                j(`rocketgrunt`, `l`, `joy`),
                j(`rocketgruntf`, `r`, `joy`),
              ],
            },
            {
              bg: `bg-city`,
              cast: [j(`red-gen1`, `l`, `!`), j(`erika-gen1`, `r`, `fear`)],
              line: `¡Giovanni ha tomado Silph S.A.!`,
            },
          ],
        },
        {
          id: `fin`,
          at: `end`,
          style: `strip`,
          go: `iris`,
          panels: [
            { bg: Sr, cast: [j(K, `c`, `dots`, { flip: !0 })] },
            { bg: Sr, cast: [j(`red-gen1`, `l`, `joy`), j(lr, `r`, `joy`)] },
            { bg: `bg-city`, fx: `dawn`, cast: [j(`erika-gen1`, `c`, `joy`)] },
          ],
        },
      ]),
      m([
        [
          `¡Giovanni ha tomado Silph S.A.!`,
          `Giovanni has taken over Silph Co.!`,
        ],
        [
          `Un almacén del Team Rocket sin vigilar. ¡Coge lo que te haga falta!`,
          `An unguarded Team Rocket storeroom. Take whatever you need!`,
        ],
        [
          `La enfermería Rocket está vacía. Recupérate: Giovanni está cerca.`,
          `The Rocket sick bay is empty. Recover: Giovanni is close.`,
        ],
        [
          `¡Hoy hay premio gordo! Tres sietes y te llevas un Porygon.`,
          `Jackpot day! Three sevens and the Porygon is yours.`,
        ],
        [`Almacén Rocket`, `Rocket storeroom`],
        [`Enfermería Rocket`, `Rocket sick bay`],
        [`Alerta`, `Alert`],
        [`¡Eh! ¿Quién anda ahí?`, `Hey! Who's there?`],
        [
          `Cada alerta, un guardia más con Giovanni`,
          `Each alert, one more guard for Giovanni`,
        ],
        [`B1`, `B1F`],
        [`B2`, `B2F`],
        [`B3`, `B3F`],
        [`B4`, `B4F`],
        [`P1`, `1F`],
        [`P3`, `3F`],
        [`P5`, `5F`],
        [`P6`, `6F`],
        [`P7`, `7F`],
        [`P9`, `9F`],
        [`P11`, `11F`],
        [
          `Descansa aquí, los Rocket no vigilan esta sala.`,
          `Rest here, the Rockets don't guard this room.`,
        ],
        [
          `Llévate lo que quieras del almacén.`,
          `Take whatever you want from the storeroom.`,
        ],
      ]),
      (wr = `scenes/escondite-rocket.webp`),
      (Tr = `scenes/silph-oficina.webp`),
      (Er = { host: `erika-gen1`, name: `Erika` }),
      (Dr = { host: `scientist-gen1`, name: `Científico de Silph` }),
      En(q, {
        "roc-casino": {
          host: `gentleman-gen1`,
          name: `Encargado del Casino`,
          say: `¡Hoy hay premio gordo! Tres sietes y te llevas un Porygon.`,
        },
        "roc-tienda": {
          ...Er,
          say: `Un almacén del Team Rocket sin vigilar. ¡Coge lo que te haga falta!`,
          icon: `item:lift-key`,
          bg: wr,
        },
        "roc-centro2": {
          ...Er,
          say: `La enfermería Rocket está vacía. Recupérate: Giovanni está cerca.`,
          icon: `item:hyper-potion`,
          bg: wr,
        },
        "roc-lib": { icon: `item:poke-ball`, bg: wr },
        "roc-curacion": {
          ...Dr,
          say: `Descansa aquí, los Rocket no vigilan esta sala.`,
          icon: `item:super-potion`,
          bg: Tr,
        },
        "roc-tienda2": {
          ...Dr,
          say: `Llévate lo que quieras del almacén.`,
          icon: `item:card-key`,
          bg: Tr,
        },
      }),
      Dn(q, `roc-giovanni`, {
        team: [
          N(`rhyhorn`, 3),
          N(`meowth`, 3),
          N(`kangaskhan`, 2),
          N(`nidoran`, 2),
          N(`nidoranf`, 3),
          N(`onix`, 2),
          N(`cubone`, 2),
          N(`sandshrew`),
        ],
      }));
  }))();
}
function kr(e, t) {
  let n = e && Lr(e) ? e : `kanto`,
    r = J[n];
  _e(r.rounds, r.stages);
  let i = n === `kanto` ? jr : r.shop.map((e) => f[e]);
  ((p.length !== i.length || p.some((e, t) => e !== i[t])) &&
    ((p.length = 0), p.push(...i)),
    t && ((t.length = 0), t.push(...r.safari)),
    (Rr = n));
}
var Ar, jr, J, Mr, Nr, Pr, Fr, Ir, Lr, Rr, zr;
function Br() {
  return (Br = e(() => {
    (Me(),
      s(),
      xn(),
      wn(),
      o(),
      jt(),
      Wn(),
      rr(),
      ar(),
      Or(),
      (Ar = [
        `tauros`,
        `chansey`,
        `scyther`,
        `rhyhorn`,
        `exeggcute`,
        `dratini`,
        `nidoran`,
        `paras`,
      ]),
      (jr = [...p]),
      (J = {
        kanto: {
          id: `kanto`,
          name: `Kanto`,
          tagline: `8 medallas, la Liga y un secreto`,
          rounds: T,
          stages: se,
          shop: jr.map((e) => e.id),
          safari: Ar,
          starters: [`bulbasaur`, `charmander`, `squirtle`],
          cardTrainer: `blue-gen1champion`,
          cardMon: 25,
          cardBg: `bg-route`,
          stars: 1,
          scenes: ir,
        },
        safari: {
          id: `safari`,
          name: `Zona Safari`,
          tagline: `Los furtivos del Safari`,
          rounds: Pn,
          stages: Fn,
          shop: [...jr.map((e) => e.id).filter((e) => !In.includes(e)), ...Ln],
          safari: Rn,
          starters: [`nidoran`, `venonat`, `paras`],
          cardTrainer: `koga-gen1`,
          cardMon: 115,
          cardBg: `bg-meadow`,
          stars: 1,
          host: zn,
          music: `mus_rg_fuchsia`,
          story: Bn,
          epilogue: Vn,
          tokens: Mn,
          scenes: Hn,
        },
        lavanda: {
          id: `lavanda`,
          name: `Noche en Lavanda`,
          tagline: `La Torre Pokémon de noche`,
          rounds: U,
          stages: qn,
          shop: [...jr.map((e) => e.id).filter((e) => !Jn.includes(e)), ...Yn],
          safari: Xn,
          starters: [`gastly`, `cubone`, `koffing`],
          cardTrainer: `channeler-gen1`,
          cardMon: 105,
          cardBg: `scenes/lavanda-noche.webp`,
          stars: 2,
          host: Zn,
          music: `mus_rg_lavender`,
          story: Qn,
          epilogue: $n,
          scenes: tr,
        },
        rocket: {
          id: `rocket`,
          name: `Team Rocket`,
          tagline: `El escondite, Silph y Giovanni`,
          rounds: q,
          stages: ur,
          shop: [...jr.map((e) => e.id).filter((e) => !dr.includes(e)), ...fr],
          safari: pr,
          starters: [`abra`, `meowth`, `eevee`],
          cardTrainer: `giovanni-gen1rb`,
          cardMon: 53,
          cardBg: `scenes/escondite-rocket.webp`,
          stars: 4,
          unlock: `adventure`,
          host: mr,
          music: `mus_rg_celadon`,
          story: hr,
          epilogue: gr,
          meter: yr,
          scenes: Cr,
        },
      }),
      (Mr = Object.keys(J)),
      (Nr = [
        {
          id: `intro`,
          at: `start`,
          style: `strip`,
          go: `iris`,
          panels: [
            {
              bg: `bg-route`,
              cast: [j(`oak-gen1`, `c`, `!`)],
              line: `Ya conoces Kanto. Ahora, la Liga de verdad.`,
            },
            {
              bg: `bg-route`,
              cast: [
                j(`blue-gen1champion`, `l`, `joy`),
                j(`red-gen1`, `r`, `angry`),
              ],
            },
            {
              bg: `bg-city`,
              cast: [
                j(`lorelei-gen1`, `l`),
                j(`lance-gen1`, `c`, `!`, { scale: 1.1 }),
                j(`agatha-gen1`, `r`),
              ],
            },
          ],
        },
        {
          id: `fin`,
          at: `end`,
          style: `strip`,
          go: `iris`,
          panels: [
            { bg: `bg-route`, cast: [j(`blue-gen1champion`, `c`, `fear`)] },
            {
              bg: `bg-space`,
              fx: `night`,
              cast: [
                j(`red-gen1`, `l`, `!`),
                M(`mewtwo`, `r`, `angry`, { scale: 1.1 }),
              ],
            },
            {
              bg: `bg-route`,
              fx: `dawn`,
              cast: [j(`red-gen1`, `l`, `joy`), j(`oak-gen1`, `r`, `joy`)],
            },
          ],
        },
      ]),
      (Pr = {
        ...J.kanto,
        name: `Kanto · Maestro`,
        tagline: `La Liga de verdad`,
        cardTrainer: `lance-gen1`,
        cardMon: 150,
        cardBg: `bg-space`,
        stars: 3,
        unlock: `kanto`,
        scenes: Nr,
      }),
      (Fr = (e, t) => (e === `kanto` && Ct(t) >= 2 ? Pr : J[e])),
      (Ir = (e, t) => (Fr(e, t) === Pr ? `maestro` : e)),
      m([
        [`Kanto · Maestro`, `Kanto · Master`],
        [`Maestro`, `Master`],
        [`La Liga de verdad`, `The real League`],
        [
          `Ya conoces Kanto. Ahora, la Liga de verdad.`,
          `You know Kanto. Now, the real League.`,
        ],
      ]),
      (Lr = (e) => typeof e == `string` && e in J));
    for (let e of Object.values(J)) {
      let t = new Set(e.shop);
      if (t.size !== e.shop.length)
        throw Error(`aventura ${e.id}: líneas repetidas en el set`);
      for (let t of [...e.shop, ...e.safari])
        if (!f[t]) throw Error(`aventura ${e.id}: falta la línea ${t}`);
      if (e.id !== `kanto`) {
        for (let n of e.starters)
          if (!t.has(n))
            throw Error(`aventura ${e.id}: el inicial ${n} no está en el set`);
      }
    }
    ((Rr = `kanto`), (zr = () => Rr));
  }))();
}
var Vr,
  Y,
  Hr,
  Ur,
  Wr,
  Gr,
  Kr,
  qr,
  Jr,
  Yr,
  Xr,
  Zr,
  Qr,
  $r,
  ei,
  ti,
  ni,
  ri,
  ii,
  ai,
  oi,
  si,
  ci,
  li,
  ui,
  di,
  fi,
  pi,
  mi,
  hi;
function gi() {
  return (gi = e(() => {
    (o(),
      (Vr = `Torre Batalla`),
      (Y = (e, t, n) => ({ trainer: e, who: t, intro: n })),
      (Hr = Y(`sailor-gen1`, `Marinero`, `¡Un Marinero quiere luchar!`)),
      (Ur = Y(`fisherman-gen1`, `Pescador`, `¡Un Pescador quiere luchar!`)),
      (Wr = Y(`swimmer-gen1`, `Nadador`, `¡Un Nadador quiere luchar!`)),
      (Gr = Y(`hiker-gen1`, `Montañero`, `¡Un Montañero quiere luchar!`)),
      (Kr = Y(
        `pokemaniac-gen1`,
        `Pokémaníaco`,
        `¡Un Pokémaníaco quiere luchar!`,
      )),
      (qr = Y(
        `jrtrainerf-gen1`,
        `Entrenadora`,
        `¡Una Entrenadora quiere luchar!`,
      )),
      (Jr = Y(
        `rocketgrunt`,
        `Recluta`,
        `¡Un recluta del Team Rocket quiere luchar!`,
      )),
      (Yr = Y(
        `rocketgruntf`,
        `Recluta`,
        `¡Una recluta del Team Rocket quiere luchar!`,
      )),
      (Xr = Y(
        `birdkeeper-gen1`,
        `Ornitólogo`,
        `¡Un Ornitólogo quiere luchar!`,
      )),
      (Zr = Y(`cueball-gen1`, `Calvo`, `¡Un Calvo quiere luchar!`)),
      (Qr = Y(`blackbelt-gen1`, `Karateka`, `¡Un Karateka quiere luchar!`)),
      ($r = Y(`scientist-gen1`, `Científico`, `¡Un Científico quiere luchar!`)),
      (ei = Y(`juggler-gen1`, `Malabarista`, `¡Un Malabarista quiere luchar!`)),
      (ti = Y(`burglar-gen1`, `Ladrón`, `¡Un Ladrón quiere luchar!`)),
      (ni = Y(`gentleman-gen1`, `Caballero`, `¡Un Caballero quiere luchar!`)),
      (ri = Y(`tamer-gen1`, `Domador`, `¡Un Domador quiere luchar!`)),
      (ii = Y(
        `acetrainer-gen1`,
        `Entrenador Guay`,
        `¡Un Entrenador Guay quiere luchar!`,
      )),
      (ai = Y(
        `bugcatcher-gen1`,
        `Cazabichos`,
        `¡Un Cazabichos quiere luchar!`,
      )),
      (oi = Y(`channeler-gen1`, `Médium`, `¡Una Médium quiere luchar!`)),
      (si = {
        Normal: [ri, ni, qr],
        Fire: [ti, ni],
        Water: [Wr, Ur, Hr],
        Grass: [qr, ii],
        Electric: [$r, ni],
        Ice: [Wr, ii],
        Fighting: [Qr, Zr, Hr],
        Poison: [Jr, Yr],
        Ground: [Gr, ri, Kr],
        Flying: [Xr],
        Psychic: [ei, oi],
        Bug: [ai],
        Rock: [Gr, Kr],
        Ghost: [oi],
        Dragon: [ii, Kr],
      }),
      (ci = {
        Normal: `bg-city`,
        Fire: `bg-volcanocave`,
        Water: `bg-deepsea`,
        Grass: `bg-forest`,
        Electric: `bg-city`,
        Ice: `bg-icecave`,
        Fighting: `bg-mountain`,
        Poison: `bg-dampcave`,
        Ground: `bg-earthycave`,
        Flying: `bg-route`,
        Psychic: `bg-space`,
        Bug: `bg-forest`,
        Rock: `bg-mountain`,
        Ghost: `bg-dampcave`,
        Dragon: `bg-mountain`,
      }),
      (li = {
        Water: `rain`,
        Electric: `rain`,
        Fire: `sun`,
        Grass: `sun`,
        Rock: `sand`,
        Ground: `sand`,
        Fighting: `sand`,
        Ice: `hail`,
        Dragon: `hail`,
      }),
      (ui = {
        floor: `mus_rg_victory_road`,
        boss: `mus_rg_gym`,
        legend: `mus_rg_mt_moon`,
      }),
      (di = [
        { id: `brock`, types: [`Rock`, `Ground`] },
        { id: `misty`, types: [`Water`] },
        { id: `surge`, types: [`Electric`] },
        { id: `gym4`, types: [`Grass`] },
        { id: `gym5`, types: [`Poison`] },
        { id: `gym6`, types: [`Psychic`] },
        { id: `blaine`, types: [`Fire`] },
        { id: `giovanni`, types: [`Ground`, `Rock`] },
      ]),
      (fi = [
        { id: `lorelei`, types: [`Ice`, `Water`] },
        { id: `bruno`, types: [`Fighting`, `Rock`] },
        { id: `agatha`, types: [`Ghost`, `Poison`] },
        { id: `lance`, types: [`Dragon`, `Flying`] },
        { id: `giovanni`, types: [`Ground`, `Rock`] },
        { id: `campeon`, types: [`Normal`, `Fire`] },
      ]),
      (pi = [`articuno`, `zapdos`, `moltres`, `mew`, `mewtwo`]),
      (mi = {
        articuno: {
          intro: `¡Articuno legendario!`,
          bg: `bg-icecave`,
          types: [`Ice`, `Flying`],
        },
        zapdos: {
          intro: `¡Zapdos legendario!`,
          bg: `bg-mountain`,
          types: [`Electric`, `Flying`],
        },
        moltres: {
          intro: `¡Moltres legendario!`,
          bg: `bg-volcanocave`,
          types: [`Fire`, `Flying`],
        },
        mew: { intro: `¡Mew legendario!`, bg: `bg-forest`, types: [`Psychic`] },
        mewtwo: {
          intro: `¡Mewtwo te espera en la cima!`,
          bg: `bg-dampcave`,
          types: [`Psychic`],
        },
      }),
      (hi = {
        snorlax: {
          name: `Snorlax`,
          intro: `¡Un Snorlax dormido bloquea el paso!`,
          bg: `bg-route`,
        },
        missingno: {
          name: `MissingNo.`,
          intro: `¡Un MISSINGNO. salvaje apareció!`,
          bg: `bg-volcanocave`,
        },
        gyarados: {
          name: `Gyarados`,
          intro: `¡Un Gyarados furioso emerge del agua!`,
          bg: `bg-river`,
        },
        marowak: {
          name: `Fantasma`,
          intro: `¡El FANTASMA no se puede identificar!`,
          bg: `bg-gen4-cave`,
          arena: `tower`,
        },
      }),
      m([
        [Vr, `Battle Tower`],
        [`Médium`, `Channeler`],
        [`¡Una Médium quiere luchar!`, `You are challenged by Channeler!`],
        [`¡Un Ladrón quiere luchar!`, `You are challenged by Burglar!`],
        [`¡Un Domador quiere luchar!`, `You are challenged by Tamer!`],
        [`¡Articuno legendario!`, `Legendary Articuno!`],
        [`¡Zapdos legendario!`, `Legendary Zapdos!`],
        [`¡Moltres legendario!`, `Legendary Moltres!`],
        [`¡Mew legendario!`, `Legendary Mew!`],
        [`¡Mewtwo te espera en la cima!`, `Mewtwo awaits at the top!`],
        [
          `¡Un Snorlax dormido bloquea el paso!`,
          `A sleeping Snorlax blocks the way!`,
        ],
        [`¡Un MISSINGNO. salvaje apareció!`, `Wild MISSINGNO. appeared!`],
        [
          `¡Un Gyarados furioso emerge del agua!`,
          `An enraged Gyarados bursts out of the water!`,
        ],
        [`¡El FANTASMA no se puede identificar!`, `The GHOST can't be ID'd!`],
        [`Fantasma`, `Ghost`],
      ]));
  }))();
}
function _i(e, t, n, r = 0, i) {
  for (t += n; e < 9 && t >= oa(e, r, i);) ((t -= oa(e, r, i)), e++);
  return { level: e, xp: t };
}
function vi(e, t) {
  let n = {};
  for (let e of p) n[e.id] = d[e.cost];
  for (let t of e) n[u(t.line)] -= 3 ** (t.star - 1);
  if (t) for (let [e, r] of Object.entries(t)) e in n && (n[e] -= r);
  return n;
}
function yi(e) {
  let t = {};
  for (let n of e) {
    let e = u(n.line);
    t[e] = (t[e] ?? 0) + 3 ** (n.star - 1);
  }
  return t;
}
function bi(e) {
  let t = new Set();
  for (let n of e) n.star >= 3 && t.add(u(n.line));
  return t;
}
function xi(e, t, n = Math.random, r, i = aa) {
  let a = [...t],
    o = vi(a, r),
    s = bi(a),
    c = i[e],
    l = (e) => p.filter((t) => t.cost === e && o[t.id] > 0 && !s.has(t.id));
  return Array.from({ length: 5 }, () => {
    let e = n() * 100,
      t = 1;
    for (let n = 0; n < 5; n++) {
      if (e < c[n]) {
        t = n + 1;
        break;
      }
      e -= c[n];
    }
    let r = l(t);
    if (!r.length) {
      let e = [
        ...[1, 2, 3, 4, 5].filter((e) => e > t),
        ...[4, 3, 2, 1].filter((e) => e < t),
      ];
      for (let t of e) if (c[t - 1] > 0 && (r = l(t)).length) break;
      if (!r.length) {
        for (let t of e) if ((r = l(t)).length) break;
      }
    }
    let i = r.reduce((e, t) => e + o[t.id], 0);
    if (!i) return null;
    let a = n() * i;
    for (let e of r) if (((a -= o[e.id]), a <= 0)) return (o[e.id]--, e.id);
    return r[r.length - 1].id;
  });
}
function Si(e) {
  let t = Object.fromEntries(ca.map((e) => [e, 0]));
  for (let n of e) {
    let e = la(n);
    e && (t[e] += g(n) ? 1 : 2);
  }
  return t;
}
function Ci(e) {
  let t = new Set(e.map((e) => e.line));
  return Object.fromEntries(
    ca.map((e) => {
      let n = f[e].traits[0];
      return [
        e,
        [...t].filter((e) => {
          var t;
          return (t = f[e]) == null ? void 0 : t.traits.includes(n);
        }).length,
      ];
    }),
  );
}
function wi(e, t, n = ca) {
  let r = Si(e),
    i = Ci(t),
    a = ca.filter((e) => n.includes(e)),
    o = (e, t) => {
      let n = Math.max(...e.map(t));
      return e.filter((e) => t(e) === n);
    },
    s = o(a, (e) => r[e]);
  if (s.length === 1) return { line: s[0], why: `items`, votes: r, syn: i };
  let c = o(s, (e) => i[e]);
  return {
    line: c[0],
    why: c.length === 1 ? `synergy` : `default`,
    votes: r,
    syn: i,
  };
}
function Ti(e, t, n = [], r = [], i = [], a = !1) {
  var o;
  let s = f[e],
    c = s != null && s.branches ? e : s == null ? void 0 : s.branchOf;
  if (!c || t < 2) return e;
  let l = ((o = f[c]) == null ? void 0 : o.branches) ?? [],
    d = (e) => wi(n, r, e).line;
  if (t >= 3 && i.length) {
    let t = [e, ...i.filter((e) => u(e) === c)],
      n = (e) => t.filter((t) => t === e).length,
      r = Math.max(...t.map(n)),
      o = [...new Set(t.filter((e) => n(e) === r))];
    if (o.length === 1) return o[0] === c && !a ? d(l) : o[0];
    if (a && o.includes(c)) return c;
    let s = o.filter((e) => e !== c);
    return d(s.length ? s : l);
  }
  return e === c && !a ? d(l) : e;
}
function Ei(e, t, n, r = !1) {
  var i;
  let a = (e == null ? void 0 : e.line) ?? `eevee`,
    o = (e == null ? void 0 : e.star) ?? 1;
  if (u(a) !== `eevee` || o >= 3 || (r && o === 1)) return null;
  let s = new Set(n),
    c = t.filter((e) => s.has(e.id)),
    l = t
      .filter(
        (t) =>
          t.id !== (e == null ? void 0 : e.id) &&
          u(t.line) === `eevee` &&
          t.star === o,
      )
      .sort((e, t) => Number(s.has(t.id)) - Number(s.has(e.id))),
    d = e != null && e.id ? e : (l.shift() ?? null),
    f = [...(d ? [d] : []), ...l].slice(0, 3),
    p = Yi(
      ((i = f[0]) == null ? void 0 : i.items) ?? [],
      f.slice(1).flatMap((e) => e.items ?? []),
    ).kept;
  if (o === 1) return wi(p, c);
  let m = f.map((e) => e.line);
  if (m.length < 3) return a === `eevee` && !r ? wi(p, c) : null;
  let h = (e) => m.filter((t) => t === e).length,
    g = Math.max(...m.map(h)),
    ee = [...new Set(m.filter((e) => h(e) === g))];
  if (ee.length === 1) return ee[0] === `eevee` && !r ? wi(p, c) : null;
  if (r && ee.includes(`eevee`)) return null;
  let _ = ee.filter((e) => e !== `eevee`);
  return wi(p, c, _.length ? _ : ca);
}
function Di(e, t = Math.random, n = ua) {
  return (da && (n = 0), e.map((e) => !!e && t() < n));
}
function Oi(e = new Date()) {
  return `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, `0`)}-${String(e.getDate()).padStart(2, `0`)}`;
}
function ki(e) {
  let [t, n, r] = e.split(`-`).map(Number);
  return Math.round((Date.UTC(t, n - 1, r) - fa) / 864e5) + 1;
}
function Ai(e, t) {
  return e * 3 ** (t - 1) - (t > 1 && e > 1);
}
function ji(e, t = () => !1) {
  let n = new Map();
  for (let t of e) {
    if (t.star >= 3) continue;
    let e = `${u(t.line)}:${t.star}`;
    n.set(e, [...(n.get(e) ?? []), t]);
  }
  for (let e of n.values()) {
    if (e.length < 3) continue;
    let [n, ...r] = [...e]
      .sort((e, n) => Number(t(n)) - Number(t(e)))
      .slice(0, 3);
    return { keep: n, gone: r };
  }
  return null;
}
function Mi(e) {
  let t = b[e];
  return !!t && !t.route && !t.canLose && (!!t.badge || !!t.league || !!t.boss);
}
function Ni(e) {
  if (e <= 1) return [3];
  let t = Math.min(6, 2 * (e - 1));
  return Array.from({ length: e }, (n, r) =>
    Math.round(3 - t / 2 + (r * t) / (e - 1)),
  );
}
function Pi(e, t, n, r = {}) {
  let i = n === void 0 ? -1 : Li(e, n, t, r),
    a = Fi(Ac(e, { ...r, seed: n, starter: t }), i);
  return yo(e) || !(r.league && r.league > 1)
    ? a
    : a.map((t) => {
        let n = ms(e, t.line, r.league);
        return n ? { ...t, boost: n } : t;
      });
}
function Fi(e, t = -1) {
  let n = new Set(),
    r = e.map((e, n) => ({
      ...e,
      i: n,
      role: f[e.line].role,
      shiny: n === t || e.shiny === !0,
    })),
    i = (e, t) => {
      let r = -1,
        i = 1 / 0;
      for (let a of ha)
        for (let o = 0; o < 7; o++) {
          let s = xe(o, a);
          if (n.has(s)) continue;
          let c = Math.abs(o - e) + Math.abs(a - t) * 1.5;
          c < i && ((i = c), (r = s));
        }
      return (r >= 0 && n.add(r), r);
    },
    a = [];
  for (let e of [3, 2, 1]) {
    let t = r
        .filter((t) => ga[t.role] === e && !t.ward)
        .sort((e, t) => _a[e.role] - _a[t.role] || e.i - t.i),
      n = Ni(Math.min(7, t.length)).sort(
        (e, t) => Math.abs(e - 3) - Math.abs(t - 3) || t - e,
      ),
      o = 0,
      s = (e, t) => {
        let r = f[e.line].entry;
        return r === `stealth` || r === `rush`
          ? o++ % 2
            ? 0
            : 6
          : n[t % n.length];
      };
    t.forEach((t, n) => {
      var r;
      return a.push({
        line: t.line,
        star: t.star,
        cell: i(s(t, n), e),
        ...((r = t.items) != null && r.length ? { items: [...t.items] } : {}),
        ...(t.shiny ? { shiny: !0 } : {}),
        ...(t.boss ? { boss: t.boss } : {}),
      });
    });
  }
  return (
    r
      .filter((e) => e.ward)
      .forEach((e, t) => {
        var r;
        let o = -1;
        for (let e of [3, 4, 2, 5, 1, 6, 0])
          if (!n.has(xe(e, 0))) {
            o = xe(e, 0);
            break;
          }
        (o < 0 && (o = i(3 + t, 0)),
          n.add(o),
          a.push({
            line: e.line,
            star: e.star,
            cell: o,
            ...((r = e.items) != null && r.length
              ? { items: [...e.items] }
              : {}),
            ...(e.shiny ? { shiny: !0 } : {}),
          }));
      }),
    a
  );
}
function Ii(e) {
  let t = E(`${e}|wildShiny`),
    n = t(),
    r = t(),
    i = Math.floor(t() * 1e6),
    a = b.flatMap((e, t) =>
      t > 0 && !e.trainer && !e.event && !e.boss ? [t] : [],
    );
  if (n < 0.5 && a.length)
    return { round: a[Math.floor(r * a.length)], pick: i };
  let o = b.findIndex((e) => e.boss);
  return n < 0.54 && o >= 0 ? { round: o, pick: 0 } : null;
}
function Li(e, t, n, r = {}) {
  let i = Ii(t);
  if (!i || i.round !== e) return -1;
  let a = Ac(e, { ...r, seed: t, starter: n }).length;
  return a ? i.pick % a : -1;
}
function Ri(e, t) {
  return t ? Math.max(1, e + 1) : Math.min(-1, e - 1);
}
function zi(e) {
  var t;
  let n = ((t = f[e.line]) == null ? void 0 : t.cost) ?? 1;
  return (X.star[e.star] ?? e.star) + (n >= X.costFrom ? X.costBonus : 0);
}
function Bi(e, t) {
  let n = 0;
  for (let [r, i] of yo(e) ? wa : Ca) t >= r && (n = i);
  return n;
}
function Vi(e, t = 1) {
  let n = 0,
    r = 0;
  for (let i of e)
    i.team === t && ((r += i.maxHp), i.alive && (n += Math.max(0, i.hp)));
  return r > 0 ? Math.max(0, Math.min(1, 1 - n / r)) : 0;
}
function Hi(e) {
  let t = e.retryShare !== void 0,
    n = Sa(e.round),
    r = t ? Ta(e.round, e.retryShare) : n,
    i = t ? 0 : Math.min(4, Math.floor(e.gold / 10)),
    a = Bi(e.round, Math.max(0, e.streak));
  e.won;
  let o = r + i + a + 0,
    s = e.halved ? Math.floor(o / 2) : o;
  return {
    base: r,
    interest: i,
    streak: a,
    win: 0,
    penalty: o - s,
    total: s,
    retry: t,
    fullBase: n,
  };
}
function Ui(e) {
  let t = e.won
    ? 0
    : e.survivors
      ? xa(e.round, e.survivors)
      : ya(e.round) + (e.survivorStars ?? 0);
  t > 0 &&
    e.hp !== void 0 &&
    (ba(e.round) && e.hp > X.floorHp && (t = Math.min(t, e.hp - X.floorHp)),
    _c(e.round) && (t = Math.min(t, Math.max(0, e.hp - 1))));
  let n = Ri(e.streak, e.won),
    r = e.won || !(e.mustWin ?? Mi(e.round)),
    i =
      !r && (e.attempts ?? 0) > 0 && e.foeShare !== void 0
        ? Math.max(0, Math.min(1, e.foeShare))
        : null,
    a = Hi({
      round: e.round,
      gold: e.gold,
      streak: n,
      won: e.won,
      retryShare: i ?? void 0,
    }).total;
  return {
    damage: t,
    retryDamage: 0,
    streak: n,
    income: a,
    advanced: r,
    penalized: !1,
    retryShare: i,
  };
}
function Wi(e, t, n = !1) {
  var r;
  let i = b[e];
  return n && i != null && (r = i.sneakTeam) != null && r.length
    ? (i.sneakLoot ?? 0)
    : i != null && i.canLose && !i.event
      ? 3
      : !i || i.event || i.boss || i.league
        ? 0
        : i.route === `rival`
          ? 2
          : i.route === `wild`
            ? +(t !== void 0 && E(`${t}|routeItem|${i.id}`)() < 0.5)
            : i.route
              ? 0
              : i.badge
                ? 3
                : i.rivalTeam
                  ? 2
                  : i.trainer
                    ? +!!Oa.has(e)
                    : 1;
}
function Gi(e, t) {
  var n;
  return (((n = b[e]) == null ? void 0 : n.badge) ?? 0) === 8 ? `full` : `part`;
}
function Ki(e) {
  var t;
  let n = (t = b[e]) == null ? void 0 : t.badge;
  return n && Da.includes(n) ? 1 : 0;
}
function qi(e, t = Math.random, n = [], r = `part`, i = !1) {
  let a = r === `part` ? [...le(i)] : [...re(i)],
    o = a.filter((e) => !n.includes(e)),
    s = o.length >= e ? o : a,
    c = [];
  for (; c.length < e && s.length;)
    c.push(s.splice(Math.floor(t() * s.length), 1)[0]);
  return c;
}
function Ji(e, t) {
  return [...e, t].slice(-2).map((e) => [...e]);
}
function Yi(e, t) {
  let n = oe([...e, ...t]);
  return { kept: n.slice(0, 3), spare: n.slice(3) };
}
function Xi(e, t, n = Math.random) {
  if (t) return 3;
  let r = ja(e) ** 0.25,
    i = [0, 1, 2, 3].map((e) => r ** +e * (1 - r)),
    a = i.reduce((e, t) => e + t, 0),
    o = n() * a;
  for (let e = 0; e < 4; e++) {
    if (o < i[e]) return e;
    o -= i[e];
  }
  return 0;
}
function Zi(e, t, n, r, i = Na) {
  let a = vi(t, r),
    o = bi(t),
    s = i.filter((e) => f[e] && (a[e] ?? 0) > 0 && !o.has(e));
  for (let e = s.length - 1; e > 0; e--) {
    let t = Math.floor(n() * (e + 1));
    [s[e], s[t]] = [s[t], s[e]];
  }
  let c = s.find((e) => t.some((t) => t.line === e)),
    l = c ? [c] : [];
  for (let e of s) {
    if (l.length >= 3) break;
    l.includes(e) ||
      (f[e].cost >= 4 && l.filter((e) => f[e].cost >= 4).length >= 2) ||
      l.push(e);
  }
  for (let i = 0; l.length < 3 && i < 6; i++)
    for (let i of xi(Math.min(9, e + 1), t, n, r))
      i && l.length < 3 && !l.includes(i) && f[i].cost < 5 && l.push(i);
  return l.sort((e, t) => f[e].cost - f[t].cost);
}
function Qi(e, t, n, r, i, a = Na) {
  let o = e.filter((e) => {
      var t;
      return (((t = f[e]) == null ? void 0 : t.cost) ?? 0) >= 4;
    }).length,
    s = (t) => !e.includes(t) && !(f[t].cost >= 4 && o >= 2),
    c = Zi(t, n, r, i, a).find(s);
  if (c) return c;
  let l = a.filter((e) => f[e] && s(e));
  return l.length ? l[Math.floor(r() * l.length)] : (a[0] ?? null);
}
function $i(e, t, n, r = 100) {
  let i = Fa[e][t];
  if (!i || (i === `care` && n.gold < 6)) return null;
  let { hp: a, gold: o, level: s, xp: c } = n;
  return (
    i === `rest`
      ? (a = Math.max(a, Math.min(r, a + 3)))
      : i === `care`
        ? ((a = Math.max(a, Math.min(r, a + 9))), (o -= 6))
        : i === `train`
          ? (({ level: s, xp: c } = _i(s, c, 8)), (a = Math.max(1, a - 8)))
          : (o += 4),
    { choice: i, hp: a, gold: o, level: s, xp: c }
  );
}
function ea(e, t, n, r = Math.random, i = [], a = 100, o = 100, s, c = !1, l) {
  if (e === `safari`) return { mons: Zi(t, [...n], r, s, l), items: [] };
  if (e === `center`) return { mons: [], items: [], center: Pa(a, o) };
  if (e === `oak`) return { mons: [], items: qi(2, r, i, Ia, c) };
  if (e === `shop` || e === `choice`) return { mons: [], items: [] };
  if (e === `mall`) {
    let e = [...qi(2, r, i, `part`, c), ...qi(1, r, i, `full`, c)],
      t = [...n],
      a = vi(t, s),
      o = bi(t),
      l = p.filter(
        (e) => (e.cost === 3 || e.cost === 4) && a[e.id] > 0 && !o.has(e.id),
      ),
      u = r() < 0.5 && l.length ? l[Math.floor(r() * l.length)].id : null;
    return (r() < 0.5 && (e[1] = C), { mons: u ? [u] : [], items: e });
  }
  if (e === `legend`) {
    let e = vi(n, s),
      t = Wa.filter((t) => (e[t] ?? 1) > 0);
    return { mons: t.length ? t : [...Wa], items: [] };
  }
  return { mons: [], items: [] };
}
function ta(e, t, n = 100) {
  let r = Ga[e] ?? { hp: 0, gold: 0 };
  return t.gold + r.gold < 0
    ? null
    : {
        hp: Math.max(1, Math.min(Math.max(n, t.hp), t.hp + r.hp)),
        gold: t.gold + r.gold,
        terms: r,
      };
}
function na(e, t = Math.random, n = [], r, i) {
  let a = t(),
    o = `rocket`;
  for (let e of Ha) {
    if (a < e.p) {
      o = e.sym;
      break;
    }
    a -= e.p;
  }
  let s = [`cherry`, `ball`, `pika`, `seven`, `rocket`];
  if (o === `rocket`) {
    let e = () => s[Math.floor(t() * s.length)],
      n = e(),
      r = t() < 0.4 ? n : e(),
      i = s.filter((e) => e !== n);
    return { reels: [n, r, i[Math.floor(t() * i.length)]], prize: `none` };
  }
  let c = [o, o, o];
  if (
    o === `seven` &&
    i &&
    f[i] &&
    (vi([...e, ...n.map((e) => ({ line: e, star: 1 }))], r)[i] ?? 0) > 0
  )
    return { reels: c, prize: `mon`, line: i };
  if (o === `seven` || o === `cherry`)
    return { reels: c, prize: `gold`, gold: Ua[o] };
  if (o === `ball`)
    return { reels: c, prize: `item`, item: qi(1, t, [], `full`)[0] };
  let l = vi([...e, ...n.map((e) => ({ line: e, star: 1 }))], r),
    u = p.filter((e) => (e.cost === 3 || e.cost === 4) && l[e.id] > 0);
  return u.length
    ? { reels: c, prize: `mon`, line: u[Math.floor(t() * u.length)].id }
    : { reels: c, prize: `gold`, gold: 6 };
}
var ra,
  ia,
  aa,
  oa,
  sa,
  ca,
  la,
  ua,
  da,
  fa,
  pa,
  ma,
  ha,
  ga,
  _a,
  va,
  X,
  ya,
  ba,
  xa,
  Sa,
  Ca,
  wa,
  Ta,
  Ea,
  Da,
  Oa,
  ka,
  Aa,
  ja,
  Ma,
  Na,
  Pa,
  Fa,
  Ia,
  La,
  Ra,
  za,
  Ba,
  Va,
  Ha,
  Ua,
  Wa,
  Ga,
  Ka;
function qa() {
  return (qa = e(() => {
    (s(),
      n(),
      Me(),
      ds(),
      jc(),
      me(),
      ks(),
      S(),
      _(),
      (ia = { 1: 2, 2: 4, 3: 8, 4: 12, 5: 16, 6: 24, 7: 40, 8: 96 }),
      (aa = {
        1: [100, 0, 0, 0, 0],
        2: [100, 0, 0, 0, 0],
        3: [75, 25, 0, 0, 0],
        4: [60, 30, 10, 0, 0],
        5: [50, 36, 13, 1, 0],
        6: [36, 42, 19, 3, 0],
        7: [22, 32, 34, 12, 0],
        8: [14, 22, 32, 26, 6],
        9: [6, 14, 27, 36, 17],
      }),
      (oa = (e, t = 0, n) => (n ?? ia)[e] ?? 1 / 0),
      (sa = {
        spa: `vaporeon`,
        as: `jolteon`,
        mana: `jolteon`,
        crit: `jolteon`,
        atk: `flareon`,
      }),
      (ca = ((ra = f.eevee) == null ? void 0 : ra.branches) ?? []),
      (la = (e) => {
        let t = Re(e) ? ee[e].stat : void 0;
        return (t && sa[t]) || null;
      }),
      (ua = 1 / 200),
      (da = t(`trailer`)),
      (fa = Date.UTC(2026, 9, 8)),
      (pa = [`bulbasaur`, `charmander`, `squirtle`, `pikachu`]),
      (ma = (e) => pa[Math.floor(E(`${e}|starter`)() * pa.length)]),
      (ha = [3, 2, 1, 0]),
      (ga = {
        tank: 3,
        fighter: 3,
        special: 3,
        assassin: 2,
        support: 1,
        mage: 1,
        marksman: 1,
      }),
      (_a = {
        tank: 0,
        fighter: 1,
        special: 2,
        assassin: 3,
        support: 4,
        mage: 5,
        marksman: 6,
      }),
      (va = (e) => {
        var t;
        return (t = b[e]) != null && t.boss ? 10 : 4;
      }),
      (X = {
        stageBase: [2, 3, 4, 5, 6, 8],
        routeBase: 0,
        star: [0, 1, 2, 3],
        costFrom: 4,
        costBonus: 1,
        floorStage: 2,
        floorHp: 10,
      }),
      (ya = (e) => {
        var t;
        return gc(e)
          ? X.routeBase
          : (((t = be[fe(e)]) == null ? void 0 : t.lossBase) ??
              X.stageBase[Math.min(X.stageBase.length - 1, fe(e))] ??
              0);
      }),
      (ba = (e) => {
        var t;
        return (
          ((t = be[fe(e)]) == null ? void 0 : t.floor) ?? fe(e) <= X.floorStage
        );
      }),
      (xa = (e, t) => ya(e) + t.reduce((e, t) => e + zi(t), 0)),
      (Sa = (e) => (yo(e), 5)),
      (Ca = [[2, 1]]),
      (wa = [[2, 1]]),
      (Ta = (e, t) => Math.round(Sa(e) * Math.max(0, Math.min(1, t)))),
      (Ea = (e) =>
        e <
        Math.max(
          0,
          b.findIndex((e) => (e.badge ?? 0) >= 2),
        )),
      (Da = [3, 6]),
      (Oa = new Set([])),
      (ka = (e) => {
        var t;
        return !!((t = b[e]) != null && t.event) || Go(e);
      }),
      (Aa = { 1: 1, 2: 0.85, 3: 0.6, 4: 0.4, 5: 0.3 }),
      (ja = (e) => {
        var t;
        return Aa[((t = f[e]) == null ? void 0 : t.cost) ?? 5] ?? 0.3;
      }),
      (Ma = (e, t = Math.random) => t() < ja(e)),
      (Na = [
        `tauros`,
        `chansey`,
        `scyther`,
        `rhyhorn`,
        `exeggcute`,
        `dratini`,
        `nidoran`,
        `paras`,
      ]),
      (Pa = (e, t = 100) => {
        let n = t - e;
        return n <= 0 ? `full` : n <= 3 ? `top` : `care`;
      }),
      (Fa = {
        care: [`rest`, `care`],
        top: [`rest`, `train`],
        full: [`train`, `tip`],
      }),
      (Ia = `part`),
      (La = (e) => (g(e) || y(e) ? 2 : 4)),
      (Ra = 1.3),
      (za = (e) => (y(e) ? 3 : g(e) ? 4 : 10)),
      (Ba = (e) => {
        var t;
        return e
          ? Math.ceil((((t = f[e]) == null ? void 0 : t.cost) ?? 4) * Ra)
          : 8;
      }),
      (Va = (e, t) => (t < e.items.length ? za(e.items[t]) : Ba(e.mons[0]))),
      (Ha = [
        { p: 0.04, sym: `seven` },
        { p: 0.07, sym: `pika` },
        { p: 0.05, sym: `ball` },
        { p: 0.3, sym: `cherry` },
      ]),
      (Ua = { seven: 20, cherry: 5 }),
      (Wa = [`articuno`, `zapdos`, `moltres`]),
      (Ga = {
        articuno: { hp: 0, gold: 0 },
        zapdos: { hp: 0, gold: 0 },
        moltres: { hp: 0, gold: 0 },
      }),
      (Ka = (e, t = -1) => {
        var n;
        return !((n = b[t]) != null && n.prep);
      }));
  }))();
}
function Ja(e) {
  if (e % 10 == 0) return `legend`;
  if (e % 5 == 0) return `boss`;
  let t = Xa(e);
  return t >= 1 ? Ya[t % 2][(e - 1) % 5] : `floor`;
}
var Ya, Xa, Za;
function Qa() {
  return (Qa = e(() => {
    ((Ya = [
      [`floor`, `mystery`, `floor`, `elite`],
      [`floor`, `center`, `floor`, `elite`],
    ]),
      (Xa = (e) => Math.floor((Math.max(1, e) - 1) / 5)),
      (Za = (e) => {
        let t = Ja(e);
        return t === `center` || t === `mystery`;
      }));
  }))();
}
function $a(e) {
  let t = To(e),
    n = Eo[t],
    r = n ? ne[n] : pi[t];
  return {
    line: r,
    star: Math.min(3, 1 + Math.floor(e / 30)),
    num: n ? Le[n].num : f[r].stages[0],
  };
}
function eo(e) {
  e = He(e);
  let t = `${e}|${Do.chance}|${Do.from}`,
    n = ko.get(t);
  if (n !== void 0) return n;
  let r = E(`${e}|torre|missingno`),
    i = -1;
  for (let e = Math.ceil(Do.from / 10) * 10; e <= 999; e += 10)
    if (r() < Do.chance) {
      i = e;
      break;
    }
  return (ko.size > 200 && ko.clear(), ko.set(t, i), i);
}
function to(e, t) {
  return (
    (t = He(t)),
    e % 10 != 0 || Oo.off ? null : Ao || (e === eo(t) ? `missingno` : Eo[To(e)])
  );
}
function no(e, t, n) {
  let r = Math.min(3, 1 + Math.floor(t / 30)),
    i = x[e],
    a = t >= 60,
    o = a ? (i.hpBig ?? i.hp) : i.hp,
    s = a ? (i.dmgBig ?? i.dmg) : i.dmg;
  return {
    id: e,
    hp: Math.round(o * Mo(n)),
    dmg: de(5) * (1 + (ae(5, r) - 1) * i.dmgStar) * s,
    ...(a ? { big: !0 } : {}),
  };
}
function ro(e, t) {
  let n = [...e];
  for (let e = n.length - 1; e > 0; e--) {
    let r = Math.floor(t() * (e + 1));
    [n[e], n[r]] = [n[r], n[e]];
  }
  return n;
}
function io(e, t) {
  if (((t = He(t)), e < 30)) {
    let n = ro(di, E(`${t}|torre|jefes`));
    return n[Math.floor((e - 5) / 10) % n.length];
  }
  let n = Math.floor((e - 35) / 10),
    r = Math.floor(n / fi.length),
    i = ro(fi, E(`${t}|torre|jefes2|${r}`));
  return i[((n % i.length) + i.length) % i.length];
}
function ao(e, t, n = Z) {
  t = He(t);
  let r = E(`${t}|torre|evento|${e}`),
    i = e % 5 == 0,
    a = 0;
  return (
    i && e >= n.eventFrom
      ? (a = e >= n.eventTwoFrom ? 2 : 1)
      : !i && e >= n.eventHardFrom && r() < n.eventChance && (a = 1),
    ro(No, r).slice(0, a)
  );
}
function oo(e, t, n = Z) {
  var r;
  t = He(t);
  let i = Ja(e) === `elite`,
    a = `${e}|${t}|${Ao ?? ``}`,
    o = n === Z ? Ro.get(a) : void 0;
  if (o) return o;
  let s = E(`${t}|torre|${e}`),
    c = So(e),
    l = ao(e, t, n),
    u = c === `boss` ? io(e, t) : void 0,
    d = c === `legend` ? to(e, t) : null,
    m =
      c === `legend`
        ? {
            line: pi[To(e)],
            star:
              d || e >= n.legend3From ? $a(e).star : Math.min(2, $a(e).star),
          }
        : void 0,
    h = e === 1 ? 1 : Math.min(n.nMax, n.n0 + Math.floor(e * n.nRate)),
    g = u && e < n.boss3From ? Math.min(n.bossN, h) : h,
    ee = Math.min(
      9,
      n.lvl0 +
        Math.floor(e / n.lvlEvery) +
        +(!m && !i && e >= n.lvlUpFrom && e <= n.lvlUpTo),
    ),
    _ = Io[Math.floor(s() * Io.length)],
    v = _;
  for (; v === _;) v = Io[Math.floor(s() * Io.length)];
  let te = s(),
    y = e === 1 ? zo[Math.floor(s() * zo.length)] : null,
    ne = u
      ? u.types
      : m
        ? mi[m.line].types
        : y
          ? [f[y].traits[0]]
          : te < 0.5
            ? [_]
            : [_, v],
    re = u ? 0.85 : 0.7,
    ie = Math.min(
      3,
      e <= n.knee
        ? 1 + e * n.starRate
        : 1 + n.knee * n.starRate + (e - n.knee) * n.starRate2,
    ),
    x = [],
    ae = new Map(),
    oe = (e, t) => {
      let n = p.filter(
          (t) => t.cost === e && (ae.get(t.id) ?? 0) < 2 && !pi.includes(t.id),
        ),
        r = n.filter((e) => e.traits.some((e) => ne.includes(e)));
      (r.length && (t || s() < re) && (n = r),
        n.length ||
          (n = p.filter((e) => (ae.get(e.id) ?? 0) < 2 && e.cost <= 4)));
      let i = n[Math.floor(s() * n.length)];
      return (ae.set(i.id, (ae.get(i.id) ?? 0) + 1), i);
    },
    se = () => {
      let e = Math.floor(ie);
      return Math.min(3, e + +(s() < ie - e));
    };
  if (y) x.push({ line: y, star: 1 });
  else
    for (let e = 0; e < g; e++) {
      let e = s() * 100,
        t = 1;
      for (let n = 0; n < 5; n++) {
        if (e < aa[ee][n]) {
          t = n + 1;
          break;
        }
        e -= aa[ee][n];
      }
      x.push({ line: oe(t, !1).id, star: se() });
    }
  if (
    (x.sort((e, t) => Lo(f[t.line], t.star) - Lo(f[e.line], e.star)),
    m
      ? (x[0] = { line: m.line, star: m.star })
      : u &&
        (x[0] = {
          ...x[0],
          star: Math.min(e < n.boss3From ? 2 : 3, x[0].star + 1),
        }),
    !m)
  )
    for (
      let t = Math.floor((e - n.upFrom) / n.upEvery), r = 0;
      t > 0 && r < x.length;
      r++
    )
      x[r].star === 1 && ((x[r] = { ...x[r], star: 2 }), t--);
  if (l.includes(`swarm`))
    for (let e = 0; e < Po.swarm; e++)
      x.push({ line: oe(1, !0).id, star: Math.max(1, se() - 1) });
  let S = x.map(() => []),
    C =
      Math.floor(Math.max(0, e - n.itemFrom) * n.itemRate) +
      (l.includes(`armory`) ? Po.armory : 0);
  C = Math.min(C, 3 * g);
  for (let e = 0; e < C; e++) S[e % g].push(Fe[Math.floor(s() * Fe.length)]);
  let w = x.map((e, t) => ({
    ...e,
    ...(S[t].length ? { items: S[t] } : {}),
    ...(t === 0 && l.includes(`shadow`) ? { shiny: !0 } : {}),
  }));
  if (i && w.length) {
    w[0] = {
      ...w[0],
      star: Math.max(
        w[0].star,
        Math.min(e < n.boss3From ? 2 : 3, w[0].star + 1),
      ),
    };
    let t = w[Math.min(1, w.length - 1)];
    w.length < n.nMax
      ? w.push({ line: oe(f[t.line].cost, !1).id, star: t.star })
      : w.length > 1 &&
        (w[1] = {
          ...w[1],
          star: Math.max(
            w[1].star,
            Math.min(e < n.boss3From ? 2 : 3, w[1].star + 1),
          ),
        });
  }
  if (!d && n.copies3 < 2) {
    let r = E(`${t}|torre|${e}|copias`),
      i = new Set(w.map((e) => e.line)),
      a = {};
    for (let e = 0; e < w.length; e++) {
      let t = w[e];
      if (t.star !== 3 || (a[t.line] = (a[t.line] ?? 0) + 1) <= n.copies3)
        continue;
      let o = p.filter(
          (e) =>
            e.cost === f[t.line].cost && !i.has(e.id) && !pi.includes(e.id),
        ),
        s = o.filter((e) => e.traits.some((e) => ne.includes(e)));
      if ((s.length && r() < re && (o = s), !o.length)) continue;
      let c = o[Math.floor(r() * o.length)].id;
      (i.add(c), (a[c] = 1), (w[e] = { ...t, line: c }));
    }
  }
  let le = null;
  u
    ? (le =
        ((r = b.find((e) => e.id === u.id)) == null ? void 0 : r.weather) ??
        li[ne[0]] ??
        null)
    : m && (le = li[ne[0]] ?? null);
  let ue = w.reduce((e, t) => e + Lo(f[t.line], t.star), 0),
    T = d
      ? {
          team: [{ line: ce[d], star: m.star, boss: no(d, e, w) }],
          theme: [],
          kind: c,
          weather: d === `gyarados` ? `rain` : null,
          events: l,
          wow: d,
          power: ue,
        }
      : {
          team: w,
          theme: ne,
          kind: c,
          weather: le,
          events: l,
          ...(u ? { boss: u } : {}),
          ...(m ? { legend: m.line } : {}),
          power: ue,
        };
  return (n === Z && (Ro.size > 500 && Ro.clear(), Ro.set(a, T)), T);
}
function so(e, t) {
  t = He(t);
  let n = bo(e),
    r = uo(n, t),
    i = `${n}|${t}|${Ao ?? ``}`,
    a = Bo.get(i);
  if (a) return a;
  let o = oo(n, t),
    s = n <= Z.fastUntil,
    c;
  if (r)
    c = {
      id: `torre-${n}`,
      index: e,
      vid: `a`,
      eventKind: r,
      event: [r],
      name: `${Vr} · ${ke[r].title}`,
      team: [],
      bg: ie[r].bg,
      music: ie[r].music,
    };
  else if (o.boss) {
    let t = b.find((e) => e.id === o.boss.id),
      r = t.name.slice(t.name.lastIndexOf(` · `) + 3);
    c = {
      id: `torre-${n}`,
      index: e,
      vid: `a`,
      eventKind: null,
      name: `${Vr} · ${r}`,
      trainer: t.trainer,
      intro: t.intro,
      introStyle: `gym`,
      team: o.team,
      bg: t.bg,
      music: ui.boss,
    };
  } else if (o.wow) {
    let t = hi[o.wow];
    c = {
      id: `torre-${n}`,
      index: e,
      vid: `a`,
      eventKind: null,
      name: `${Vr} · ${t.name}`,
      intro: t.intro,
      team: o.team,
      bg: t.bg,
      music: ze[o.wow] ?? ui.legend,
      introStyle: `boss`,
      wow: o.wow,
      ...(t.arena ? { pvpArena: t.arena } : {}),
    };
  } else if (o.legend) {
    let t = mi[o.legend],
      r = o.legend === `mewtwo`;
    c = {
      id: `torre-${n}`,
      index: e,
      vid: `a`,
      eventKind: null,
      name: `${Vr} · ${Vo(o.legend)}`,
      intro: t.intro,
      team: o.team,
      bg: t.bg,
      music: ui.legend,
      ...(r
        ? { boss: !0, lair: !0, introStyle: `boss` }
        : { introStyle: `wild` }),
    };
  } else {
    let r = E(`${t}|torre|look|${n}`),
      i = si[o.theme[0]],
      a = i[Math.floor(r() * i.length)];
    c = {
      id: `torre-${n}`,
      index: e,
      vid: `a`,
      eventKind: null,
      name: `${Vr} · ${a.who}`,
      trainer: a.trainer,
      intro: a.intro,
      introStyle: s ? `wild` : `trainer`,
      team: o.team,
      bg: ci[o.theme[0]],
      music: ui.floor,
    };
  }
  return (
    o.weather && (c.weather = o.weather),
    Bo.size > 500 && Bo.clear(),
    Bo.set(i, c),
    c
  );
}
function co(e, t, n, r = {}, i = Z) {
  n = He(n);
  let a = Ho(t, i),
    o = ao(t, n, i),
    s = o.includes(`shadow`)
      ? (e.units.find((e) => e.team === 1 && e.shiny) ?? null)
      : null;
  for (let t of e.units) {
    if (t.team === 0) {
      r.flute && (t.mana = Math.max(t.mana, Math.round(t.maxMana * qo.flute)));
      continue;
    }
    let e = a,
      n = a;
    (t === s && ((e *= 1 + Po.shadow), (n *= 1 + Po.shadow)),
      e !== 1 && ((t.maxHp = Math.round(t.maxHp * e)), (t.hp = t.maxHp)),
      n !== 1 && (t.costMult *= n),
      o.includes(`rage`) && (t.as *= 1 + Po.rage),
      o.includes(`fortress`) && (t.shield += t.maxHp * Po.fortress),
      o.includes(`focus`) &&
        (t.mana = Math.max(t.mana, Math.round(t.maxMana * Po.focus))));
  }
}
function lo(e) {
  return e % 10 == 0
    ? { n: 3, kind: `full`, gift: 0 }
    : e % 5 == 0
      ? { n: 3, kind: `part`, gift: 1 }
      : e % 5 == 3 || Ja(e) === `elite`
        ? { n: 1, kind: `part`, gift: 0 }
        : { n: 0, kind: `part`, gift: 0 };
}
function uo(e, t) {
  t = He(t);
  let n = Ja(e);
  return n === `center`
    ? `center`
    : n === `mystery`
      ? Wo[Math.floor(E(`${t}|torre|respiro|${e}`)() * Wo.length)]
      : null;
}
function fo(e, t, n = [], r = {}) {
  let i = E(`${t}|torre|bendicion|${e}`);
  return {
    floor: e,
    ids: po(i, ns(n, r)),
    item: Fe[Math.floor(i() * Fe.length)],
  };
}
function po(e, t, n = []) {
  let r = [];
  for (; r.length < 3;) {
    let i = t.filter((e) => !r.includes(e));
    i.length || (i = n.filter((e) => !r.includes(e)));
    let a = i.reduce((e, t) => e + Jo[t], 0),
      o = e() * a,
      s = i[i.length - 1];
    for (let e of i)
      if (((o -= Jo[e]), o < 0)) {
        s = e;
        break;
      }
    r.push(s);
  }
  return r;
}
function mo(e, t, n = [], r = {}) {
  let i = E(`${t}|torre|bendicion|${e.floor}|refresco`),
    a = ns(n, r),
    o = po(
      i,
      a.filter((t) => !e.ids.includes(t)),
      a.filter((t) => e.ids.includes(t)),
    );
  return {
    floor: e.floor,
    ids: o,
    item: Fe[Math.floor(i() * Fe.length)],
    rerolled: !0,
  };
}
function ho(e, t) {
  let n = p.filter(
    (t) => t.cost === Math.max(1, Math.min(5, e)) && !pi.includes(t.id),
  );
  return n[Math.floor(t() * n.length)].id;
}
function go(e, t) {
  let n = (e) => {
      var n;
      return (
        (t(e) ? 1e3 : 0) + (((n = f[e.line]) == null ? void 0 : n.cost) ?? 1)
      );
    },
    r = (t) => e.filter(t).sort((e, t) => n(t) - n(e))[0] ?? null;
  return (
    r((e) => e.star === 1) ??
    r((e) => {
      var t;
      return (
        e.star === 2 && (((t = f[e.line]) == null ? void 0 : t.cost) ?? 9) <= 2
      );
    })
  );
}
function _o(e) {
  let t = e && typeof e == `object` ? e : {},
    n = (e, t) =>
      typeof e == `number` && Number.isFinite(e)
        ? Math.max(0, Math.min(t, e))
        : 0,
    r = t.offer,
    i =
      r &&
      typeof r == `object` &&
      Number.isInteger(r.floor) &&
      Array.isArray(r.ids) &&
      r.ids.length === 3 &&
      r.ids.every(os) &&
      typeof r.item == `string` &&
      Fe.includes(r.item)
        ? {
            floor: r.floor,
            ids: r.ids,
            item: r.item,
            ...(r.rerolled === !0 ? { rerolled: !0 } : {}),
          }
        : null;
  return {
    boons: Array.isArray(t.boons) ? t.boons.filter(os).slice(0, 200) : [],
    offer: i,
    master: t.master === !0,
    ash: Math.round(n(t.ash, 9)),
    losses: Math.round(n(t.losses, 9999)),
    simTime: n(t.simTime, 1e7),
    ...(t.dupe === !0 ? { dupe: !0 } : {}),
  };
}
var vo,
  yo,
  bo,
  xo,
  Z,
  So,
  Co,
  wo,
  To,
  Eo,
  Do,
  Oo,
  ko,
  Ao,
  jo,
  Mo,
  No,
  Po,
  Fo,
  Io,
  Lo,
  Ro,
  zo,
  Bo,
  Vo,
  Ho,
  Uo,
  Wo,
  Go,
  Ko,
  qo,
  Jo,
  Yo,
  Xo,
  Zo,
  Qo,
  $o,
  es,
  ts,
  ns,
  rs,
  is,
  as,
  os,
  ss,
  cs,
  ls,
  us;
function ds() {
  return (ds = e(() => {
    (Me(),
      S(),
      s(),
      Pe(),
      gi(),
      qa(),
      lt(),
      Qa(),
      _(),
      w(),
      Be(),
      (vo = 1e3),
      (yo = (e) => e >= vo),
      (bo = (e) => Math.max(1, Math.floor(e) - vo + 1)),
      (xo = (e) => vo + Math.max(1, Math.floor(e)) - 1),
      (Z = {
        hp: 100,
        n0: 2,
        nRate: 0.28,
        nMax: 9,
        lvl0: 3,
        lvlEvery: 5,
        lvlUpFrom: 16,
        lvlUpTo: 24,
        starRate: 0.05,
        knee: 15,
        starRate2: 0.024,
        upFrom: 2,
        upEvery: 4,
        itemFrom: 4,
        itemRate: 0.25,
        boss3From: 30,
        bossN: 8,
        pressFrom: 40,
        pressRate: 0.03,
        lossBase: 2,
        lossStep: 5,
        boonEvery: 10,
        eventFrom: 9999,
        eventTwoFrom: 35,
        eventHardFrom: 9999,
        eventChance: 0.35,
        fastUntil: 9,
        copies3: 1,
        legend3From: 90,
      }),
      (So = (e) => (e % 10 == 0 ? `legend` : e % 5 == 0 ? `boss` : `floor`)),
      (Co = (e) => {
        let t = Math.max(5, Math.ceil(e / 5) * 5);
        return (t % 10 == 0 && (t += 5), t);
      }),
      (wo = (e) => Math.max(10, Math.ceil(e / 10) * 10)),
      (To = (e) => (Math.max(1, Math.floor(e / 10)) - 1) % pi.length),
      (Eo = [`snorlax`, `gyarados`, null, `marowak`, null]),
      (Do = { chance: 0.15, from: 20 }),
      (Oo = { off: !1 }),
      (ko = new Map()),
      (Ao = null),
      (jo = (e) => {
        ((Ao = e), Ro.clear(), Bo.clear());
      }),
      (Mo = (e) =>
        e.reduce((e, t) => {
          let n = f[t.line];
          return e + ge(n, t.star, ye[l(n, t.star).num]).maxHp;
        }, 0)),
      (No = [`rage`, `fortress`, `swarm`, `focus`, `shadow`, `armory`]),
      (Po = {
        rage: 0.3,
        fortress: 0.25,
        swarm: 2,
        focus: 0.5,
        shadow: 0.25,
        armory: 2,
      }),
      (Fo = {
        rage: `💢`,
        fortress: `🛡️`,
        swarm: `🐝`,
        focus: `🔮`,
        shadow: `🌑`,
        armory: `🎒`,
      }),
      (Io = Object.keys(pe).filter(
        (e) => pe[e].thresholds[0] > 1 && p.some((t) => t.traits.includes(e)),
      )),
      (Lo = (e, t) => (1 + 0.35 * (e.cost - 1)) * [1, 1.9, 3.6][t - 1]),
      (Ro = new Map()),
      (zo = [`caterpie`, `magikarp`, `oddish`]),
      (Bo = new Map()),
      (Vo = (e) => e.charAt(0).toUpperCase() + e.slice(1)),
      (Ho = (e, t = Z) => 1 + Math.max(0, e - t.pressFrom) * t.pressRate),
      (Uo = (e, t, n = Z) =>
        n.lossBase +
        Math.floor(e / n.lossStep) +
        t.reduce((e, t) => e + zi(t), 0)),
      (Wo = [`mall`, `shop`, `safari`]),
      (Go = (e) => yo(e) && Za(bo(e))),
      (Ko = [
        `potion`,
        `nugget`,
        `amulet`,
        `candy`,
        `expshare`,
        `item`,
        `vitamins`,
        `egg`,
        `moonstone`,
        `wonder`,
        `master`,
        `ash`,
        `coincase`,
        `flute`,
      ]),
      (qo = {
        potion: 40,
        nugget: 25,
        amulet: 2,
        expshare: 2,
        vitamins: 4,
        eggCost: 4,
        eggStar: 2,
        ash: 2,
        coincase: 1,
        flute: 0.4,
        masterStar: 2,
        fallbackGold: 10,
      }),
      (Jo = {
        potion: 3,
        nugget: 3,
        amulet: 2,
        candy: 3,
        expshare: 2,
        item: 3,
        vitamins: 2,
        egg: 2,
        moonstone: 2,
        wonder: 1,
        master: 1,
        ash: 2,
        coincase: 1,
        flute: 2,
      }),
      (Yo = {
        potion: `max-potion`,
        nugget: `big-nugget`,
        amulet: `amulet-coin`,
        candy: `rare-candy`,
        expshare: `exp-share`,
        item: ``,
        vitamins: `zinc`,
        egg: `mystery-egg`,
        moonstone: `moon-stone`,
        wonder: `poke-ball`,
        master: `master-ball`,
        ash: `sacred-ash`,
        coincase: `coin-case`,
        flute: `poke-flute`,
      }),
      (Xo = [`amulet`, `expshare`, `coincase`, `flute`]),
      (Zo = [`coincase`, `flute`]),
      (Qo = [`amulet`, `expshare`, `ash`]),
      ($o = [`master`]),
      (es = (e, t = Z) =>
        t.boonEvery > 0 && e > 1 && (e - 1) % t.boonEvery == 0),
      (ts = (e, t) =>
        (t.maxLevel === !0 && (e === `candy` || e === `expshare`)) ||
        (t.fullHp === !0 && e === `potion`) ||
        (t.noMoonTarget === !0 && e === `moonstone`)),
      (ns = (e, t) =>
        Ko.filter((n) => !(Zo.includes(n) && e.includes(n)) && !ts(n, t))),
      (rs = (e, t) => {
        let n = E(`${t}|torre|vitaminas|${e}`);
        return Array.from(
          { length: qo.vitamins },
          () => v[Math.floor(n() * v.length)],
        );
      }),
      (is = (e, t) => {
        let n = f[e];
        return !n || n.cost >= 5 ? e : ho(Math.min(4, n.cost + 1), t);
      }),
      (as = () => ({
        boons: [],
        offer: null,
        master: !1,
        ash: 0,
        losses: 0,
        simTime: 0,
      })),
      (os = (e) => typeof e == `string` && Ko.includes(e)),
      (ss = (e) => e.filter((e) => e === `amulet`).length * qo.amulet),
      (cs = (e) => e.filter((e) => e === `expshare`).length * qo.expshare),
      (ls = (e, t) => (e.includes(`coincase`) ? Math.min(t, qo.coincase) : t)),
      (us = (e, t) =>
        t.floor - e.floor || e.losses - t.losses || e.simTime - t.simTime));
  }))();
}
function fs(e, t = zr()) {
  var n;
  let r = xs(e);
  return r === 1 ? [] : (((n = Mt[t]) == null ? void 0 : n[r]) ?? []);
}
function ps(e, t, n) {
  if (t < 0 || t >= 1e3 || !b[t] || b[t].event) return !1;
  let r = e.at ?? n;
  return !(
    (r === `boss` && !Cs(t)) ||
    (r === `final` && t !== b.length - 1) ||
    (e.from && t < Math.floor(e.from * b.length))
  );
}
function ms(e, t, n) {
  let r = 0;
  for (let i of fs(n))
    i.k === `vit` && ps(i, e, `all`) && ws(t, i.type) && (r += i.v);
  return r;
}
function hs(e) {
  let t = f[e.line];
  if (!t) return [];
  if (t.role === `tank`) return [`leftovers`, `rocky-helmet`, `assault-vest`];
  let n = he(t, e.star);
  return [
    n ? `choice-band` : `choice-specs`,
    `life-orb`,
    n ? `scope-lens` : `shell-bell`,
  ];
}
function gs(e, t, n, r = !1) {
  let i = fs(n).filter(
    (e) => (e.k === `armory` || e.k === `ace`) && ps(e, t, `boss`),
  );
  if (!i.length || !e.length) return e;
  let a = e.map((e) => ({ ...e, ...(e.items ? { items: [...e.items] } : {}) })),
    o = Ee(a, r).filter((e) => !a[e].boss && f[a[e].line]);
  for (let e of i) {
    if (e.k === `ace`) {
      let e = o[0];
      e !== void 0 && a[e].star < 3 && a[e].star++;
      continue;
    }
    if (e.k !== `armory`) continue;
    let t = e.v;
    for (let e of o) {
      if (t <= 0) break;
      let n = a[e].items ?? [];
      for (let r of hs(a[e])) {
        if (t <= 0 || n.length >= 3) break;
        n.includes(r) || (n.push(r), t--);
      }
      a[e].items = n;
    }
  }
  return a;
}
function _s(e, t, n) {
  let r = fs(n).filter(
    (e) =>
      (e.k === `rage` || e.k === `fortress` || e.k === `focus`) &&
      ps(e, t, `boss`),
  );
  if (r.length) {
    for (let t of e.units)
      if (t.team === 1)
        for (let e of r)
          (e.k === `rage` || e.k === `fortress` || e.k === `focus`) &&
            (!e.type || t.types.includes(e.type) || ws(t.line, e.type)) &&
            (e.k === `rage`
              ? (t.as *= 1 + e.v)
              : e.k === `fortress`
                ? (t.shield += t.maxHp * e.v)
                : (t.mana = Math.max(t.mana, Math.round(t.maxMana * e.v))));
  }
}
function vs(e, t) {
  let n = [];
  for (let r of fs(t)) {
    if (r.k === `trainers` || !ps(r, e, r.k === `vit` ? `all` : `boss`))
      continue;
    let t = `type` in r ? r.type : void 0,
      i = r.k === `ace` ? 1 : r.v,
      a = n.find((e) => e.k === r.k && e.type === t);
    a
      ? r.k === `focus`
        ? (a.v = Math.max(a.v, i))
        : r.k !== `ace` && (a.v += i)
      : n.push({ k: r.k, v: i, ...(t ? { type: t } : {}) });
  }
  return n;
}
function ys(e, t = zr()) {
  var n;
  let r = fs(e, t);
  if (!r.length) return [];
  let i = ((n = J[t]) == null ? void 0 : n.rounds) ?? b,
    a = i.length,
    o = i[a - 1],
    s = !!o && !o.route && !o.canLose && (!!o.badge || !!o.league || !!o.boss),
    c = (e) => ({
      at:
        (`at` in e && e.at) ||
        (e.k === `trainers` || e.k === `vit` ? `all` : `boss`),
      ...(`type` in e && e.type ? { type: e.type } : {}),
      from: `from` in e && e.from ? Math.floor(e.from * a) : 0,
    }),
    l = (e, t) =>
      (!e.type || e.type === t.type) &&
      Ds[e.at] <= Ds[t.at] &&
      (t.at !== `final` || e.at !== `boss` || s) &&
      (t.at === `final` || e.from <= t.from),
    u = [];
  for (let e of r) {
    let t = c(e),
      n = u.find(
        (e) =>
          e.who.at === t.at && e.who.type === t.type && e.who.from === t.from,
      );
    (n || u.push((n = { who: t, pieces: [] })),
      n.pieces.some((t) => t.k === e.k) || n.pieces.push({ k: e.k, v: 0 }));
  }
  for (let e of u)
    for (let t of e.pieces)
      for (let n of r) {
        if (n.k !== t.k || !l(c(n), e.who)) continue;
        let r = n.k === `ace` || n.k === `trainers` ? 1 : n.v;
        t.v =
          n.k === `focus`
            ? Math.max(t.v, r)
            : n.k === `ace` || n.k === `trainers`
              ? 1
              : t.v + r;
      }
  return u.sort(
    (e, t) =>
      Ds[e.who.at] - Ds[t.who.at] ||
      e.who.from - t.who.from ||
      +!!e.who.type - !!t.who.type,
  );
}
function bs(e, t) {
  let n = (e, t) => e.at === t.at && e.type === t.type && e.from === t.from;
  return e
    .map((e) => {
      let r = t.find((t) => n(t.who, e.who));
      return {
        who: e.who,
        pieces: e.pieces.filter(
          (e) =>
            !(r != null && r.pieces.some((t) => t.k === e.k && t.v === e.v)),
        ),
      };
    })
    .filter((e) => e.pieces.length > 0);
}
var xs, Ss, Cs, ws, Ts, Es, Ds, Os;
function ks() {
  return (ks = e(() => {
    (Me(),
      Nt(),
      S(),
      s(),
      Br(),
      jt(),
      ds(),
      _(),
      (xs = (e) => Ct(e)),
      (Ss = (e) => !!Mt[e]),
      (Cs = (e) => {
        let t = b[e];
        return (
          !!t && !t.route && !t.canLose && (!!t.badge || !!t.league || !!t.boss)
        );
      }),
      (ws = (e, t) => {
        var n;
        return !t || !!((n = f[e]) != null && n.traits.includes(t));
      }),
      (Ts = (e) => fs(e).some((e) => e.k === `trainers`)),
      (Es = (e, t) =>
        fs(t).some(
          (t) =>
            (t.k === `rage` || t.k === `fortress` || t.k === `focus`) &&
            ps(t, e, `boss`),
        )),
      (Ds = { all: 0, boss: 1, final: 2 }),
      (Os = (e = zr()) => {
        var t;
        return !!(
          (t = J[e]) != null && t.rounds.some((e) => e.badge || e.league)
        );
      }));
  }))();
}
function As(e, t) {
  var n;
  let r =
    ((n = b[t]) == null ? void 0 : n.team.filter((e) => e.ward).length) ?? 0;
  if (!r) return [];
  let i = e.units.filter((e) => e.team === 1);
  return i.slice(i.length - r);
}
function js(e, t) {
  var n;
  let r = ((n = b[t]) == null || (n = n.ward) == null ? void 0 : n.hp) ?? 1;
  for (let n of As(e, t))
    (r !== 1 &&
      ((n.maxHp = Math.max(1, Math.round(n.maxHp * r))), (n.hp = n.maxHp)),
      (n.atkCd = 1 / 0),
      (n.mana = 0),
      (n.maxMana = Is),
      (n.manaRegen = 0),
      (n.range = 99));
}
function Ms(e, t) {
  var n;
  let r = (n = b[t]) == null ? void 0 : n.ward;
  if (!r || e.winner !== 0) return null;
  let i = As(e, t);
  if (!i.length) return null;
  let a = e.units.filter(
      (e) => e.team === 1 && !i.includes(e) && e.line === r.guard,
    ),
    o = a.length ? a : e.units.filter((e) => e.team === 1 && !i.includes(e)),
    s = Math.max(...o.map((e) => (e.alive ? 1 / 0 : e.tFaint)));
  return i.every((e) => e.alive || e.tFaint >= s - 1e-9);
}
function Ns(e, t, n) {
  return Rs(n) < 0 || !f[t] ? e : !e || !f[e] || f[t].cost >= f[e].cost ? t : e;
}
function Ps(e, t, n) {
  var r;
  let i = (r = b[t]) == null ? void 0 : r.takes;
  return i === void 0 || !n || !f[n] || !e[i]
    ? e
    : e.map((e, t) => (t === i ? { ...e, line: n } : e));
}
var Fs, Is, Ls, Rs, zs, Bs;
function Vs() {
  return (Vs = e(() => {
    (Me(),
      s(),
      (Fs = (e) => {
        var t;
        return (
          !!((t = b[e]) != null && t.ward) && b[e].team.some((e) => e.ward)
        );
      }),
      (Is = 9999),
      (Ls = (e) => {
        var t;
        let n = b[e];
        if (!(n != null && n.ward)) return null;
        let r =
          n.ward.gift ??
          ((t = n.team.find((e) => e.ward)) == null ? void 0 : t.line) ??
          null;
        return r && f[r] ? r : null;
      }),
      (Rs = (e) => b.findIndex((t, n) => n > e && t.takes !== void 0)),
      (zs = (e, t) => (t ? Math.min(1, e * t.catch) : e)),
      (Bs = (e, t) =>
        (t && (e == null ? void 0 : e.find((e) => e.id === t))) || null));
  }))();
}
function Hs(e, t, n, r, i = !1) {
  let a = e.map((e) => ({ ...e }));
  if (a.length < 3) return a;
  let o = E(`${n}|entrenador|${r}`),
    s = Ee(a, i)[0],
    c = Math.min(Ws[t], Math.floor(a.length / 2)),
    l = a.map((e, t) => t).filter((e) => e !== s && !a[e].boss && f[a[e].line]);
  for (let e = 0; e < c && l.length; e++) {
    let e = l.splice(Math.floor(o() * l.length), 1)[0],
      t = f[a[e].line],
      n = new Set(a.map((e) => e.line)),
      r = p.filter(
        (e) =>
          e.cost < 5 &&
          !Gs.has(e.id) &&
          !n.has(e.id) &&
          Math.abs(e.cost - t.cost) <= 1 &&
          e.traits[0] === t.traits[0],
      );
    if (!r.length) continue;
    let i = r[Math.floor(o() * r.length)];
    a[e] = { ...a[e], line: i.id };
  }
  return a;
}
function Us(e, t) {
  let [n, r] = ve(t);
  if ((!n && !r) || !e.length) return e.map((e) => ({ ...e }));
  let i = e.map((e) => [...(e.items ?? [])]),
    a = (t) => t.sort((t, n) => Ks(e[n]) - Ks(e[t]) || t - n),
    o = e.map((e, t) => t).filter((t) => f[e[t].line]),
    s = a(o.filter((t) => f[e[t].line].role === `tank`)),
    c = a(o.filter((t) => f[e[t].line].role !== `tank`));
  c.length || (c = s.slice());
  let l = (t) => he(f[e[t].line], e[t].star),
    u = (e) => i[e].length < 2,
    d = (e, t) =>
      e === void 0 || !u(e) || i[e].includes(t) ? !1 : (i[e].push(t), !0),
    p = [],
    m = s[0];
  c.forEach((e, t) => {
    (p.push([e, qs(l(e))]),
      t === 0 && p.push([m, `leftovers`]),
      p.push([e, `life-orb`]),
      t === 0 && p.push([m, `rocky-helmet`]));
  });
  for (let e of s.slice(1)) p.push([e, `leftovers`]);
  let h = 0;
  for (let [e, t] of p) {
    if (h >= n) break;
    d(e, t) && h++;
  }
  for (let e of a(o.slice())) {
    if (h >= n) break;
    d(e, l(e) ? `scope-lens` : `quick-claw`) && h++;
  }
  let g = [c[0], m, ...c.slice(1), ...s.slice(1)].filter((e) => e !== void 0);
  for (let t = 0; t < r && g.length; t++) {
    let n = g[t % g.length];
    i[n].push(f[e[n].line].role === `tank` ? `hp-up` : Js(l(n)));
  }
  return e.map((e, t) => (i[t].length ? { ...e, items: i[t] } : { ...e }));
}
var Ws, Gs, Ks, qs, Js;
function Ys() {
  return (Ys = e(() => {
    (Me(),
      S(),
      s(),
      _(),
      (Ws = { trainer: 1, gym: 2, league: 2 }),
      (Gs = new Set([`ditto`, `magikarp`])),
      (Ks = (e) => {
        var t;
        return (
          (((t = f[e.line]) == null ? void 0 : t.cost) ?? 1) * 3 ** (e.star - 1)
        );
      }),
      (qs = (e) => (e ? `choice-band` : `choice-specs`)),
      (Js = (e) => (e ? `protein` : `calcium`)));
  }))();
}
function Xs(e, t) {
  let n = [...e, t],
    r = wc(n);
  return r.length === 1 ? [...n, r[0]] : n;
}
function Zs(e, t) {
  let n = new Set(),
    r = (Array.isArray(e) ? e : [])
      .filter((e) => Sc(e) && !n.has(e) && !!n.add(e))
      .slice(0, 3),
    i = Q.filter((e) => e >= 0 && t > e).length;
  for (let e of yc) r.length < i && !r.includes(e) && (r = [...r, e]);
  return (r.length === 2 && (r = [...r, wc(r)[0]]), r);
}
function Qs(e, t, n, r) {
  if (n === t) return e;
  if (r != null && r[n]) return r[n];
  let i = e.map((e) => ({ ...e }));
  for (let e = t; e !== n; e += n > t ? 1 : -1) {
    let r = e + (n > t ? 1 : -1);
    if (r < e) {
      i = i.slice(0, Math.max(1, Math.min(i.length, Ec[r])));
      let e = i.findIndex((e, t) => t > 0 && e.star >= 3);
      e > 0 && (i[e].star = 2);
    } else {
      let t = i.slice(1).map((e) => e.line),
        n = Math.min(Dc, i.length + Ec[r] - Ec[e]);
      for (let e = 0; i.length < n && t.length; e++)
        i.push({ line: t[e % t.length], star: r === 6 && e === 0 ? 2 : 1 });
    }
  }
  return i;
}
function $s(e, t) {
  var n;
  let r = b[e],
    i = 1 + ((r == null || (n = r.variants) == null ? void 0 : n.length) ?? 0);
  return t === void 0 || i === 1
    ? 0
    : Math.floor(E(`${t}|route|${r.route ? r.id : lc(e)}`)() * i);
}
function ec(e, t, n) {
  var r;
  if (e >= 1e3) return uo(bo(e), t);
  if (!((r = b[e]) != null && r.event)) return null;
  let i = E(`${t}|events`),
    a = {};
  for (let t = 0; t <= e; t++) {
    var o;
    let n = b[t],
      r = n.event;
    if (!r) continue;
    let s = r,
      c = i(),
      l = s.filter((e) => (a[e] ?? 0) < ue[e]),
      u =
        (o = n.eventMust) == null
          ? void 0
          : o.find((e) => !a[e] && s.includes(e)),
      d = (l.length ? l : s).flatMap((e) => {
        var t;
        return Array.from(
          {
            length: Math.max(
              1,
              Math.round(((t = n.eventWeight) == null ? void 0 : t[e]) ?? 1),
            ),
          },
          () => e,
        );
      }),
      f = u ?? d[Math.floor(c * d.length)];
    if (((a[f] = (a[f] ?? 0) + 1), t === e)) return f;
  }
  return null;
}
function tc(e, t, n, r = !1) {
  let [i, a] = ve(t);
  if ((!i && !a) || !e.length) return e.map((e) => ({ ...e }));
  let o = e.map((e) => [...(e.items ?? [])]),
    s = Ee(e, r),
    c = (t) => {
      var n;
      return (n = f[e[t].line]) == null ? void 0 : n.role;
    },
    l = 0;
  for (let [t, r] of h[n ?? `none`] ?? []) {
    if (l >= i) break;
    let n = s.find(
      (n) => e[n].line === t && !o[n].includes(r) && o[n].length < 2,
    );
    n !== void 0 && (o[n].push(r), l++);
  }
  for (let e of s) {
    if (l >= i) break;
    let t = c(e);
    !o[e].length && t && (o[e].push(je[t]), l++);
  }
  for (let e = 0; e < a; e++) {
    let t = s[e % s.length],
      n = c(t);
    n && o[t].push(De[n]);
  }
  return e.map((e, t) => (o[t].length ? { ...e, items: o[t] } : { ...e }));
}
function nc(e, t, n, r = !1) {
  var i;
  if (n && (i = e.starterTeam) != null && i[n]) return e.starterTeam[n];
  let a = (t == null ? void 0 : t.rivalTeam) ?? e.rivalTeam;
  if (a && n && n in Ae) return a(Ae[n]);
  let o = t
    ? (t.trainerTeam ?? (t.team ? void 0 : e.trainerTeam))
    : e.trainerTeam;
  return r && o ? o : ((t == null ? void 0 : t.team) ?? e.team);
}
function rc(e, t = {}) {
  var n, r, i, a, o;
  if (e >= 1e3) return so(e, t.seed ?? ``);
  let s = Math.max(0, Math.min(b.length - 1, Math.floor(e) || 0)),
    c = xs(t.league),
    l = Ts(c),
    u = ic(s, t.meter),
    d =
      t.sneakAt === s &&
      !!((n = b[s]) != null && (n = n.sneakTeam) != null && n.length),
    f = b[s].bossKey,
    p = f && (r = t.keys) != null && r.includes(f.key) ? f.key : void 0,
    m = `${s}|${t.seed ?? ``}|${t.starter ?? ``}|${((i = t.gymOrder) == null ? void 0 : i.join(`,`)) ?? ``}|${c > 1 ? `L${c}` : ``}${u ? `|m${u}` : ``}${d ? `|s` : ``}${t.lost && ((a = b[s]) == null ? void 0 : a.takes) !== void 0 ? `|${t.lost}` : ``}${p ? `|K${p}` : ``}`,
    h = kc.get(m);
  if (h) return h;
  let g = Cc(s),
    ee = g >= 0 ? ((o = t.gymOrder) == null ? void 0 : o[g]) : void 0,
    _ = ee ? bc[ee] : s,
    v = b[_],
    te = $s(_, t.seed),
    y = te > 0 ? v.variants[te - 1] : null,
    {
      variants: ne,
      rivalTeam: re,
      starterTeam: x,
      eventMust: ae,
      eventPlace: oe,
      eventWeight: se,
      tiers: ce,
      ...S
    } = v,
    C = d ? b[s].sneakTeam.map((e) => ({ ...e })) : nc(v, y, t.starter, l);
  if (((C = Ps(C, _, t.lost)), g >= 0)) {
    let e = 4 + Cc(_);
    C = Qs(C, e, 4 + g, y ? y.tiers : v.tiers);
  }
  let w = !!(v.rivalTeam || (y != null && y.rivalTeam));
  C = we(C, s, w);
  let le = y ? (y.trainer ?? v.trainer) : v.trainer,
    ue =
      v.event || v.boss || !le
        ? null
        : v.badge
          ? `gym`
          : v.league
            ? `league`
            : `trainer`;
  (l && ue && (C = Hs(C, ue, t.seed ?? ``, v.id ?? String(_), w)),
    v.event || (C = l ? Us(C, s) : tc(C, s, le, w)),
    c > 1 && (C = gs(C, s, c, w)),
    u && (C = [...C, ...b[s].meterTeam.slice(0, u).map((e) => ({ ...e }))]),
    p &&
      f &&
      (C = C.map((e) =>
        e.boss ? { ...e, boss: { ...e.boss, ...f.boss } } : e,
      )));
  let T = {
      ...S,
      index: s,
      vid: (y == null ? void 0 : y.vid) ?? v.vid ?? `a`,
      name: (y == null ? void 0 : y.name) ?? v.name,
      trainer: le,
      team: C,
      bg: (y == null ? void 0 : y.bg) ?? v.bg,
      music: (y == null ? void 0 : y.music) ?? v.music,
      intro:
        (d ? v.sneakIntro : void 0) ??
        (y == null ? void 0 : y.intro) ??
        v.intro,
      eventKind: null,
      ...(p ? { keyOn: p } : {}),
    },
    de = v.weather ?? null;
  if ((de ? (T.weather = de) : delete T.weather, v.event)) {
    let e = v.event[0],
      n = t.seed === void 0 ? e : (ec(s, t.seed, t.league) ?? e);
    if (((T.eventKind = n), (T.event = [n]), n !== v.event[0])) {
      var fe;
      ((T.name = `${((fe = v.eventPlace) == null ? void 0 : fe[n]) ?? Oc(v.name)} · ${ke[n].title}`),
        (T.bg = ie[n].bg),
        (T.music = ie[n].music));
    }
  }
  return (kc.size > 2e3 && kc.clear(), kc.set(m, T), T);
}
function ic(e, t) {
  var n;
  let r = (n = b[e]) == null ? void 0 : n.meterTeam;
  return r != null && r.length && t && t > 0
    ? Math.min(r.length, Math.floor(t))
    : 0;
}
var ac,
  oc,
  sc,
  cc,
  lc,
  uc,
  dc,
  fc,
  pc,
  mc,
  hc,
  gc,
  _c,
  vc,
  yc,
  Q,
  bc,
  xc,
  Sc,
  Cc,
  wc,
  Tc,
  Ec,
  Dc,
  Oc,
  kc,
  Ac;
function jc() {
  return (jc = e(() => {
    (Me(),
      s(),
      ks(),
      Vs(),
      Ys(),
      ds(),
      (ac = (e) => !!e.route || !!e.prep),
      (oc = (e) => {
        let t = -1;
        return e.map((e) => (ac(e) ? Math.max(0, t) : ++t));
      }),
      (sc = oc(b)),
      (cc = (e) => Math.max(0, Math.min(b.length - 1, Math.floor(e) || 0))),
      (lc = (e) => sc[cc(e)]),
      (uc = T.flatMap((e, t) => (ac(e) ? [] : [t]))),
      (dc = (e) =>
        Number.isInteger(e) && e >= 0 && e < uc.length ? uc[e] : e),
      (fc = (e) => (e >= uc.length ? T.length : e >= 1 ? dc(e - 1) + 1 : e)),
      (pc =
        `ruta2.bosque.oak.brock.puente.azul.misty.ruta6.carmin.ssanne.surge.tunel.azulona.escondite.gym4.ruta12.fucsia.gym5.espuma.silph.gym6.mansion.blaine.ruta21.giovanni.ruta22.victoria.lorelei.bruno.agatha.lance.campeon.mewtwo`
          .split(`.`)
          .map((e) => T.findIndex((t) => t.id === e))),
      (mc = (e) =>
        Number.isInteger(e) && e >= 0 && e < pc.length ? pc[e] : e),
      (hc = (e) => (e >= pc.length ? T.length : e >= 1 ? mc(e - 1) + 1 : e)),
      (gc = (e) => {
        var t;
        return ((t = b[e]) == null ? void 0 : t.route) ?? null;
      }),
      (_c = (e) => {
        var t;
        return !!((t = b[e]) != null && t.quick);
      }),
      (vc = (e) => {
        let t = b.findIndex((t) => t.id === e);
        if (t < 0 && b === T) throw Error(`route: falta la parada ${e}`);
        return t;
      }),
      (yc = [`erika`, `koga`, `sabrina`]),
      (Q = [vc(`gym4`), vc(`gym5`), vc(`gym6`)]),
      (bc = { erika: Q[0], koga: Q[1], sabrina: Q[2] }),
      (xc = { erika: `Grass`, koga: `Poison`, sabrina: `Psychic` }),
      (Sc = (e) => e === `erika` || e === `koga` || e === `sabrina`),
      (Cc = (e) => Q.indexOf(e)),
      (wc = (e) => yc.filter((t) => !e.includes(t))),
      (Tc = (e, t) => {
        let n = Cc(e);
        return n >= 0 && n < 2 && t.length <= n;
      }),
      (Ec = { 4: 5, 5: 6, 6: 8 }),
      (Dc = 8),
      (Oc = (e) => {
        let t = e.lastIndexOf(` · `);
        return t >= 0 ? e.slice(0, t) : e;
      }),
      (kc = new Map()),
      Oe(() => {
        ((sc = oc(b)),
          (Q = [vc(`gym4`), vc(`gym5`), vc(`gym6`)]),
          (bc = { erika: Q[0], koga: Q[1], sabrina: Q[2] }),
          kc.clear());
      }),
      (Ac = (e, t = {}) => rc(e, t).team));
  }))();
}
function Mc(e, t = []) {
  let n = e.slice(0, 9);
  for (; n.length < 9;) n.push(null);
  let r = t.filter((e) => !n.includes(e));
  for (let t of e.slice(9)) {
    if (!t) continue;
    let e = n.indexOf(null);
    e >= 0 ? (n[e] = t) : r.includes(t) || (r = [...r, t]);
  }
  return {
    bench: n,
    floor: r.length === t.length && r.every((e, n) => e === t[n]) ? t : r,
  };
}
function Nc(e, t, n = null, r = !1) {
  let i = (t) =>
      Object.values(e.board).includes(t.id) ? 2 : +!e.floor.includes(t.id),
    a = () =>
      n
        ? Object.values(e.units).filter((e) => !n.has(e.id))
        : Object.values(e.units);
  for (let n = ji(a(), i); n; n = ji(a(), i)) {
    let i = n.gone.flatMap((t) => {
      var n;
      return ((n = e.units[t.id]) == null ? void 0 : n.items) ?? [];
    });
    for (let t of n.gone) {
      (delete e.units[t.id],
        (e.bench = e.bench.map((e) => (e === t.id ? null : e))),
        (e.floor = e.floor.filter((e) => e !== t.id)));
      for (let [n, r] of Object.entries(e.board))
        r === t.id && delete e.board[+n];
    }
    let a = e.units[n.keep.id],
      o = l(f[a.line], a.star).num,
      { kept: s, spare: c } = Yi(a.items ?? [], i);
    c.length && (e.items = [...e.items, ...c]);
    let u = !!a.shiny || n.gone.some((e) => e.shiny),
      d = a.star + 1,
      { items: p, shiny: m, ...h } = a;
    ((e.units[a.id] = {
      ...h,
      line: Ti(
        a.line,
        d,
        s,
        Object.values(e.board)
          .map((t) => e.units[t])
          .filter(Boolean),
        n.gone.map((e) => e.line),
        r,
      ),
      star: d,
      ...(s.length ? { items: s } : {}),
      ...(u ? { shiny: u } : {}),
    }),
      t.push({ k: `evolved`, unit: e.units[a.id], prev: a, prevNum: o }));
  }
}
function Pc(e, t, n) {
  if (Se(e) <= 8) return { items: e, itemQueue: t };
  let { keep: r, over: i } = te(e);
  return (
    n.push({ k: `bagQueue`, n: i.length > 1 ? i.length : 1 }),
    { items: r, itemQueue: [...t, ...i] }
  );
}
function Fc(e) {
  if (!e.itemQueue.length) return e;
  let t = Ic(e.items, e.itemQueue);
  return t ? { ...e, ...t } : e;
}
function Ic(e, t) {
  let n = [...e],
    r = [];
  for (let e of t) (Ce(n, e) ? n : r).push(e);
  return r.length === t.length ? null : { items: n, itemQueue: r };
}
function Lc(e, t, n, r) {
  Nc(t, r, Kc(e.phase) ? new Set(Object.values(t.board)) : null, !!e.eeveeKeep);
  let i = Mc(t.bench, t.floor),
    a = Pc(t.items, e.itemQueue, r);
  return {
    ...e,
    units: { ...t.units },
    bench: i.bench,
    floor: i.floor,
    board: { ...t.board },
    items: a.items,
    itemQueue: a.itemQueue,
  };
}
function Rc(e, t, n) {
  return Kc(e.phase) || !ji(Object.values(e.units))
    ? e
    : Lc(
        e,
        {
          units: { ...e.units },
          bench: [...e.bench],
          board: { ...e.board },
          items: e.items,
          floor: e.floor,
        },
        t,
        n,
      );
}
function zc(e, t, n = []) {
  let r = new Set(n.flatMap((e) => (e.k === `evolved` ? [e.unit.id] : []))),
    i = [];
  for (let [n, a] of Object.entries(t)) {
    let t = e[n];
    !t ||
      r.has(n) ||
      a.star <= t.star ||
      !f[t.line] ||
      i.push({
        k: `evolved`,
        unit: a,
        prev: t,
        prevNum: l(f[t.line], t.star).num,
      });
  }
  return i;
}
function Bc(e) {
  let t = new Set(),
    n = (n) => !!n && !!e.units[n] && !t.has(n) && !!t.add(n),
    r = {};
  for (let [t, i] of Object.entries(e.board)) Te(+t) && n(i) && (r[+t] = i);
  let i = e.bench.slice(0, 9).map((e) => (n(e) ? e : null));
  for (; i.length < 9;) i.push(null);
  let a = e.floor.filter(n);
  for (let n of Object.keys(e.units)) t.has(n) || (t.add(n), a.push(n));
  return i.every((t, n) => t === e.bench[n]) &&
    e.bench.length === 9 &&
    a.length === e.floor.length &&
    a.every((t, n) => t === e.floor[n]) &&
    Object.keys(r).length === Object.keys(e.board).length
    ? e
    : { ...e, bench: i, board: r, floor: a };
}
function Vc(e) {
  let t = Object.entries(e.board).filter(([, t]) => !!e.units[t]),
    n = e.level - t.length;
  if (n <= 0) return [];
  let r = (t) => {
      var n;
      let r = e.units[t];
      return r
        ? (((n = f[r.line]) == null ? void 0 : n.cost) ?? 1) * 3 ** (r.star - 1)
        : 0;
    },
    i = [
      ...e.bench.flatMap((t, n) =>
        t && e.units[t] ? [{ id: t, slot: n }] : [],
      ),
      ...e.floor.filter((t) => e.units[t]).map((e) => ({ id: e, slot: -1 })),
    ].sort(
      (t, n) => r(n.id) - r(t.id) || e.units[n.id].star - e.units[t.id].star,
    ),
    a = new Set(t.map(([e]) => +e)),
    o = [];
  for (let t of i) {
    var s;
    if (n <= 0) break;
    let r =
        (((s = f[e.units[t.id].line]) == null ? void 0 : s.range) ?? 1) <= 2
          ? [4, 5, 6, 7]
          : [7, 6, 5, 4],
      i = -1;
    for (let e of r) {
      let t = Yc.map((t) => xe(t, e)).find((e) => !a.has(e));
      if (t !== void 0) {
        i = t;
        break;
      }
    }
    if (i < 0) break;
    (a.add(i), o.push({ id: t.id, slot: t.slot, cell: i }), n--);
  }
  return o;
}
function Hc(e, t, n, r) {
  let i = [],
    a = e.bench.indexOf(null),
    o = `u${e.nextId}`,
    s = n >= 2 ? Uc(t, n, [], e, e.units) : t,
    c = { ...e.units, [o]: { id: o, line: s, star: n } },
    l = [...e.bench];
  a >= 0 ? (l[a] = o) : l.push(o);
  let u = Lc(
      { ...e, nextId: e.nextId + 1 },
      {
        units: c,
        bench: l,
        board: { ...e.board },
        items: e.items,
        floor: e.floor,
      },
      r,
      i,
    ),
    d = u.floor.includes(o)
      ? `floor`
      : u.units[o] && a >= 0
        ? `bench`
        : `merge`;
  return (
    i.push({ k: `unitGiven`, id: o, line: s, where: d }),
    { s: u, ev: i, id: o, where: d }
  );
}
function Uc(e, t, n, r, i) {
  return Ti(
    e,
    t,
    n,
    Object.values(r.board)
      .map((e) => i[e])
      .filter(Boolean),
    [],
    !!r.eeveeKeep,
  );
}
function Wc(e, t) {
  return Ce(e.items, t)
    ? { s: { ...e, items: [...e.items, t] }, ev: [] }
    : {
        s: { ...e, itemQueue: [...e.itemQueue, t] },
        ev: [{ k: `bagQueue`, n: 1 }],
      };
}
function Gc(e) {
  if (e.phase !== `planning` || !e.floor.length || !e.bench.includes(null))
    return e;
  let t = [...e.bench],
    n = [...e.floor];
  for (; n.length && t.includes(null);) t[t.indexOf(null)] = n.shift();
  return { ...e, bench: t, floor: n };
}
var Kc, qc, Jc, Yc;
function Xc() {
  return (Xc = e(() => {
    (s(),
      S(),
      qa(),
      me(),
      (Kc = (e) => e === `intro` || e === `combat` || e === `result`),
      (qc = (e) => (Kc(e.phase) ? new Set(Object.values(e.board)) : null)),
      (Jc = (e) => Object.values(e.board).filter((t) => !!e.units[t]).length),
      (Yc = [3, 2, 4, 1, 5, 0, 6]));
  }))();
}
function Zc(e, t, n, r = []) {
  let i = E(`${e}|boon|${t}|${n}`),
    a = il(n),
    o = Ko.filter(
      (e) =>
        cl(n, e) > 0 &&
        ((e !== `coincase` && e !== `flute`) || !r.includes(e)) &&
        !(e === `master` && n >= (a.masterLegend ? ll : ul)),
    ),
    s = [];
  for (; s.length < 3 && s.length < o.length;) {
    let e = o.filter((e) => !s.includes(e)),
      t = e.reduce((e, t) => e + cl(n, t), 0),
      r = i() * t,
      a = e[e.length - 1];
    for (let t of e)
      if (((r -= cl(n, t)), r < 0)) {
        a = t;
        break;
      }
    s.push(a);
  }
  let c = Array.from(
      { length: Math.max(1, a.items) },
      () => Fe[Math.floor(i() * Fe.length)],
    ),
    l = Array.from({ length: a.vitamins }, () => v[Math.floor(i() * v.length)]);
  return { n, ids: s, item: c[0], fulls: c, parts: l };
}
function Qc(e, t, n, r, i) {
  let a = vi(n, r.taken),
    o = p.filter(
      (n) => n.cost === Math.max(1, Math.min(4, e)) && (a[n.id] ?? 0) >= t,
    );
  return o.length ? o[Math.floor(i() * o.length)].id : null;
}
function $c(e, t, n, r) {
  let i = t.ids[n];
  if (!i) return { s: e, ev: [], id: null };
  let a = il(t.n),
    o = r.rng(`boon|${t.n}`),
    s = { ...e, tower: { ...e.tower, boons: [...e.tower.boons, i] } },
    c = [],
    l = () => {
      s = { ...s, gold: s.gold + a.fallbackGold };
    };
  switch (i) {
    case `potion`:
      s = { ...s, hp: Math.min($.startHp, s.hp + a.potion) };
      break;
    case `nugget`:
      s = { ...s, gold: s.gold + a.nugget };
      break;
    case `candy`:
      s.level >= 9 ? l() : (s = { ...s, level: s.level + 1, xp: 0 });
      break;
    case `item`:
      for (let e of t.fulls.slice(0, Math.max(1, a.items))) {
        let t = Wc(s, e);
        ((s = t.s), (c = [...c, ...t.ev]));
      }
      break;
    case `vitamins`:
      for (let e of t.parts) {
        let t = Wc(s, e);
        ((s = t.s), (c = [...c, ...t.ev]));
      }
      break;
    case `egg`: {
      let e = Qc(a.eggCost, 3 ** (a.eggStar - 1), Object.values(s.units), r, o);
      if (!e) {
        l();
        break;
      }
      let t = Hc(s, e, a.eggStar, r);
      ((s = t.s), (c = t.ev));
      break;
    }
    case `master`:
      s = { ...s, tower: { ...s.tower, master: !0 } };
      break;
    case `ash`:
      s = { ...s, tower: { ...s.tower, ash: s.tower.ash + a.ash } };
      break;
    case `moonstone`: {
      let e = new Set(Object.values(s.board)),
        t = go(
          Object.values(s.units).filter((e) => {
            var t;
            return (
              (((t = f[e.line]) == null ? void 0 : t.cost) ?? 5) <=
              a.moonMaxCost
            );
          }),
          (t) => e.has(t.id),
        );
      if (!t) {
        l();
        break;
      }
      let n = {
          ...t,
          star: t.star + 1,
          line: Uc(t.line, t.star + 1, t.items ?? [], s, s.units),
        },
        i = [];
      ((s = Lc(
        s,
        {
          units: { ...s.units, [t.id]: n },
          bench: [...s.bench],
          board: { ...s.board },
          items: s.items,
          floor: s.floor,
        },
        r,
        i,
      )),
        (c = i));
      break;
    }
    case `wonder`: {
      let e = {},
        t = Object.values(s.units);
      for (let n of t) {
        var d;
        let i = ((d = f[n.line]) == null ? void 0 : d.cost) ?? 5,
          s =
            i + 1 > a.wonderMaxCost
              ? null
              : Qc(i + 1, 3 ** (n.star - 1), t, r, o);
        e[n.id] = s && u(s) !== u(n.line) ? { ...n, line: s } : n;
      }
      for (let n of t)
        e[n.id] !== n &&
          (e[n.id] = {
            ...e[n.id],
            line: Uc(e[n.id].line, n.star, n.items ?? [], s, e),
          });
      let n = [];
      ((s = Lc(
        s,
        {
          units: e,
          bench: [...s.bench],
          board: { ...s.board },
          items: s.items,
          floor: s.floor,
        },
        r,
        n,
      )),
        (c = n));
      break;
    }
  }
  return { s, ev: c, id: i };
}
var el, tl, nl, rl, il, al, ol, sl, cl, ll, ul;
function dl() {
  return (dl = e(() => {
    (s(),
      S(),
      qa(),
      ds(),
      Gl(),
      Xc(),
      (el = {
        ...qo,
        nugget: 12,
        amulet: 4,
        vitamins: 5,
        eggCost: 2,
        ash: 1,
        items: 2,
        wonderMaxCost: 2,
        moonMaxCost: 2,
        masterLegend: !0,
        masterStar: 1,
        masterStarLegend: 2,
      }),
      (tl = { ...Jo }),
      (nl = [
        {
          values: { nugget: 10, amulet: 2, vitamins: 3, ash: 2, expshare: 2 },
          weight: {
            item: 0,
            egg: 0,
            moonstone: 0,
            wonder: 0,
            master: 0,
            flute: 0,
            potion: 0,
          },
        },
        {
          values: {
            nugget: 14,
            amulet: 5,
            vitamins: 4,
            items: 1,
            eggCost: 2,
            moonMaxCost: 2,
            wonderMaxCost: 2,
            potion: 25,
            ash: 1,
            expshare: 4,
          },
          weight: {},
        },
        {
          values: {
            nugget: 18,
            amulet: 6,
            vitamins: 5,
            items: 2,
            eggCost: 3,
            moonMaxCost: 3,
            wonderMaxCost: 2,
            potion: 25,
            ash: 1,
            expshare: 6,
          },
          weight: { ash: 0 },
        },
      ]),
      (rl = (e) => {
        let t = zl(e);
        return t < 32 ? 0 : t < 42 ? 1 : 2;
      }),
      (il = (e) => {
        var t;
        return { ...el, ...((t = nl[rl(e)]) == null ? void 0 : t.values) };
      }),
      (al = (e) => {
        var t;
        return {
          ...el,
          ...((t = nl[Math.min(e, nl.length - 1)]) == null ? void 0 : t.values),
        };
      }),
      (ol = (e) =>
        e.reduce((e, t, n) => e + (t === `amulet` ? al(n).amulet : 0), 0)),
      (sl = (e) =>
        e.reduce((e, t, n) => e + (t === `expshare` ? al(n).expshare : 0), 0)),
      (cl = (e, t) => {
        var n;
        return ((n = nl[rl(e)]) == null ? void 0 : n.weight[t]) ?? tl[t];
      }),
      (ll = 17),
      (ul = 12));
  }))();
}
var fl;
function pl() {
  return (pl = e(() => {
    fl = {
      privateRooms: !0,
      arrivals: !0,
      overflowLabel: !1,
      boons: !1,
      itemShop: !1,
    };
  }))();
}
function ml(e, t, n) {
  let r = e.mode === `tower`,
    i = Ui({
      round: e.round,
      won: t.won,
      survivors: t.survivors,
      streak: e.streak,
      gold: e.gold,
      hp: e.hp,
      attempts: e.attempts,
      foeShare: t.foeShare,
      mustWin: r || void 0,
    }),
    a = r ? bo(e.round) : 0,
    o = e.tower,
    s = !1;
  if (r) {
    let e = t.won ? 0 : Uo(a, t.survivors),
      n = o.ash;
    (e > 0 && n > 0 && ((e = 0), n--, (s = !0)),
      (o = {
        ...o,
        ash: n,
        losses: o.losses + +!t.won,
        simTime: Math.round((o.simTime + t.simTime) * 10) / 10,
      }),
      (i = {
        ...i,
        damage: e,
        advanced: t.won,
        income: i.income + ss(o.boons),
      }));
  }
  let c = Math.min(i.damage, Math.max(0, e.hp)),
    l = !!(t.won && n && !e.badges.includes(n)),
    u = l ? [...e.badges, n] : e.badges;
  return {
    s: { ...e, streak: i.streak, badges: u, ...(r ? { tower: o } : {}) },
    damage: c,
    hp: e.hp - c,
    income: i.income,
    advanced: i.advanced,
    newBadge: l,
    ashUsed: s,
    floor: a,
    retryShare: i.retryShare,
  };
}
function hl(e, t, n, r = []) {
  let i = Rc({ ...e, phase: `planning` }, t, r),
    { level: a, xp: o } = _i(
      i.level,
      i.xp,
      2 + (i.mode === `tower` ? cs(i.tower.boons) : 0),
      i.round,
    ),
    s = n.advanced ? i.round + 1 : i.round,
    c = n.advanced ? 0 : i.attempts + 1,
    l = ka(s),
    u =
      (i.locked && !_l(i)) || l
        ? {
            shop: i.shop,
            shopShiny: i.shopShiny,
            rollN: 0,
            ...(i.locked && !l ? { locked: !1 } : {}),
          }
        : {
            ...Kl(i, t, a, Object.values(i.units), s, c, 0),
            ...(i.locked ? { locked: !1 } : {}),
          };
  return {
    ...i,
    phase: `planning`,
    hp: n.hp,
    gold: i.gold + n.income,
    level: a,
    xp: o,
    round: s,
    attempts: c,
    ...u,
  };
}
function gl(e, t, n) {
  let r = e.mode === `tower` ? e.tower.boons : [],
    i =
      n.kind && !Ka(n.kind, e.round)
        ? 0
        : Hi({ round: e.round, gold: e.gold, streak: e.streak }).total + ss(r),
    { level: a, xp: o } = _i(e.level, e.xp, 2 + n.trayXp + cs(r), e.round),
    s = e.round + 1,
    c =
      e.locked && !_l(e)
        ? { rollN: 0, locked: !1 }
        : { ...Kl(e, t, a, Object.values(e.units), s, 0, 0), locked: !1 };
  return {
    ...e,
    phase: `planning`,
    gold: e.gold + i,
    level: a,
    xp: o,
    round: s,
    attempts: 0,
    ...c,
  };
}
var _l;
function vl() {
  return (vl = e(() => {
    (qa(), ds(), Xc(), Xl(), (_l = (e) => e.locked && !e.shop.some(Boolean)));
  }))();
}
function yl(e) {
  if (e < 3)
    return e === 0
      ? { n: e, stage: 1, r: 1, kind: `oak` }
      : { n: e, stage: 1, r: e + 1, kind: `pve`, pve: `route1` };
  let t = Ll.length,
    n = e - 3,
    r = 2 + Math.floor(n / t),
    i = (n % t) + 1;
  if (r >= 5) return { n: e, stage: 5, r: n - 3 * t + 1, kind: `pvp` };
  let a = Ll[i - 1],
    o =
      fl.boons && a === `pvp` && ((r === 2 && i === 1) || (r >= 3 && i === 2));
  return a === `pvp`
    ? { n: e, stage: r, r: i, kind: a, ...(o ? { boon: o } : {}) }
    : a === `pve`
      ? { n: e, stage: r, r: i, kind: a, pve: Il[r] }
      : { n: e, stage: r, r: i, kind: a };
}
function bl() {
  return {
    phase: `planning`,
    mode: `pvp`,
    round: 0,
    attempts: 0,
    hp: $.startHp,
    gold: $.startGold,
    level: $.startLevel,
    xp: 0,
    streak: 0,
    badges: [],
    units: {},
    bench: Array(9).fill(null),
    floor: [],
    board: {},
    shop: [],
    shopShiny: [],
    shinySeen: 0,
    shinyBought: 0,
    rollN: 0,
    locked: !1,
    items: Array($.startMagnets).fill(C),
    itemQueue: [],
    itemReward: null,
    coins: null,
    league: 1,
    tower: as(),
    daily: null,
    runSeed: 0,
    nextId: 1,
  };
}
function xl(e, t, n) {
  let r = {
    seed: e,
    n: 0,
    players: t.map((e) => ({ id: e, s: bl(), place: null, recent: [] })),
    ...(n ? { secret: n } : {}),
  };
  for (let e of r.players)
    e.s = { ...e.s, ...Kl(e.s, wl(r, e.id), e.s.level, []) };
  return r;
}
function Sl(e, t = !0) {
  let n = yi(Object.values(e.units));
  if (t) {
    for (let t of e.shop)
      if (t) {
        let e = u(t);
        n[e] = (n[e] ?? 0) + 1;
      }
  }
  return n;
}
function Cl(e, t) {
  let n = {};
  for (let r of Bl(e))
    if (r.id !== t)
      for (let [e, t] of Object.entries(Sl(r.s))) n[e] = (n[e] ?? 0) + t;
  return n;
}
function wl(e, t) {
  let n = e.secret ?? e.seed;
  return { rng: (e) => E(`${n}|${t}|${e}`), taken: Cl(e, t), odds: $.odds };
}
function Tl(e) {
  let t = E(`${e.seed}|pair|${e.n}`),
    n = Bl(e).map((e) => e.id);
  for (let e = n.length - 1; e > 0; e--) {
    let r = Math.floor(t() * (e + 1));
    [n[e], n[r]] = [n[r], n[e]];
  }
  let r = Vl(n.length),
    i = new Map(n.map((t) => [t, e.players.find((e) => e.id === t).recent])),
    a = (e, t) => {
      let n = i.get(e),
        a = n.lastIndexOf(t),
        o = n.length - a;
      return a < 0 || o > r ? 0 : 1 << (4 * (r - o));
    },
    o = 1 / 0,
    s = [],
    c = [],
    l = (e, t) => {
      e > o ||
        (e < o && ((o = e), (s = [])),
        s.push({ pairs: c.map((e) => [e[0], e[1]]), ghost: t }));
    },
    u = (e, t, n) => {
      if (t > o) return;
      if (!e.length) {
        l(t, n);
        return;
      }
      let [r, ...i] = e;
      for (let e = 0; e < i.length; e++) {
        let o = i[e];
        (c.push([r, o]),
          u([...i.slice(0, e), ...i.slice(e + 1)], t + a(r, o) + a(o, r), n),
          c.pop());
      }
    };
  if (n.length % 2 == 0) u(n, 0, null);
  else if (n.length === 1) return { pairs: [], ghost: null };
  else
    for (let e of n)
      for (let t of n)
        t !== e &&
          u(
            n.filter((t) => t !== e),
            a(e, t),
            { player: e, copyOf: t },
          );
  return s[Math.floor(t() * s.length)];
}
function El(e, t) {
  if (yl(e.n).kind !== `pvp`) return null;
  let n = Bl(e);
  if (!n.some((e) => e.id === t)) return null;
  let r = `${e.seed}|${e.n}|${n.map((e) => `${e.id}:${e.recent.join(`,`)}`).join(`;`)}`;
  (Hl == null ? void 0 : Hl.key) !== r && (Hl = { key: r, pr: Tl(e) });
  let { pairs: i, ghost: a } = Hl.pr;
  if ((a == null ? void 0 : a.player) === t)
    return { opponent: a.copyOf, ghost: !0 };
  let o = i.find((e) => e.includes(t));
  return o ? { opponent: o[0] === t ? o[1] : o[0] } : null;
}
function Dl(e) {
  return Object.entries(e.board)
    .filter(([, t]) => e.units[t])
    .map(([t, n]) => {
      var r;
      let i = e.units[n];
      return {
        line: i.line,
        star: i.star,
        cell: +t,
        ownedId: n,
        ...((r = i.items) != null && r.length ? { items: i.items } : {}),
        ...(i.shiny ? { shiny: !0 } : {}),
      };
    });
}
function Ol(e) {
  let t = Math.min($.interestMax, Math.floor(e.gold / $.interestStep)),
    n = Math.abs(e.streak),
    r = 0;
  for (let [e, t] of $.streakGold) n >= e && (r = t);
  let i = e.won ? $.winGold : 0;
  return {
    base: $.baseIncome,
    interest: t,
    streak: r,
    win: i,
    total: $.baseIncome + t + r + i,
  };
}
function kl(e) {
  var t;
  let n = $.survivor,
    r = ((t = f[e.line]) == null ? void 0 : t.cost) ?? 1;
  return (
    (n.star[e.star] ?? n.star[n.star.length - 1]) +
    (r >= n.costFrom ? n.costBonus : 0)
  );
}
function Al(e, t, n = !1) {
  let r = yl(e),
    i =
      r.stage >= 5 && r.r >= $.finalFrom
        ? (r.r - $.finalFrom + 1) * $.finalStep
        : 0;
  return (
    (($.stageDamage[Math.min(r.stage, $.stageDamage.length - 1)] ?? 0) + i) *
      (n ? $.pveDamageK : 1) +
    t.reduce((e, t) => e + kl(t), 0)
  );
}
function jl(e) {
  let t = yl(e);
  return t.kind === `oak`
    ? $.oakSecs
    : t.kind === `safari`
      ? $.carouselSecs
      : (t.stage === 2 && t.r === 1
          ? $.firstPvpSecs
          : ($.planSecs[Math.min(t.stage, $.planSecs.length - 1)] ?? 30)) +
        (t.stage >= 5
          ? $.finalSecs
          : t.stage * 10 + t.r >= $.lateFrom
            ? $.lateSecs
            : 0) +
        (t.boon ? $.boonSecs : 0);
}
function Ml(e) {
  let t = yl(e).kind;
  return t === `oak` ? $.oakPays : t !== `safari` || $.carouselPays;
}
function Nl(e, t) {
  let n = e.players.map((e) => ({ ...e, recent: [...e.recent] })),
    r = new Map(n.map((e) => [e.id, e.s.hp])),
    i = new Map();
  for (let r of t) {
    let t = n.find((e) => e.id === r.id);
    if (!t || t.place !== null) continue;
    let a = r.won && !r.draw,
      o = a ? 0 : Math.min(t.s.hp, Al(e.n, r.survivors, r.pve)),
      s = t.s.tower;
    o > 0 && s.ash > 0 && ((o = 0), (s = { ...s, ash: s.ash - 1 }));
    let c = t.s.gold + (r.gold ?? 0);
    if (r.pve) {
      t.s = { ...t.s, hp: t.s.hp - o, gold: c, tower: s };
      continue;
    }
    i.set(t.id, a);
    let l = a ? Math.max(1, t.s.streak + 1) : Math.min(-1, t.s.streak - 1);
    ((t.s = { ...t.s, hp: t.s.hp - o, streak: l, gold: c, tower: s }),
      t.recent.push(r.opponent));
  }
  let a = n.filter((e) => e.place === null),
    o = a.filter((e) => e.s.hp <= 0).sort((e, t) => r.get(e.id) - r.get(t.id)),
    s = a.length;
  for (let e of o) e.place = s--;
  let c = a.filter((e) => e.place === null);
  c.length === 1 && (c[0].place = 1);
  let l = { ...e, n: e.n + 1, players: n },
    u = Wl(l.n),
    d = Ml(e.n),
    f = !(yl(e.n).kind === `safari` && !$.carouselPays),
    p = [];
  for (let e of n) {
    if (e.place !== null) continue;
    let t = e.s,
      n = t.tower.boons,
      r = d
        ? Ol({ gold: t.gold, streak: t.streak, won: i.get(e.id) === !0 })
            .total + ol(n)
        : 0,
      { level: a, xp: o } = f
        ? _i(t.level, t.xp, $.xpPerRound + sl(n), 0, $.xpTable)
        : t,
      s = {
        ...t,
        phase: u ? `event` : `planning`,
        gold: t.gold + r,
        level: a,
        xp: o,
        round: l.n,
        attempts: 0,
      };
    if (u) {
      e.s = s;
      continue;
    }
    let c = t.locked && !_l(t);
    ((e.s = c
      ? { ...s, rollN: 0, locked: !1 }
      : { ...s, shop: [], shopShiny: [], locked: !1 }),
      c || p.push(e));
  }
  let m = E(`${e.seed}|shop-order|${l.n}`);
  for (let e of p
    .map((e) => ({ p: e, k: m() }))
    .sort((e, t) => e.k - t.k)
    .map((e) => e.p))
    e.s = {
      ...e.s,
      ...Kl(e.s, wl(l, e.id), e.s.level, Object.values(e.s.units), l.n, 0, 0),
    };
  return l;
}
var Pl, Fl, $, Il, Ll, Rl, zl, Bl, Vl, Hl, Ul, Wl;
function Gl() {
  return (Gl = e(() => {
    (qa(),
      me(),
      S(),
      s(),
      ds(),
      dl(),
      pl(),
      vl(),
      Xl(),
      (Pl = { 1: 2, 2: 4, 3: 8, 4: 12, 5: 16, 6: 20, 7: 32, 8: 56 }),
      (Fl = {
        ...aa,
        4: [65, 30, 5, 0, 0],
        5: [58, 32, 9, 1, 0],
        6: [42, 40, 15, 3, 0],
      }),
      ($ = {
        players: 8,
        startHp: 100,
        startGold: 5,
        startLevel: 2,
        baseIncome: 5,
        winGold: 1,
        streakGold: [
          [2, 1],
          [3, 2],
          [5, 3],
        ],
        interestStep: 10,
        interestMax: 5,
        odds: Fl,
        rerollCost: 2,
        xpPerRound: 2,
        xpTable: Pl,
        stageDamage: [0, 0, 2, 6, 6, 8],
        finalFrom: 2,
        finalStep: 6,
        survivor: { star: [0, 1, 2, 4], costFrom: 4, costBonus: 1 },
        pairMemory: 3,
        pveDamageK: 1,
        carouselPays: !1,
        oakPays: !1,
        startMagnets: 1,
        planSecs: [0, 20, 25, 30, 30, 30],
        lateFrom: 34,
        lateSecs: 5,
        finalSecs: 10,
        firstPvpSecs: 20,
        boonSecs: 5,
        carouselSecs: 20,
        oakSecs: 6,
        transitionSecs: 3,
      }),
      (Il = { 2: `rocket`, 3: `snorlax`, 4: `legend` }),
      (Ll = [`pvp`, `pvp`, `pvp`, `safari`, `pvp`, `pvp`, `pvp`, `pve`]),
      (Rl = (e, t) => 3 + (Math.min(e, 5) - 2) * Ll.length + (t - 1)),
      (zl = (e) => {
        let t = yl(e);
        return t.stage * 10 + t.r;
      }),
      (Bl = (e) => e.players.filter((e) => e.place === null)),
      (Vl = (e) => Math.min($.pairMemory, Math.max(0, e - 2))),
      (Hl = null),
      (Ul = (e) => e.map((e) => ({ ...e, cell: 55 - e.cell }))),
      (Wl = (e) => {
        let t = yl(e).kind;
        return t === `oak` || t === `safari`;
      }));
  }))();
}
function Kl(e, t, n, r, i = e.round, a = e.attempts, o = e.rollN) {
  var s;
  let c = t.rng(`shop|${i}|${a}|${o}`),
    l = xi(n, r, c, t.taken, t.odds),
    u = Di(l, c);
  (s = t.shinyHook) == null || s.call(t, l, u);
  let d = u.filter(Boolean).length;
  return { shop: l, shopShiny: u, shinySeen: e.shinySeen + d, rollN: o + 1 };
}
function ql(e, t) {
  let n = Jl(e, t);
  return n && e.gold >= n.cost ? n.slots : null;
}
function Jl(e, t) {
  let n = e.shop[t];
  if (!n || !f[n]) return null;
  let r = u(n),
    i = qc(e),
    a = Object.values(e.units).filter(
      (e) => e.star === 1 && u(e.line) === r && !(i != null && i.has(e.id)),
    ).length,
    o = Math.max(1, 3 - a),
    s = e.shop
      .map((e, t) => t)
      .filter((n) => n !== t && !!e.shop[n] && u(e.shop[n]) === r)
      .sort(
        (t, n) => Number(!!e.shopShiny[n]) - Number(!!e.shopShiny[t]) || t - n,
      );
  if (s.length < o - 1) return null;
  let c = [t, ...s.slice(0, o - 1)];
  return { slots: c, cost: c.reduce((t, n) => t + f[e.shop[n]].cost, 0) };
}
var Yl;
function Xl() {
  return (Xl = e(() => {
    (qa(),
      ds(),
      s(),
      Xc(),
      Gl(),
      (Yl = (e) => {
        var t, n;
        return e.mode === `pvp`
          ? ls(((t = e.tower) == null ? void 0 : t.boons) ?? [], $.rerollCost)
          : e.mode === `tower`
            ? ls(((n = e.tower) == null ? void 0 : n.boons) ?? [], 2)
            : 2;
      }));
  }))();
}
export {
  Bc as $,
  Ea as $n,
  wt as $r,
  us as $t,
  ml as A,
  X as An,
  di as Ar,
  ks as At,
  rl as B,
  Sa as Bn,
  Ir as Br,
  Zo as Bt,
  zl as C,
  Qe as Ci,
  Ja as Cn,
  Ai as Cr,
  Ns as Ct,
  vl as D,
  ca as Dn,
  Ii as Dr,
  Os as Dt,
  Cl as E,
  We as Ei,
  Fa as En,
  Oi as Er,
  Ms as Et,
  tl as F,
  Ua as Fn,
  J as Fr,
  Ko as Ft,
  Fc as G,
  wi as Gn,
  bn as Gr,
  Z as Gt,
  Jc as H,
  $i as Hn,
  Lr as Hr,
  Fo as Ht,
  $c as I,
  Ca as In,
  Mr as Ir,
  Yo as It,
  Hc as J,
  Pi as Jn,
  Ct as Jr,
  Oo as Jt,
  Uc as K,
  la as Kn,
  xn as Kr,
  vo as Kt,
  dl as L,
  wa as Ln,
  kr as Lr,
  $o as Lt,
  pl as M,
  aa as Mn,
  pi as Mr,
  vs as Mt,
  nl as N,
  Na as Nn,
  si as Nr,
  Es as Nt,
  gl as O,
  sa as On,
  Li as Or,
  _s as Ot,
  el as P,
  ua as Pn,
  gi as Pr,
  ys as Pt,
  Gc as Q,
  qa as Qn,
  jt as Qr,
  mo as Qt,
  ol as R,
  ia as Rn,
  zr as Rr,
  Xo as Rt,
  yl as S,
  Xe as Si,
  to as Sn,
  Ma as Sr,
  Bs as St,
  Ml as T,
  it as Ti,
  Xa as Tn,
  na as Tr,
  Fs as Tt,
  Pc as U,
  ki as Un,
  wn as Ur,
  Po as Ut,
  il as V,
  Pa as Vn,
  Br as Vr,
  qo as Vt,
  zc as W,
  ma as Wn,
  Cn as Wr,
  Do as Wt,
  qc as X,
  Vi as Xn,
  Dt as Xr,
  ss as Xt,
  Xc as Y,
  Ka as Yn,
  Ot as Yr,
  co as Yt,
  Vc as Z,
  Hi as Zn,
  kt as Zr,
  fo as Zt,
  Tl as _,
  rt as _i,
  lo as _n,
  qi as _r,
  hc as _t,
  ql as a,
  ft as ai,
  es as an,
  Ki as ar,
  bc as at,
  Al as b,
  ct as bi,
  rs as bn,
  Qi as br,
  Vs as bt,
  Ll as c,
  ut as ci,
  eo as cn,
  Va as cr,
  Tc as ct,
  Nl as d,
  st as di,
  wo as dn,
  Fi as dr,
  _c as dt,
  gt as ei,
  as as en,
  ka as er,
  Lc as et,
  Gl as f,
  Ye as fi,
  ho as fn,
  vi as fr,
  dc as ft,
  Vl as g,
  at as gi,
  jo as gn,
  ea as gr,
  mc as gt,
  El as h,
  lt as hi,
  _o as hn,
  Ta as hr,
  Zs as ht,
  Jl as i,
  vt as ii,
  ds as in,
  ta as ir,
  xc as it,
  fl as j,
  Da as jn,
  fi as jr,
  bs as jt,
  hl as k,
  Wa as kn,
  oa as kr,
  Ss as kt,
  Bl as l,
  E as li,
  go as ln,
  ji as lr,
  wc as lt,
  xl as m,
  $e as mi,
  xo as mn,
  Ji as mr,
  rc as mt,
  Kl as n,
  xt as ni,
  So as nn,
  Wi as nr,
  Ic as nt,
  Fl as o,
  pt as oi,
  yo as on,
  Ba as or,
  ec as ot,
  Ul as p,
  nt as pi,
  uo as pn,
  La as pr,
  fc as pt,
  Wc as q,
  Ei as qn,
  Tt as qr,
  No as qt,
  Yl as r,
  St as ri,
  bo as rn,
  Gi as rr,
  yc as rt,
  $ as s,
  mt as si,
  $a as sn,
  za as sr,
  Cc as st,
  Xl as t,
  bt as ti,
  ao as tn,
  Mi as tr,
  Rc as tt,
  Dl as u,
  Je as ui,
  Co as un,
  Ri as ur,
  jc as ut,
  jl as v,
  Ge as vi,
  Ho as vn,
  xi as vr,
  Xs as vt,
  Rl as w,
  tt as wi,
  Qa as wn,
  va as wr,
  Ls as wt,
  Ol as x,
  Ue as xi,
  is as xn,
  Xi as xr,
  zs as xt,
  wl as y,
  ot as yi,
  oo as yn,
  ja as yr,
  js as yt,
  Zc as z,
  _i as zn,
  Fr as zr,
  Qo as zt,
};
